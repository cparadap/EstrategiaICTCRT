export { candleArb, bullishCandleArb, bearishCandleArb } from './candle.gen';
export type { Candle, CandleType } from './candle.gen';

export {
  bearishThenBullishSequenceArb,
  bullishThenBearishSequenceArb,
  pullbackImpulseSequenceArb,
  impulsePullbackSequenceArb,
  continuousSequenceArb,
} from './candle-sequence.gen';
export type { SequenceOptions } from './candle-sequence.gen';

export { crtRangeArb, anyCrtRangeArb, crtCascadeArb } from './crt-range.gen';
export type { CrtRange, CrtTimeframe, CrtFlagState } from './crt-range.gen';

export { strategyStateArb, stateForPhaseArb, STATE } from './state.gen';
export type { StrategyState, StateValue, TrendDirection, OrderBlock } from './state.gen';
