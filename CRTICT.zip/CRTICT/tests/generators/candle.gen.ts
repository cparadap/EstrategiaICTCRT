import fc from 'fast-check';

/**
 * Represents an OHLC candle with open, high, low, close prices.
 */
export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
}

export type CandleType = 'bullish' | 'bearish' | 'any';

/**
 * Generates a valid OHLC candle ensuring:
 * - high >= max(open, close)
 * - low <= min(open, close)
 * - high >= low
 *
 * @param type - Constrain to bullish (close > open), bearish (close < open), or any
 * @param priceRange - Optional price range constraints { min, max }
 */
export function candleArb(
  type: CandleType = 'any',
  priceRange: { min: number; max: number } = { min: 1, max: 10000 }
): fc.Arbitrary<Candle> {
  const { min, max } = priceRange;

  return fc
    .record({
      open: fc.double({ min, max, noNaN: true, noDefaultInfinity: true }),
      close: fc.double({ min, max, noNaN: true, noDefaultInfinity: true }),
      wickAbove: fc.double({ min: 0, max: (max - min) * 0.1, noNaN: true, noDefaultInfinity: true }),
      wickBelow: fc.double({ min: 0, max: (max - min) * 0.1, noNaN: true, noDefaultInfinity: true }),
    })
    .filter(({ open, close }) => {
      if (type === 'bullish') return close > open;
      if (type === 'bearish') return close < open;
      return true;
    })
    .map(({ open, close, wickAbove, wickBelow }) => {
      const bodyHigh = Math.max(open, close);
      const bodyLow = Math.min(open, close);
      const high = bodyHigh + wickAbove;
      const low = Math.max(min, bodyLow - wickBelow);

      return { open, high, low, close };
    });
}

/**
 * Generates a strictly bullish candle (close > open).
 */
export function bullishCandleArb(
  priceRange: { min: number; max: number } = { min: 1, max: 10000 }
): fc.Arbitrary<Candle> {
  return candleArb('bullish', priceRange);
}

/**
 * Generates a strictly bearish candle (close < open).
 */
export function bearishCandleArb(
  priceRange: { min: number; max: number } = { min: 1, max: 10000 }
): fc.Arbitrary<Candle> {
  return candleArb('bearish', priceRange);
}
