import fc from 'fast-check';
import { Candle, bullishCandleArb, bearishCandleArb, candleArb } from './candle.gen';

/**
 * Options for generating candle sequences with controlled patterns.
 */
export interface SequenceOptions {
  /** Price range for generated candles */
  priceRange?: { min: number; max: number };
  /** Maximum gap between consecutive candles (as fraction of price) */
  maxGapFraction?: number;
}

const DEFAULT_OPTIONS: Required<SequenceOptions> = {
  priceRange: { min: 100, max: 5000 },
  maxGapFraction: 0.02,
};

/**
 * Adjusts a candle to maintain price continuity with the previous candle.
 * The new candle's open is derived from the previous candle's close with a small gap.
 */
function adjustForContinuity(candle: Candle, prevClose: number, maxGap: number): Candle {
  const gap = (candle.open - prevClose) > 0
    ? Math.min(candle.open - prevClose, maxGap)
    : Math.max(candle.open - prevClose, -maxGap);

  const newOpen = prevClose + gap;
  const diff = candle.close - candle.open;
  const newClose = newOpen + diff;

  const bodyHigh = Math.max(newOpen, newClose);
  const bodyLow = Math.min(newOpen, newClose);

  // Preserve wick proportions
  const origBodyHigh = Math.max(candle.open, candle.close);
  const origBodyLow = Math.min(candle.open, candle.close);
  const wickAbove = candle.high - origBodyHigh;
  const wickBelow = origBodyLow - candle.low;

  return {
    open: newOpen,
    close: newClose,
    high: bodyHigh + wickAbove,
    low: bodyLow - wickBelow,
  };
}

/**
 * Generates a sequence of N bearish candles followed by M bullish candles
 * with realistic price continuity between consecutive candles.
 *
 * @param bearishCount - Number of bearish candles (minimum 1)
 * @param bullishCount - Number of bullish candles (minimum 1)
 * @param options - Sequence generation options
 */
export function bearishThenBullishSequenceArb(
  bearishCount: number,
  bullishCount: number,
  options: SequenceOptions = {}
): fc.Arbitrary<Candle[]> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const { priceRange, maxGapFraction } = opts;
  const maxGap = (priceRange.max - priceRange.min) * maxGapFraction;

  return fc
    .tuple(
      fc.array(bearishCandleArb(priceRange), { minLength: bearishCount, maxLength: bearishCount }),
      fc.array(bullishCandleArb(priceRange), { minLength: bullishCount, maxLength: bullishCount })
    )
    .map(([bearishCandles, bullishCandles]) => {
      const allCandles = [...bearishCandles, ...bullishCandles];
      const result: Candle[] = [allCandles[0]];

      for (let i = 1; i < allCandles.length; i++) {
        const prevClose = result[i - 1].close;
        result.push(adjustForContinuity(allCandles[i], prevClose, maxGap));
      }

      return result;
    });
}

/**
 * Generates a sequence of N bullish candles followed by M bearish candles
 * with realistic price continuity between consecutive candles.
 *
 * @param bullishCount - Number of bullish candles (minimum 1)
 * @param bearishCount - Number of bearish candles (minimum 1)
 * @param options - Sequence generation options
 */
export function bullishThenBearishSequenceArb(
  bullishCount: number,
  bearishCount: number,
  options: SequenceOptions = {}
): fc.Arbitrary<Candle[]> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const { priceRange, maxGapFraction } = opts;
  const maxGap = (priceRange.max - priceRange.min) * maxGapFraction;

  return fc
    .tuple(
      fc.array(bullishCandleArb(priceRange), { minLength: bullishCount, maxLength: bullishCount }),
      fc.array(bearishCandleArb(priceRange), { minLength: bearishCount, maxLength: bearishCount })
    )
    .map(([bullishCandles, bearishCandles]) => {
      const allCandles = [...bullishCandles, ...bearishCandles];
      const result: Candle[] = [allCandles[0]];

      for (let i = 1; i < allCandles.length; i++) {
        const prevClose = result[i - 1].close;
        result.push(adjustForContinuity(allCandles[i], prevClose, maxGap));
      }

      return result;
    });
}

/**
 * Generates a random-length candle sequence with a controlled pattern:
 * N bearish (pullback) followed by M bullish (impulse), where N >= minBearish and M >= minBullish.
 *
 * @param minBearish - Minimum number of bearish candles (default 3)
 * @param minBullish - Minimum number of bullish candles (default 3)
 * @param options - Sequence generation options
 */
export function pullbackImpulseSequenceArb(
  minBearish: number = 3,
  minBullish: number = 3,
  options: SequenceOptions = {}
): fc.Arbitrary<{ sequence: Candle[]; bearishCount: number; bullishCount: number }> {
  return fc
    .tuple(
      fc.integer({ min: minBearish, max: minBearish + 4 }),
      fc.integer({ min: minBullish, max: minBullish + 4 })
    )
    .chain(([nBearish, nBullish]) =>
      bearishThenBullishSequenceArb(nBearish, nBullish, options).map((sequence) => ({
        sequence,
        bearishCount: nBearish,
        bullishCount: nBullish,
      }))
    );
}

/**
 * Generates a random-length candle sequence with a controlled pattern:
 * N bullish (impulse) followed by M bearish (pullback), where N >= minBullish and M >= minBearish.
 *
 * @param minBullish - Minimum number of bullish candles (default 3)
 * @param minBearish - Minimum number of bearish candles (default 3)
 * @param options - Sequence generation options
 */
export function impulsePullbackSequenceArb(
  minBullish: number = 3,
  minBearish: number = 3,
  options: SequenceOptions = {}
): fc.Arbitrary<{ sequence: Candle[]; bullishCount: number; bearishCount: number }> {
  return fc
    .tuple(
      fc.integer({ min: minBullish, max: minBullish + 4 }),
      fc.integer({ min: minBearish, max: minBearish + 4 })
    )
    .chain(([nBullish, nBearish]) =>
      bullishThenBearishSequenceArb(nBullish, nBearish, options).map((sequence) => ({
        sequence,
        bullishCount: nBullish,
        bearishCount: nBearish,
      }))
    );
}

/**
 * Generates a continuous candle sequence of arbitrary type with price continuity.
 *
 * @param length - Number of candles to generate
 * @param options - Sequence generation options
 */
export function continuousSequenceArb(
  length: number,
  options: SequenceOptions = {}
): fc.Arbitrary<Candle[]> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const { priceRange, maxGapFraction } = opts;
  const maxGap = (priceRange.max - priceRange.min) * maxGapFraction;

  return fc
    .array(candleArb('any', priceRange), { minLength: length, maxLength: length })
    .map((candles) => {
      const result: Candle[] = [candles[0]];

      for (let i = 1; i < candles.length; i++) {
        const prevClose = result[i - 1].close;
        result.push(adjustForContinuity(candles[i], prevClose, maxGap));
      }

      return result;
    });
}
