import fc from 'fast-check';

/**
 * Represents a CRT (Candle Range Theory) range state.
 */
export interface CrtRange {
  /** Upper boundary of the CRT range */
  high: number;
  /** Lower boundary of the CRT range */
  low: number;
  /** Whether the CRT range is currently valid (established but not invalidated) */
  valid: boolean;
  /** Whether the CRT range has been activated (price broke activation extreme) */
  activated: boolean;
}

export type CrtTimeframe = '4H' | '1H' | '15M' | '5M';

export type CrtFlagState = 'established' | 'activated' | 'invalidated';

/**
 * Generates a valid CRT range state with:
 * - high > low (always)
 * - Consistent flag combinations:
 *   - established: valid=true, activated=false
 *   - activated: valid=true, activated=true
 *   - invalidated: valid=false, activated=false
 *
 * @param flagState - The desired flag state combination
 * @param priceRange - Optional price range constraints
 */
export function crtRangeArb(
  flagState: CrtFlagState = 'established',
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<CrtRange> {
  const { min, max } = priceRange;

  return fc
    .record({
      low: fc.double({ min, max: max - 1, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: (max - min) * 0.1, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => {
      const high = low + spread;
      const flags = getFlagsByState(flagState);

      return {
        high,
        low,
        ...flags,
      };
    });
}

/**
 * Generates a CRT range with any valid flag combination.
 */
export function anyCrtRangeArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<CrtRange & { flagState: CrtFlagState }> {
  return fc
    .constantFrom<CrtFlagState>('established', 'activated', 'invalidated')
    .chain((flagState) =>
      crtRangeArb(flagState, priceRange).map((range) => ({
        ...range,
        flagState,
      }))
    );
}

/**
 * Generates a set of CRT ranges for all four timeframes with consistent parent-child relationships.
 * - If a parent CRT is invalidated, children must also be invalidated.
 * - If a child is activated, its parent must also be activated.
 */
export function crtCascadeArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<Record<CrtTimeframe, CrtRange | null>> {
  return fc
    .constantFrom<CrtFlagState>('established', 'activated', 'invalidated')
    .chain((h4State) => {
      // 4H determines what's possible for children
      const h1States = getValidChildStates(h4State);
      return fc.tuple(
        crtRangeArb(h4State, priceRange),
        fc.constantFrom(...h1States).chain((h1State) => {
          const m15States = getValidChildStates(h1State);
          return fc.tuple(
            h1State === 'invalidated' ? fc.constant(null) : crtRangeArb(h1State, priceRange).map(r => r as CrtRange | null),
            fc.constantFrom(...m15States).chain((m15State) => {
              const m5States = getValidChildStates(m15State);
              return fc.tuple(
                m15State === 'invalidated' ? fc.constant(null) : crtRangeArb(m15State, priceRange).map(r => r as CrtRange | null),
                fc.constantFrom(...m5States).chain((m5State) =>
                  m5State === 'invalidated' ? fc.constant(null) : crtRangeArb(m5State, priceRange).map(r => r as CrtRange | null)
                )
              );
            })
          );
        })
      );
    })
    .map(([h4Range, [h1Range, [m15Range, m5Range]]]) => ({
      '4H': h4Range,
      '1H': h1Range,
      '15M': m15Range,
      '5M': m5Range,
    }));
}

function getFlagsByState(state: CrtFlagState): { valid: boolean; activated: boolean } {
  switch (state) {
    case 'established':
      return { valid: true, activated: false };
    case 'activated':
      return { valid: true, activated: true };
    case 'invalidated':
      return { valid: false, activated: false };
  }
}

function getValidChildStates(parentState: CrtFlagState): CrtFlagState[] {
  switch (parentState) {
    case 'invalidated':
      return ['invalidated'];
    case 'established':
      // Parent not yet activated, so child cannot exist yet
      return ['invalidated'];
    case 'activated':
      // Parent activated, child can be in any state
      return ['established', 'activated', 'invalidated'];
  }
}
