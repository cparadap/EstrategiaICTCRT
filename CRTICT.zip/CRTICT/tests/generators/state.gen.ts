import fc from 'fast-check';
import { CrtRange, crtRangeArb } from './crt-range.gen';

/**
 * State machine state constants matching Pine Script definitions.
 */
export const STATE = {
  IDLE: 0,
  WAIT_OB_TOUCH: 1,
  WAIT_4H_ACTIVATION: 2,
  WAIT_1H_CRT: 3,
  WAIT_15M_CRT: 4,
  WAIT_5M_ENTRY: 5,
  POSITION_OPEN: 6,
} as const;

export type StateValue = (typeof STATE)[keyof typeof STATE];

export type TrendDirection = 1 | -1;

/**
 * Represents the order block zone.
 */
export interface OrderBlock {
  high: number;
  low: number;
  barIndex: number;
  valid: boolean;
}

/**
 * Represents the full state machine configuration.
 */
export interface StrategyState {
  /** Current state machine state */
  state: StateValue;
  /** Current trend direction: 1=bullish, -1=bearish */
  trend: TrendDirection;
  /** Previous trend (for change detection) */
  prevTrend: TrendDirection;
  /** Order block zone (null if not identified) */
  orderBlock: OrderBlock | null;
  /** 4H CRT range (null if not established) */
  crt4h: CrtRange | null;
  /** 1H CRT range (null if not established) */
  crt1h: CrtRange | null;
  /** 15M CRT range (null if not established) */
  crt15m: CrtRange | null;
  /** 5M CRT range (null if not established) */
  crt5m: CrtRange | null;
  /** Setup time for 4H CRT (timestamp in ms, null if no setup) */
  setupTime: number | null;
  /** Whether a position is currently open */
  positionOpen: boolean;
}

/**
 * Generates a valid order block with high > low.
 */
function orderBlockArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<OrderBlock> {
  return fc.record({
    low: fc.double({ min: priceRange.min, max: priceRange.max - 1, noNaN: true, noDefaultInfinity: true }),
    spread: fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
    barIndex: fc.integer({ min: 0, max: 10000 }),
    valid: fc.constant(true),
  }).map(({ low, spread, barIndex, valid }) => ({
    high: low + spread,
    low,
    barIndex,
    valid,
  }));
}

/**
 * Generates a random state machine configuration with consistent internal state.
 *
 * Consistency rules:
 * - IDLE: no active CRT ranges, no OB, no position
 * - WAIT_OB_TOUCH: OB valid, no CRT ranges
 * - WAIT_4H_ACTIVATION: OB valid, 4H CRT established (valid, not activated)
 * - WAIT_1H_CRT: 4H CRT activated, 1H CRT may be established or null (waiting for first bar)
 * - WAIT_15M_CRT: 4H + 1H CRT activated, 15M CRT may be established or null
 * - WAIT_5M_ENTRY: 4H + 1H + 15M CRT activated, 5M CRT may be established or null
 * - POSITION_OPEN: position is open, all CRTs activated
 */
export function strategyStateArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<StrategyState> {
  return fc
    .constantFrom<StateValue>(
      STATE.IDLE,
      STATE.WAIT_OB_TOUCH,
      STATE.WAIT_4H_ACTIVATION,
      STATE.WAIT_1H_CRT,
      STATE.WAIT_15M_CRT,
      STATE.WAIT_5M_ENTRY,
      STATE.POSITION_OPEN
    )
    .chain((state) => buildConsistentState(state, priceRange));
}

/**
 * Generates a strategy state for a specific state value with consistent internals.
 */
export function stateForPhaseArb(
  phase: StateValue,
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<StrategyState> {
  return buildConsistentState(phase, priceRange);
}

function buildConsistentState(
  state: StateValue,
  priceRange: { min: number; max: number }
): fc.Arbitrary<StrategyState> {
  const trendArb = fc.constantFrom<TrendDirection>(1, -1);
  const setupTimeArb = fc.integer({ min: 1_000_000_000_000, max: 2_000_000_000_000 });

  switch (state) {
    case STATE.IDLE:
      return trendArb.map((trend) => ({
        state: STATE.IDLE,
        trend,
        prevTrend: trend,
        orderBlock: null,
        crt4h: null,
        crt1h: null,
        crt15m: null,
        crt5m: null,
        setupTime: null,
        positionOpen: false,
      }));

    case STATE.WAIT_OB_TOUCH:
      return fc.tuple(trendArb, orderBlockArb(priceRange)).map(([trend, ob]) => ({
        state: STATE.WAIT_OB_TOUCH,
        trend,
        prevTrend: trend,
        orderBlock: ob,
        crt4h: null,
        crt1h: null,
        crt15m: null,
        crt5m: null,
        setupTime: null,
        positionOpen: false,
      }));

    case STATE.WAIT_4H_ACTIVATION:
      return fc
        .tuple(trendArb, orderBlockArb(priceRange), crtRangeArb('established', priceRange), setupTimeArb)
        .map(([trend, ob, crt4h, setupTime]) => ({
          state: STATE.WAIT_4H_ACTIVATION,
          trend,
          prevTrend: trend,
          orderBlock: ob,
          crt4h,
          crt1h: null,
          crt15m: null,
          crt5m: null,
          setupTime,
          positionOpen: false,
        }));

    case STATE.WAIT_1H_CRT:
      return fc
        .tuple(
          trendArb,
          orderBlockArb(priceRange),
          crtRangeArb('activated', priceRange),
          fc.option(crtRangeArb('established', priceRange), { nil: null }),
          setupTimeArb
        )
        .map(([trend, ob, crt4h, crt1h, setupTime]) => ({
          state: STATE.WAIT_1H_CRT,
          trend,
          prevTrend: trend,
          orderBlock: ob,
          crt4h,
          crt1h,
          crt15m: null,
          crt5m: null,
          setupTime,
          positionOpen: false,
        }));

    case STATE.WAIT_15M_CRT:
      return fc
        .tuple(
          trendArb,
          orderBlockArb(priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          fc.option(crtRangeArb('established', priceRange), { nil: null }),
          setupTimeArb
        )
        .map(([trend, ob, crt4h, crt1h, crt15m, setupTime]) => ({
          state: STATE.WAIT_15M_CRT,
          trend,
          prevTrend: trend,
          orderBlock: ob,
          crt4h,
          crt1h,
          crt15m,
          crt5m: null,
          setupTime,
          positionOpen: false,
        }));

    case STATE.WAIT_5M_ENTRY:
      return fc
        .tuple(
          trendArb,
          orderBlockArb(priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          fc.option(crtRangeArb('established', priceRange), { nil: null }),
          setupTimeArb
        )
        .map(([trend, ob, crt4h, crt1h, crt15m, crt5m, setupTime]) => ({
          state: STATE.WAIT_5M_ENTRY,
          trend,
          prevTrend: trend,
          orderBlock: ob,
          crt4h,
          crt1h,
          crt15m,
          crt5m,
          setupTime,
          positionOpen: false,
        }));

    case STATE.POSITION_OPEN:
      return fc
        .tuple(
          trendArb,
          orderBlockArb(priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          crtRangeArb('activated', priceRange),
          setupTimeArb
        )
        .map(([trend, ob, crt4h, crt1h, crt15m, crt5m, setupTime]) => ({
          state: STATE.POSITION_OPEN,
          trend,
          prevTrend: trend,
          orderBlock: ob,
          crt4h,
          crt1h,
          crt15m,
          crt5m,
          setupTime,
          positionOpen: true,
        }));

    default:
      return fc.constant<StrategyState>({
        state: STATE.IDLE,
        trend: 1,
        prevTrend: 1,
        orderBlock: null,
        crt4h: null,
        crt1h: null,
        crt15m: null,
        crt5m: null,
        setupTime: null,
        positionOpen: false,
      });
  }
}
