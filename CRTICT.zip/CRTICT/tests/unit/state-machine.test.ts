import { describe, it, expect } from 'vitest';
import { STATE, type StateValue } from '../logic/crt';
import {
  transition,
  applyTrendChangeInvalidation,
  isActiveSetupState,
  validEventsForState,
  type StateMachineEvent,
} from '../logic/state-machine';

/**
 * Unit tests for State Machine Transitions
 * Validates: Requirements 11.2, 11.3
 */

// ============================================================================
// FULL CASCADE: IDLE → ... → POSITION_OPEN → IDLE
// ============================================================================

describe('State Machine - Full Cascade', () => {
  it('completes the full happy-path cascade: IDLE → WAIT_OB_TOUCH → WAIT_4H_ACTIVATION → WAIT_1H_CRT → WAIT_15M_CRT → WAIT_5M_ENTRY → POSITION_OPEN → IDLE', () => {
    let state: StateValue = STATE.IDLE;

    // Step 1: OB identified → WAIT_OB_TOUCH
    state = transition(state, { type: 'OB_IDENTIFIED' });
    expect(state).toBe(STATE.WAIT_OB_TOUCH);

    // Step 2: Price touches OB → WAIT_4H_ACTIVATION
    state = transition(state, { type: 'OB_TOUCHED' });
    expect(state).toBe(STATE.WAIT_4H_ACTIVATION);

    // Step 3: 4H CRT activated → WAIT_1H_CRT
    state = transition(state, { type: 'CRT_4H_ACTIVATED' });
    expect(state).toBe(STATE.WAIT_1H_CRT);

    // Step 4: 1H CRT activated → WAIT_15M_CRT
    state = transition(state, { type: 'CRT_1H_ACTIVATED' });
    expect(state).toBe(STATE.WAIT_15M_CRT);

    // Step 5: 15M CRT activated → WAIT_5M_ENTRY
    state = transition(state, { type: 'CRT_15M_ACTIVATED' });
    expect(state).toBe(STATE.WAIT_5M_ENTRY);

    // Step 6: 5M entry triggered → POSITION_OPEN
    state = transition(state, { type: 'CRT_5M_ENTRY_TRIGGERED' });
    expect(state).toBe(STATE.POSITION_OPEN);

    // Step 7: Position closed → IDLE
    state = transition(state, { type: 'POSITION_CLOSED' });
    expect(state).toBe(STATE.IDLE);
  });

  it('4H CRT invalidation resets to IDLE from WAIT_4H_ACTIVATION', () => {
    let state: StateValue = STATE.IDLE;

    state = transition(state, { type: 'OB_IDENTIFIED' });
    state = transition(state, { type: 'OB_TOUCHED' });
    expect(state).toBe(STATE.WAIT_4H_ACTIVATION);

    // 4H CRT invalidated → back to IDLE
    state = transition(state, { type: 'CRT_4H_INVALIDATED' });
    expect(state).toBe(STATE.IDLE);
  });

  it('can restart the cascade after invalidation', () => {
    let state: StateValue = STATE.IDLE;

    // Start cascade
    state = transition(state, { type: 'OB_IDENTIFIED' });
    state = transition(state, { type: 'OB_TOUCHED' });
    state = transition(state, { type: 'CRT_4H_ACTIVATED' });
    expect(state).toBe(STATE.WAIT_1H_CRT);

    // Trend change resets
    state = transition(state, { type: 'TREND_CHANGED' });
    expect(state).toBe(STATE.IDLE);

    // Restart cascade from IDLE
    state = transition(state, { type: 'OB_IDENTIFIED' });
    expect(state).toBe(STATE.WAIT_OB_TOUCH);

    state = transition(state, { type: 'OB_TOUCHED' });
    expect(state).toBe(STATE.WAIT_4H_ACTIVATION);
  });
});

// ============================================================================
// INVALID TRANSITIONS (NO-OP)
// ============================================================================

describe('State Machine - Invalid Transitions (no-op)', () => {
  const ALL_EVENTS: StateMachineEvent['type'][] = [
    'OB_IDENTIFIED',
    'OB_TOUCHED',
    'CRT_4H_ACTIVATED',
    'CRT_4H_INVALIDATED',
    'CRT_1H_ACTIVATED',
    'CRT_15M_ACTIVATED',
    'CRT_5M_ENTRY_TRIGGERED',
    'POSITION_CLOSED',
    'TREND_CHANGED',
    'TIME_LIMIT_EXCEEDED',
  ];

  describe('IDLE state ignores all events except OB_IDENTIFIED', () => {
    const invalidForIdle: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => e !== 'OB_IDENTIFIED'
    );

    it.each(invalidForIdle)('IDLE + %s → IDLE (no-op)', (eventType) => {
      const result = transition(STATE.IDLE, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.IDLE);
    });
  });

  describe('WAIT_OB_TOUCH ignores events not in its valid set', () => {
    const invalidForWaitOB: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => !['OB_TOUCHED', 'TREND_CHANGED', 'TIME_LIMIT_EXCEEDED'].includes(e)
    );

    it.each(invalidForWaitOB)('WAIT_OB_TOUCH + %s → WAIT_OB_TOUCH (no-op)', (eventType) => {
      const result = transition(STATE.WAIT_OB_TOUCH, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.WAIT_OB_TOUCH);
    });
  });

  describe('WAIT_4H_ACTIVATION ignores events not in its valid set', () => {
    const invalidFor4H: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => !['CRT_4H_ACTIVATED', 'CRT_4H_INVALIDATED', 'TREND_CHANGED', 'TIME_LIMIT_EXCEEDED'].includes(e)
    );

    it.each(invalidFor4H)('WAIT_4H_ACTIVATION + %s → WAIT_4H_ACTIVATION (no-op)', (eventType) => {
      const result = transition(STATE.WAIT_4H_ACTIVATION, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.WAIT_4H_ACTIVATION);
    });
  });

  describe('WAIT_1H_CRT ignores events not in its valid set', () => {
    const invalidFor1H: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => !['CRT_1H_ACTIVATED', 'TREND_CHANGED', 'TIME_LIMIT_EXCEEDED'].includes(e)
    );

    it.each(invalidFor1H)('WAIT_1H_CRT + %s → WAIT_1H_CRT (no-op)', (eventType) => {
      const result = transition(STATE.WAIT_1H_CRT, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.WAIT_1H_CRT);
    });
  });

  describe('WAIT_15M_CRT ignores events not in its valid set', () => {
    const invalidFor15M: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => !['CRT_15M_ACTIVATED', 'TREND_CHANGED', 'TIME_LIMIT_EXCEEDED'].includes(e)
    );

    it.each(invalidFor15M)('WAIT_15M_CRT + %s → WAIT_15M_CRT (no-op)', (eventType) => {
      const result = transition(STATE.WAIT_15M_CRT, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.WAIT_15M_CRT);
    });
  });

  describe('WAIT_5M_ENTRY ignores events not in its valid set', () => {
    const invalidFor5M: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => !['CRT_5M_ENTRY_TRIGGERED', 'TREND_CHANGED', 'TIME_LIMIT_EXCEEDED'].includes(e)
    );

    it.each(invalidFor5M)('WAIT_5M_ENTRY + %s → WAIT_5M_ENTRY (no-op)', (eventType) => {
      const result = transition(STATE.WAIT_5M_ENTRY, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.WAIT_5M_ENTRY);
    });
  });

  describe('POSITION_OPEN ignores all events except POSITION_CLOSED', () => {
    const invalidForOpen: StateMachineEvent['type'][] = ALL_EVENTS.filter(
      (e) => e !== 'POSITION_CLOSED'
    );

    it.each(invalidForOpen)('POSITION_OPEN + %s → POSITION_OPEN (no-op)', (eventType) => {
      const result = transition(STATE.POSITION_OPEN, { type: eventType } as StateMachineEvent);
      expect(result).toBe(STATE.POSITION_OPEN);
    });
  });
});

// ============================================================================
// TREND CHANGE RESETS FROM ANY ACTIVE STATE TO IDLE
// ============================================================================

describe('State Machine - Trend Change Resets', () => {
  const ACTIVE_STATES: StateValue[] = [
    STATE.WAIT_OB_TOUCH,
    STATE.WAIT_4H_ACTIVATION,
    STATE.WAIT_1H_CRT,
    STATE.WAIT_15M_CRT,
    STATE.WAIT_5M_ENTRY,
  ];

  describe('TREND_CHANGED event resets any active state to IDLE', () => {
    it.each(ACTIVE_STATES)(
      'state %i + TREND_CHANGED → IDLE',
      (activeState) => {
        const result = transition(activeState, { type: 'TREND_CHANGED' });
        expect(result).toBe(STATE.IDLE);
      }
    );
  });

  describe('TIME_LIMIT_EXCEEDED event resets any active state to IDLE', () => {
    it.each(ACTIVE_STATES)(
      'state %i + TIME_LIMIT_EXCEEDED → IDLE',
      (activeState) => {
        const result = transition(activeState, { type: 'TIME_LIMIT_EXCEEDED' });
        expect(result).toBe(STATE.IDLE);
      }
    );
  });

  describe('applyTrendChangeInvalidation function', () => {
    it.each(ACTIVE_STATES)(
      'active state %i is reset to IDLE when trendChanged=true',
      (activeState) => {
        const result = applyTrendChangeInvalidation(activeState, true);
        expect(result).toBe(STATE.IDLE);
      }
    );

    it('IDLE remains IDLE when trendChanged=true', () => {
      const result = applyTrendChangeInvalidation(STATE.IDLE, true);
      expect(result).toBe(STATE.IDLE);
    });

    it('POSITION_OPEN remains POSITION_OPEN when trendChanged=true', () => {
      const result = applyTrendChangeInvalidation(STATE.POSITION_OPEN, true);
      expect(result).toBe(STATE.POSITION_OPEN);
    });

    it.each([
      STATE.IDLE,
      STATE.WAIT_OB_TOUCH,
      STATE.WAIT_4H_ACTIVATION,
      STATE.WAIT_1H_CRT,
      STATE.WAIT_15M_CRT,
      STATE.WAIT_5M_ENTRY,
      STATE.POSITION_OPEN,
    ] as StateValue[])(
      'state %i is unchanged when trendChanged=false',
      (state) => {
        const result = applyTrendChangeInvalidation(state, false);
        expect(result).toBe(state);
      }
    );
  });

  describe('TREND_CHANGED does NOT affect IDLE or POSITION_OPEN via transition()', () => {
    it('IDLE + TREND_CHANGED → IDLE (already IDLE, no-op)', () => {
      // TREND_CHANGED is not a valid event for IDLE in the transition map
      const result = transition(STATE.IDLE, { type: 'TREND_CHANGED' });
      expect(result).toBe(STATE.IDLE);
    });

    it('POSITION_OPEN + TREND_CHANGED → POSITION_OPEN (exempt)', () => {
      const result = transition(STATE.POSITION_OPEN, { type: 'TREND_CHANGED' });
      expect(result).toBe(STATE.POSITION_OPEN);
    });
  });
});

// ============================================================================
// HELPER FUNCTION TESTS
// ============================================================================

describe('State Machine - Helper Functions', () => {
  describe('isActiveSetupState', () => {
    it('returns true for all active setup states', () => {
      expect(isActiveSetupState(STATE.WAIT_OB_TOUCH)).toBe(true);
      expect(isActiveSetupState(STATE.WAIT_4H_ACTIVATION)).toBe(true);
      expect(isActiveSetupState(STATE.WAIT_1H_CRT)).toBe(true);
      expect(isActiveSetupState(STATE.WAIT_15M_CRT)).toBe(true);
      expect(isActiveSetupState(STATE.WAIT_5M_ENTRY)).toBe(true);
    });

    it('returns false for IDLE and POSITION_OPEN', () => {
      expect(isActiveSetupState(STATE.IDLE)).toBe(false);
      expect(isActiveSetupState(STATE.POSITION_OPEN)).toBe(false);
    });
  });

  describe('validEventsForState', () => {
    it('IDLE only accepts OB_IDENTIFIED', () => {
      const events = validEventsForState(STATE.IDLE);
      expect(events).toEqual(['OB_IDENTIFIED']);
    });

    it('WAIT_OB_TOUCH accepts OB_TOUCHED, TREND_CHANGED, TIME_LIMIT_EXCEEDED', () => {
      const events = validEventsForState(STATE.WAIT_OB_TOUCH);
      expect(events).toContain('OB_TOUCHED');
      expect(events).toContain('TREND_CHANGED');
      expect(events).toContain('TIME_LIMIT_EXCEEDED');
      expect(events).toHaveLength(3);
    });

    it('WAIT_4H_ACTIVATION accepts CRT_4H_ACTIVATED, CRT_4H_INVALIDATED, TREND_CHANGED, TIME_LIMIT_EXCEEDED', () => {
      const events = validEventsForState(STATE.WAIT_4H_ACTIVATION);
      expect(events).toContain('CRT_4H_ACTIVATED');
      expect(events).toContain('CRT_4H_INVALIDATED');
      expect(events).toContain('TREND_CHANGED');
      expect(events).toContain('TIME_LIMIT_EXCEEDED');
      expect(events).toHaveLength(4);
    });

    it('POSITION_OPEN only accepts POSITION_CLOSED', () => {
      const events = validEventsForState(STATE.POSITION_OPEN);
      expect(events).toEqual(['POSITION_CLOSED']);
    });
  });
});
