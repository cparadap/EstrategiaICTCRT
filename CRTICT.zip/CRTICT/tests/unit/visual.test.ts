import { describe, it, expect } from 'vitest';
import {
  MAX_DRAWINGS,
  drawSwingLine,
  drawObBox,
  drawCrtBox,
  cleanupDrawings,
  manageLineLimit,
  manageBoxLimit,
  initialDrawingArrays,
  CRT_COLORS,
  LineDrawing,
  BoxDrawing,
  DrawingArrays,
} from '../logic/visual';

/**
 * Unit tests for Visual Rendering Logic
 * Validates: Requirements 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 9.9
 */

describe('Visual Rendering - Swing Lines', () => {
  describe('Requirement 9.1: Swing High line (red dashed)', () => {
    it('draws a red dashed line for swing high', () => {
      const arrays = initialDrawingArrays();
      const line = drawSwingLine(1.2500, true, 100, arrays);

      expect(line.color).toBe('red');
      expect(line.style).toBe('dashed');
      expect(line.width).toBe(1);
      expect(line.y1).toBe(1.2500);
      expect(line.y2).toBe(1.2500);
      expect(line.x1).toBe(100);
      expect(line.x2).toBe(150); // bar_index + 50
    });

    it('adds the line to swingLines array', () => {
      const arrays = initialDrawingArrays();
      drawSwingLine(1.3000, true, 200, arrays);

      expect(arrays.swingLines).toHaveLength(1);
      expect(arrays.swingLines[0].color).toBe('red');
    });
  });

  describe('Requirement 9.2: Swing Low line (green dashed)', () => {
    it('draws a green dashed line for swing low', () => {
      const arrays = initialDrawingArrays();
      const line = drawSwingLine(1.1800, false, 50, arrays);

      expect(line.color).toBe('green');
      expect(line.style).toBe('dashed');
      expect(line.width).toBe(1);
      expect(line.y1).toBe(1.1800);
      expect(line.y2).toBe(1.1800);
      expect(line.x1).toBe(50);
      expect(line.x2).toBe(100);
    });

    it('adds the line to swingLines array', () => {
      const arrays = initialDrawingArrays();
      drawSwingLine(1.1800, false, 50, arrays);

      expect(arrays.swingLines).toHaveLength(1);
      expect(arrays.swingLines[0].color).toBe('green');
    });
  });

  describe('Multiple swing lines accumulate', () => {
    it('multiple swing lines are tracked in the array', () => {
      const arrays = initialDrawingArrays();
      drawSwingLine(1.2500, true, 100, arrays);
      drawSwingLine(1.1800, false, 110, arrays);
      drawSwingLine(1.2700, true, 120, arrays);

      expect(arrays.swingLines).toHaveLength(3);
      expect(arrays.swingLines[0].color).toBe('red');
      expect(arrays.swingLines[1].color).toBe('green');
      expect(arrays.swingLines[2].color).toBe('red');
    });
  });
});

describe('Visual Rendering - Order Block Boxes', () => {
  describe('Requirement 9.3: Bullish trend OB (green, transparency 70)', () => {
    it('draws a green box with transparency 70 for bullish trend', () => {
      const arrays = initialDrawingArrays();
      const box = drawObBox(1.2500, 1.2400, 80, 100, 1, arrays);

      expect(box.bgColor).toBe('green');
      expect(box.borderColor).toBe('green');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.2500);
      expect(box.bottom).toBe(1.2400);
      expect(box.left).toBe(80);
      expect(box.right).toBe(100);
      expect(box.borderWidth).toBe(1);
    });

    it('adds the box to obBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawObBox(1.2500, 1.2400, 80, 100, 1, arrays);

      expect(arrays.obBoxes).toHaveLength(1);
    });
  });

  describe('Requirement 9.4: Bearish trend OB (red, transparency 70)', () => {
    it('draws a red box with transparency 70 for bearish trend', () => {
      const arrays = initialDrawingArrays();
      const box = drawObBox(1.2500, 1.2400, 80, 100, -1, arrays);

      expect(box.bgColor).toBe('red');
      expect(box.borderColor).toBe('red');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.2500);
      expect(box.bottom).toBe(1.2400);
      expect(box.left).toBe(80);
      expect(box.right).toBe(100);
      expect(box.borderWidth).toBe(1);
    });

    it('adds the box to obBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawObBox(1.2500, 1.2400, 80, 100, -1, arrays);

      expect(arrays.obBoxes).toHaveLength(1);
      expect(arrays.obBoxes[0].bgColor).toBe('red');
    });
  });
});

describe('Visual Rendering - CRT Boxes', () => {
  describe('Requirement 9.5: 4H CRT box (blue, transparency 70)', () => {
    it('draws a blue box with transparency 70 for 4H CRT', () => {
      const arrays = initialDrawingArrays();
      const box = drawCrtBox(1.3000, 1.2900, 50, 100, CRT_COLORS['4H'], arrays.crt4hBoxes);

      expect(box.bgColor).toBe('blue');
      expect(box.borderColor).toBe('blue');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.3000);
      expect(box.bottom).toBe(1.2900);
      expect(box.left).toBe(50);
      expect(box.right).toBe(100);
    });

    it('adds to crt4hBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawCrtBox(1.3000, 1.2900, 50, 100, CRT_COLORS['4H'], arrays.crt4hBoxes);

      expect(arrays.crt4hBoxes).toHaveLength(1);
    });
  });

  describe('Requirement 9.6: 1H CRT box (yellow, transparency 70)', () => {
    it('draws a yellow box with transparency 70 for 1H CRT', () => {
      const arrays = initialDrawingArrays();
      const box = drawCrtBox(1.2800, 1.2750, 60, 110, CRT_COLORS['1H'], arrays.crt1hBoxes);

      expect(box.bgColor).toBe('yellow');
      expect(box.borderColor).toBe('yellow');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.2800);
      expect(box.bottom).toBe(1.2750);
    });

    it('adds to crt1hBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawCrtBox(1.2800, 1.2750, 60, 110, CRT_COLORS['1H'], arrays.crt1hBoxes);

      expect(arrays.crt1hBoxes).toHaveLength(1);
    });
  });

  describe('Requirement 9.7: 15M CRT box (green, transparency 70)', () => {
    it('draws a green box with transparency 70 for 15M CRT', () => {
      const arrays = initialDrawingArrays();
      const box = drawCrtBox(1.2700, 1.2680, 70, 120, CRT_COLORS['15M'], arrays.crt15mBoxes);

      expect(box.bgColor).toBe('green');
      expect(box.borderColor).toBe('green');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.2700);
      expect(box.bottom).toBe(1.2680);
    });

    it('adds to crt15mBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawCrtBox(1.2700, 1.2680, 70, 120, CRT_COLORS['15M'], arrays.crt15mBoxes);

      expect(arrays.crt15mBoxes).toHaveLength(1);
    });
  });

  describe('Requirement 9.8: 5M CRT box (fuchsia, transparency 70)', () => {
    it('draws a fuchsia box with transparency 70 for 5M CRT', () => {
      const arrays = initialDrawingArrays();
      const box = drawCrtBox(1.2650, 1.2640, 80, 130, CRT_COLORS['5M'], arrays.crt5mBoxes);

      expect(box.bgColor).toBe('fuchsia');
      expect(box.borderColor).toBe('fuchsia');
      expect(box.transparency).toBe(70);
      expect(box.top).toBe(1.2650);
      expect(box.bottom).toBe(1.2640);
    });

    it('adds to crt5mBoxes array', () => {
      const arrays = initialDrawingArrays();
      drawCrtBox(1.2650, 1.2640, 80, 130, CRT_COLORS['5M'], arrays.crt5mBoxes);

      expect(arrays.crt5mBoxes).toHaveLength(1);
    });
  });

  describe('CRT color scheme is correct', () => {
    it('4H maps to blue', () => {
      expect(CRT_COLORS['4H']).toBe('blue');
    });

    it('1H maps to yellow', () => {
      expect(CRT_COLORS['1H']).toBe('yellow');
    });

    it('15M maps to green', () => {
      expect(CRT_COLORS['15M']).toBe('green');
    });

    it('5M maps to fuchsia', () => {
      expect(CRT_COLORS['5M']).toBe('fuchsia');
    });
  });
});

describe('Visual Rendering - Cleanup', () => {
  describe('Requirement 9.9: Cleanup removes all tracked drawings', () => {
    it('clears all drawing arrays when cleanup is called', () => {
      const arrays = initialDrawingArrays();

      // Add various drawings
      drawSwingLine(1.2500, true, 100, arrays);
      drawSwingLine(1.1800, false, 110, arrays);
      drawObBox(1.2500, 1.2400, 80, 100, 1, arrays);
      drawObBox(1.2300, 1.2200, 90, 110, -1, arrays);
      drawCrtBox(1.3000, 1.2900, 50, 100, 'blue', arrays.crt4hBoxes);
      drawCrtBox(1.2800, 1.2750, 60, 110, 'yellow', arrays.crt1hBoxes);
      drawCrtBox(1.2700, 1.2680, 70, 120, 'green', arrays.crt15mBoxes);
      drawCrtBox(1.2650, 1.2640, 80, 130, 'fuchsia', arrays.crt5mBoxes);

      // Verify arrays are populated
      expect(arrays.swingLines).toHaveLength(2);
      expect(arrays.obBoxes).toHaveLength(2);
      expect(arrays.crt4hBoxes).toHaveLength(1);
      expect(arrays.crt1hBoxes).toHaveLength(1);
      expect(arrays.crt15mBoxes).toHaveLength(1);
      expect(arrays.crt5mBoxes).toHaveLength(1);

      // Cleanup
      cleanupDrawings(arrays);

      // All arrays should be empty
      expect(arrays.swingLines).toHaveLength(0);
      expect(arrays.obBoxes).toHaveLength(0);
      expect(arrays.crt4hBoxes).toHaveLength(0);
      expect(arrays.crt1hBoxes).toHaveLength(0);
      expect(arrays.crt15mBoxes).toHaveLength(0);
      expect(arrays.crt5mBoxes).toHaveLength(0);
    });

    it('cleanup on already empty arrays does not throw', () => {
      const arrays = initialDrawingArrays();

      expect(() => cleanupDrawings(arrays)).not.toThrow();

      expect(arrays.swingLines).toHaveLength(0);
      expect(arrays.obBoxes).toHaveLength(0);
    });

    it('arrays can be repopulated after cleanup', () => {
      const arrays = initialDrawingArrays();

      drawSwingLine(1.2500, true, 100, arrays);
      cleanupDrawings(arrays);

      expect(arrays.swingLines).toHaveLength(0);

      drawSwingLine(1.3000, false, 200, arrays);
      expect(arrays.swingLines).toHaveLength(1);
      expect(arrays.swingLines[0].color).toBe('green');
    });
  });
});

describe('Visual Rendering - Drawing Limit Management', () => {
  it('manageLineLimit removes oldest when at capacity (490)', () => {
    const arr: LineDrawing[] = [];

    // Fill to exactly MAX_DRAWINGS
    for (let i = 0; i < MAX_DRAWINGS; i++) {
      arr.push({
        x1: i, y1: 1.0, x2: i + 50, y2: 1.0,
        color: 'red', style: 'dashed', width: 1,
      });
    }

    expect(arr).toHaveLength(MAX_DRAWINGS);
    const firstLine = arr[0];
    expect(firstLine.x1).toBe(0);

    // Managing limit should remove the oldest
    manageLineLimit(arr);

    expect(arr).toHaveLength(MAX_DRAWINGS - 1);
    // The first element should now be what was previously index 1
    expect(arr[0].x1).toBe(1);
  });

  it('manageLineLimit does nothing when below capacity', () => {
    const arr: LineDrawing[] = [
      { x1: 0, y1: 1.0, x2: 50, y2: 1.0, color: 'red', style: 'dashed', width: 1 },
      { x1: 1, y1: 1.0, x2: 51, y2: 1.0, color: 'green', style: 'dashed', width: 1 },
    ];

    manageLineLimit(arr);

    expect(arr).toHaveLength(2);
    expect(arr[0].x1).toBe(0);
  });

  it('manageBoxLimit removes oldest when at capacity (490)', () => {
    const arr: BoxDrawing[] = [];

    // Fill to exactly MAX_DRAWINGS
    for (let i = 0; i < MAX_DRAWINGS; i++) {
      arr.push({
        left: i, top: 1.5, right: i + 10, bottom: 1.4,
        borderColor: 'blue', bgColor: 'blue', transparency: 70, borderWidth: 1,
      });
    }

    expect(arr).toHaveLength(MAX_DRAWINGS);

    manageBoxLimit(arr);

    expect(arr).toHaveLength(MAX_DRAWINGS - 1);
    expect(arr[0].left).toBe(1);
  });

  it('manageBoxLimit does nothing when below capacity', () => {
    const arr: BoxDrawing[] = [
      { left: 0, top: 1.5, right: 10, bottom: 1.4, borderColor: 'green', bgColor: 'green', transparency: 70, borderWidth: 1 },
    ];

    manageBoxLimit(arr);

    expect(arr).toHaveLength(1);
    expect(arr[0].left).toBe(0);
  });

  it('drawSwingLine manages limit before adding new line', () => {
    const arrays = initialDrawingArrays();

    // Fill swing lines to capacity
    for (let i = 0; i < MAX_DRAWINGS; i++) {
      arrays.swingLines.push({
        x1: i, y1: 1.0, x2: i + 50, y2: 1.0,
        color: 'red', style: 'dashed', width: 1,
      });
    }

    expect(arrays.swingLines).toHaveLength(MAX_DRAWINGS);

    // Drawing a new line should remove the oldest first, then add
    drawSwingLine(2.0000, true, 999, arrays);

    // Should still be at MAX_DRAWINGS (removed 1, added 1)
    expect(arrays.swingLines).toHaveLength(MAX_DRAWINGS);
    // The last element should be the new one
    expect(arrays.swingLines[MAX_DRAWINGS - 1].x1).toBe(999);
    // The first element should be what was previously index 1
    expect(arrays.swingLines[0].x1).toBe(1);
  });

  it('drawObBox manages limit before adding new box', () => {
    const arrays = initialDrawingArrays();

    // Fill OB boxes to capacity
    for (let i = 0; i < MAX_DRAWINGS; i++) {
      arrays.obBoxes.push({
        left: i, top: 1.5, right: i + 10, bottom: 1.4,
        borderColor: 'green', bgColor: 'green', transparency: 70, borderWidth: 1,
      });
    }

    expect(arrays.obBoxes).toHaveLength(MAX_DRAWINGS);

    drawObBox(2.0, 1.9, 500, 550, 1, arrays);

    expect(arrays.obBoxes).toHaveLength(MAX_DRAWINGS);
    expect(arrays.obBoxes[MAX_DRAWINGS - 1].left).toBe(500);
    expect(arrays.obBoxes[0].left).toBe(1);
  });

  it('drawCrtBox manages limit before adding new box', () => {
    const arrays = initialDrawingArrays();

    // Fill 4H CRT boxes to capacity
    for (let i = 0; i < MAX_DRAWINGS; i++) {
      arrays.crt4hBoxes.push({
        left: i, top: 1.5, right: i + 10, bottom: 1.4,
        borderColor: 'blue', bgColor: 'blue', transparency: 70, borderWidth: 1,
      });
    }

    expect(arrays.crt4hBoxes).toHaveLength(MAX_DRAWINGS);

    drawCrtBox(2.0, 1.9, 500, 550, 'blue', arrays.crt4hBoxes);

    expect(arrays.crt4hBoxes).toHaveLength(MAX_DRAWINGS);
    expect(arrays.crt4hBoxes[MAX_DRAWINGS - 1].left).toBe(500);
    expect(arrays.crt4hBoxes[0].left).toBe(1);
  });
});
