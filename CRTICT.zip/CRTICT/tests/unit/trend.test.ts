import { describe, it, expect } from 'vitest';
import { detectTrend, detectTrendSequence, TrendState } from '../logic/trend';

describe('Trend Detection', () => {
  const defaultState: TrendState = { trend: 0, prevTrend: 0 };

  describe('Basic trend classification', () => {
    it('close > ema50 → bullish (1)', () => {
      const result = detectTrend(1.1050, 1.1000, defaultState);
      expect(result.trend).toBe(1);
    });

    it('close < ema50 → bearish (-1)', () => {
      const result = detectTrend(1.0950, 1.1000, defaultState);
      expect(result.trend).toBe(-1);
    });

    it('close == ema50 → trend unchanged (maintains previous value)', () => {
      // Starting from bullish
      const bullishState: TrendState = { trend: 1, prevTrend: 1 };
      const result = detectTrend(1.1000, 1.1000, bullishState);
      expect(result.trend).toBe(1); // stays bullish

      // Starting from bearish
      const bearishState: TrendState = { trend: -1, prevTrend: -1 };
      const result2 = detectTrend(1.1000, 1.1000, bearishState);
      expect(result2.trend).toBe(-1); // stays bearish

      // Starting from uninitialized
      const result3 = detectTrend(1.1000, 1.1000, defaultState);
      expect(result3.trend).toBe(0); // stays 0
    });
  });

  describe('NA values (null/undefined) → no change', () => {
    it('null close → no change', () => {
      const bullishState: TrendState = { trend: 1, prevTrend: 1 };
      const result = detectTrend(null, 1.1000, bullishState);
      expect(result.trend).toBe(1);
      expect(result.trendChanged).toBe(false);
    });

    it('null ema50 → no change', () => {
      const bearishState: TrendState = { trend: -1, prevTrend: -1 };
      const result = detectTrend(1.1000, null, bearishState);
      expect(result.trend).toBe(-1);
      expect(result.trendChanged).toBe(false);
    });

    it('both null → no change', () => {
      const result = detectTrend(null, null, defaultState);
      expect(result.trend).toBe(0);
      expect(result.trendChanged).toBe(false);
    });

    it('undefined close → no change', () => {
      const bullishState: TrendState = { trend: 1, prevTrend: 0 };
      const result = detectTrend(undefined, 1.1000, bullishState);
      expect(result.trend).toBe(1);
      expect(result.trendChanged).toBe(false);
    });

    it('undefined ema50 → no change', () => {
      const result = detectTrend(1.1000, undefined, defaultState);
      expect(result.trend).toBe(0);
      expect(result.trendChanged).toBe(false);
    });

    it('first bar with na values does not alter initial state', () => {
      const results = detectTrendSequence([
        { close: null, ema50: null },
        { close: null, ema50: 1.1000 },
        { close: 1.1000, ema50: null },
      ]);
      // All bars should leave trend at 0
      expect(results[0].trend).toBe(0);
      expect(results[1].trend).toBe(0);
      expect(results[2].trend).toBe(0);
    });
  });

  describe('Trend change detection', () => {
    it('detects change from uninitialized to bullish', () => {
      const result = detectTrend(1.1050, 1.1000, defaultState);
      expect(result.trendChanged).toBe(true);
      expect(result.prevTrend).toBe(1);
    });

    it('detects change from uninitialized to bearish', () => {
      const result = detectTrend(1.0950, 1.1000, defaultState);
      expect(result.trendChanged).toBe(true);
      expect(result.prevTrend).toBe(-1);
    });

    it('no change when trend stays bullish', () => {
      const bullishState: TrendState = { trend: 1, prevTrend: 1 };
      const result = detectTrend(1.1100, 1.1000, bullishState);
      expect(result.trendChanged).toBe(false);
    });

    it('no change when trend stays bearish', () => {
      const bearishState: TrendState = { trend: -1, prevTrend: -1 };
      const result = detectTrend(1.0900, 1.1000, bearishState);
      expect(result.trendChanged).toBe(false);
    });

    it('detects change from bullish to bearish', () => {
      const bullishState: TrendState = { trend: 1, prevTrend: 1 };
      const result = detectTrend(1.0950, 1.1000, bullishState);
      expect(result.trend).toBe(-1);
      expect(result.trendChanged).toBe(true);
    });

    it('detects change from bearish to bullish', () => {
      const bearishState: TrendState = { trend: -1, prevTrend: -1 };
      const result = detectTrend(1.1050, 1.1000, bearishState);
      expect(result.trend).toBe(1);
      expect(result.trendChanged).toBe(true);
    });
  });

  describe('Transitions: bullish → bearish → bullish', () => {
    it('full transition sequence', () => {
      const results = detectTrendSequence([
        { close: 1.1050, ema50: 1.1000 }, // bullish
        { close: 1.1100, ema50: 1.1000 }, // still bullish
        { close: 1.0950, ema50: 1.1000 }, // bearish (change)
        { close: 1.0900, ema50: 1.1000 }, // still bearish
        { close: 1.1050, ema50: 1.1000 }, // bullish again (change)
      ]);

      // Bar 0: uninitialized → bullish
      expect(results[0].trend).toBe(1);
      expect(results[0].trendChanged).toBe(true);

      // Bar 1: bullish → bullish (no change)
      expect(results[1].trend).toBe(1);
      expect(results[1].trendChanged).toBe(false);

      // Bar 2: bullish → bearish (change)
      expect(results[2].trend).toBe(-1);
      expect(results[2].trendChanged).toBe(true);

      // Bar 3: bearish → bearish (no change)
      expect(results[3].trend).toBe(-1);
      expect(results[3].trendChanged).toBe(false);

      // Bar 4: bearish → bullish (change)
      expect(results[4].trend).toBe(1);
      expect(results[4].trendChanged).toBe(true);
    });

    it('transition with exact EMA50 == close in between', () => {
      const results = detectTrendSequence([
        { close: 1.1050, ema50: 1.1000 }, // bullish
        { close: 1.1000, ema50: 1.1000 }, // exact equal → stays bullish
        { close: 1.0950, ema50: 1.1000 }, // bearish (change)
        { close: 1.1000, ema50: 1.1000 }, // exact equal → stays bearish
        { close: 1.1050, ema50: 1.1000 }, // bullish (change)
      ]);

      expect(results[0].trend).toBe(1);
      expect(results[1].trend).toBe(1); // unchanged
      expect(results[1].trendChanged).toBe(false);
      expect(results[2].trend).toBe(-1);
      expect(results[2].trendChanged).toBe(true);
      expect(results[3].trend).toBe(-1); // unchanged
      expect(results[3].trendChanged).toBe(false);
      expect(results[4].trend).toBe(1);
      expect(results[4].trendChanged).toBe(true);
    });
  });

  describe('Doji candles', () => {
    it('doji candle (open == close) does not affect trend since trend only uses close vs ema50', () => {
      // A doji candle where close happens to be above ema50 → still bullish
      const result = detectTrend(1.1050, 1.1000, defaultState);
      // The fact that open == close (doji) is irrelevant to trend detection
      // Trend only cares about close vs ema50
      expect(result.trend).toBe(1);
    });

    it('doji candle below ema50 → bearish', () => {
      const result = detectTrend(1.0950, 1.1000, defaultState);
      expect(result.trend).toBe(-1);
    });

    it('doji candle exactly at ema50 → trend unchanged', () => {
      const bullishState: TrendState = { trend: 1, prevTrend: 1 };
      const result = detectTrend(1.1000, 1.1000, bullishState);
      expect(result.trend).toBe(1); // stays bullish
      expect(result.trendChanged).toBe(false);
    });
  });

  describe('Edge cases', () => {
    it('very small difference between close and ema50 still classifies correctly', () => {
      const result = detectTrend(1.10001, 1.10000, defaultState);
      expect(result.trend).toBe(1); // bullish

      const result2 = detectTrend(1.09999, 1.10000, defaultState);
      expect(result2.trend).toBe(-1); // bearish
    });

    it('large price values work correctly', () => {
      const result = detectTrend(50000.50, 50000.00, defaultState);
      expect(result.trend).toBe(1);
    });

    it('sequence starting with na then valid data', () => {
      const results = detectTrendSequence([
        { close: null, ema50: null },     // na → no change
        { close: null, ema50: 1.1000 },   // na close → no change
        { close: 1.1050, ema50: 1.1000 }, // first valid → bullish
        { close: 1.0950, ema50: 1.1000 }, // bearish
      ]);

      expect(results[0].trend).toBe(0);
      expect(results[0].trendChanged).toBe(false);
      expect(results[1].trend).toBe(0);
      expect(results[1].trendChanged).toBe(false);
      expect(results[2].trend).toBe(1);
      expect(results[2].trendChanged).toBe(true);
      expect(results[3].trend).toBe(-1);
      expect(results[3].trendChanged).toBe(true);
    });

    it('prevTrend is updated correctly after each bar', () => {
      const results = detectTrendSequence([
        { close: 1.1050, ema50: 1.1000 }, // bullish
        { close: 1.0950, ema50: 1.1000 }, // bearish
      ]);

      expect(results[0].prevTrend).toBe(1); // prevTrend updated to current
      expect(results[1].prevTrend).toBe(-1); // prevTrend updated to current
    });
  });
});
