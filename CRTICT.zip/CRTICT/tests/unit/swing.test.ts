import { describe, it, expect } from 'vitest';
import {
  detectSwing,
  detectSwingSequence,
  initialSwingState,
  Candle,
  SwingState,
} from '../logic/swing';

/**
 * Unit tests for Swing Detection Logic
 * Validates: Requirements 2.1, 2.2, 2.3, 2.4
 */

// Helper to create a bullish candle with specific high/low
function bullish(open: number, close: number, low?: number, high?: number): Candle {
  return {
    open,
    close,
    low: low ?? open - 5,
    high: high ?? close + 5,
  };
}

// Helper to create a bearish candle with specific high/low
function bearish(open: number, close: number, low?: number, high?: number): Candle {
  return {
    open,
    close,
    low: low ?? close - 5,
    high: high ?? open + 5,
  };
}

// Helper to create a doji candle
function doji(price: number, low?: number, high?: number): Candle {
  return {
    open: price,
    close: price,
    low: low ?? price - 5,
    high: high ?? price + 5,
  };
}

describe('Swing Detection - Bullish Trend', () => {
  const BULLISH_TREND = 1;

  describe('Requirement 2.1: Swing Low (≥3 bearish pullback + ≥3 bullish impulse)', () => {
    it('exactly 3 bearish + 3 bullish → swing low detected', () => {
      const candles: Candle[] = [
        bearish(110, 105, 100, 115),  // bearish 1, low=100
        bearish(105, 100, 95, 110),   // bearish 2, low=95
        bearish(100, 95, 90, 105),    // bearish 3, low=90
        bullish(95, 100, 90, 105),    // bullish 1
        bullish(100, 105, 95, 110),   // bullish 2
        bullish(105, 110, 100, 115),  // bullish 3 → triggers swing low
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // Swing low should be detected on the 6th candle (index 5)
      expect(results[5].newSwingLow).toBe(true);
      // Swing low price = lowest low in the pullback (bearish) group
      // Pullback lows are tracked: 100, 95, 90 → min = 90
      expect(results[5].swingLowPrice).toBe(90);
    });

    it('more than 3 each (5 bearish + 4 bullish) → swing low detected', () => {
      const candles: Candle[] = [
        bearish(120, 115, 110, 125),  // bearish 1, low=110
        bearish(115, 110, 105, 120),  // bearish 2, low=105
        bearish(110, 105, 100, 115),  // bearish 3, low=100
        bearish(105, 100, 95, 110),   // bearish 4, low=95
        bearish(100, 95, 88, 105),    // bearish 5, low=88
        bullish(95, 100, 90, 105),    // bullish 1
        bullish(100, 105, 95, 110),   // bullish 2
        bullish(105, 110, 100, 115),  // bullish 3 → triggers swing low
        bullish(110, 115, 105, 120),  // bullish 4 (after trigger)
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // Swing low detected on bullish candle #3 (index 7)
      expect(results[7].newSwingLow).toBe(true);
      // Lowest low in pullback group: min(110, 105, 100, 95, 88) = 88
      expect(results[7].swingLowPrice).toBe(88);
      // No additional swing on candle 4
      expect(results[8].newSwingLow).toBe(false);
    });

    it('only 2 bearish + 3 bullish → no swing low (pullback too short)', () => {
      const candles: Candle[] = [
        bearish(110, 105, 100, 115),  // bearish 1
        bearish(105, 100, 95, 110),   // bearish 2
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        bullish(110, 115, 105, 120),  // bullish 3
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // No swing low because only 2 bearish candles preceded
      for (const r of results) {
        expect(r.newSwingLow).toBe(false);
      }
    });

    it('3 bearish + only 2 bullish → no swing low (impulse too short)', () => {
      const candles: Candle[] = [
        bearish(110, 105, 100, 115),
        bearish(105, 100, 95, 110),
        bearish(100, 95, 90, 105),
        bullish(95, 100, 90, 105),
        bullish(100, 105, 95, 110),
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      for (const r of results) {
        expect(r.newSwingLow).toBe(false);
      }
    });
  });

  describe('Requirement 2.2: Swing High (≥3 bullish impulse + ≥3 bearish)', () => {
    it('exactly 3 bullish + 3 bearish → swing high detected', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        bullish(110, 115, 105, 120),  // bullish 3, high=120 (last bull high)
        bearish(115, 110, 105, 120),  // bearish 1
        bearish(110, 105, 100, 115),  // bearish 2
        bearish(105, 100, 95, 110),   // bearish 3 → triggers swing high
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // Swing high detected on bearish candle #3 (index 5)
      expect(results[5].newSwingHigh).toBe(true);
      // Swing high = high of last bullish candle before bearish sequence = 120
      expect(results[5].swingHighPrice).toBe(120);
    });

    it('more than 3 bullish (5) + 4 bearish → swing high detected', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),
        bullish(105, 110, 100, 115),
        bullish(110, 115, 105, 120),
        bullish(115, 120, 110, 125),
        bullish(120, 125, 115, 132),  // last bullish, high=132
        bearish(125, 120, 115, 130),  // bearish 1
        bearish(120, 115, 110, 125),  // bearish 2
        bearish(115, 110, 105, 120),  // bearish 3 → triggers swing high
        bearish(110, 105, 100, 115),  // bearish 4
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // Swing high on bearish #3 (index 7)
      expect(results[7].newSwingHigh).toBe(true);
      // Last bullish candle high = 132
      expect(results[7].swingHighPrice).toBe(132);
    });

    it('single bullish candle between groups does not satisfy ≥3', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        bearish(110, 105, 100, 115),  // bearish 1 (interrupts bullish)
        bullish(105, 110, 100, 115),  // bullish 1 (restart)
        bearish(110, 105, 100, 115),  // bearish 1 (interrupts again)
        bearish(105, 100, 95, 110),   // bearish 2
        bearish(100, 95, 90, 105),    // bearish 3
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // No swing high because no group of ≥3 bullish was followed by ≥3 bearish
      // The bullish count never reached 3 before being interrupted
      for (const r of results) {
        expect(r.newSwingHigh).toBe(false);
      }
    });
  });

  describe('Doji interruptions', () => {
    it('doji resets counters: 2 bearish + doji + 3 bearish + 3 bullish → swing low detected (fresh count after doji)', () => {
      const candles: Candle[] = [
        bearish(110, 105, 100, 115),  // bearish 1
        bearish(105, 100, 95, 110),   // bearish 2
        doji(100, 90, 110),           // doji → resets counters
        bearish(100, 95, 88, 105),    // bearish 1 (fresh)
        bearish(95, 90, 83, 100),     // bearish 2
        bearish(90, 85, 78, 95),      // bearish 3
        bullish(85, 90, 80, 95),      // bullish 1
        bullish(90, 95, 85, 100),     // bullish 2
        bullish(95, 100, 90, 105),    // bullish 3 → triggers swing low
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // Swing low should be detected on the last candle
      expect(results[8].newSwingLow).toBe(true);
      // Pullback lows from the fresh bearish group: 88, 83, 78 → min = 78
      expect(results[8].swingLowPrice).toBe(78);
    });

    it('doji resets counters: 3 bearish + doji + 2 bearish + 3 bullish → no swing low (only 2 bearish after reset)', () => {
      const candles: Candle[] = [
        bearish(110, 105, 100, 115),
        bearish(105, 100, 95, 110),
        bearish(100, 95, 90, 105),
        doji(95, 85, 100),            // doji → resets counters
        bearish(95, 90, 85, 100),     // bearish 1 (fresh)
        bearish(90, 85, 80, 95),      // bearish 2
        bullish(85, 90, 80, 95),      // bullish 1
        bullish(90, 95, 85, 100),     // bullish 2
        bullish(95, 100, 90, 105),    // bullish 3
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // No swing low because after doji reset, only 2 bearish preceded
      for (const r of results) {
        expect(r.newSwingLow).toBe(false);
      }
    });

    it('doji between bullish group resets: 3 bullish + doji + 2 bullish + 3 bearish → no swing high', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),
        bullish(105, 110, 100, 115),
        bullish(110, 115, 105, 120),
        doji(115, 110, 120),          // doji → resets counters
        bullish(115, 120, 110, 125),  // bullish 1 (fresh)
        bullish(120, 125, 115, 130),  // bullish 2
        bearish(125, 120, 115, 130),  // bearish 1
        bearish(120, 115, 110, 125),  // bearish 2
        bearish(115, 110, 105, 120),  // bearish 3
      ];

      const results = detectSwingSequence(candles, BULLISH_TREND);

      // No swing high because after doji, only 2 bullish preceded the bearish group
      for (const r of results) {
        expect(r.newSwingHigh).toBe(false);
      }
    });
  });
});

describe('Swing Detection - Bearish Trend', () => {
  const BEARISH_TREND = -1;

  describe('Requirement 2.3: Swing High (≥3 bullish pullback + ≥3 bearish impulse)', () => {
    it('exactly 3 bullish + 3 bearish → swing high detected', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 112),   // bullish 1, high=112
        bullish(105, 110, 100, 118),  // bullish 2, high=118
        bullish(110, 115, 105, 122),  // bullish 3, high=122
        bearish(115, 110, 105, 120),  // bearish 1
        bearish(110, 105, 100, 115),  // bearish 2
        bearish(105, 100, 95, 110),   // bearish 3 → triggers swing high
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // Swing high detected on bearish candle #3 (index 5)
      expect(results[5].newSwingHigh).toBe(true);
      // Swing high = highest high in pullback (bullish) group
      // Pullback highs: 112, 118, 122 → max = 122
      expect(results[5].swingHighPrice).toBe(122);
    });

    it('more than 3 each (4 bullish + 5 bearish) → swing high detected', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 108),   // bullish 1, high=108
        bullish(105, 110, 100, 115),  // bullish 2, high=115
        bullish(110, 115, 105, 125),  // bullish 3, high=125
        bullish(115, 120, 110, 128),  // bullish 4, high=128
        bearish(120, 115, 110, 125),  // bearish 1
        bearish(115, 110, 105, 120),  // bearish 2
        bearish(110, 105, 100, 115),  // bearish 3 → triggers swing high
        bearish(105, 100, 95, 110),   // bearish 4
        bearish(100, 95, 90, 105),    // bearish 5
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // Swing high on bearish #3 (index 6)
      expect(results[6].newSwingHigh).toBe(true);
      // Highest high in pullback: max(108, 115, 125, 128) = 128
      expect(results[6].swingHighPrice).toBe(128);
    });
  });

  describe('Requirement 2.4: Swing Low (≥3 bearish impulse + ≥3 bullish)', () => {
    it('exactly 3 bearish + 3 bullish → swing low detected', () => {
      const candles: Candle[] = [
        bearish(115, 110, 105, 120),  // bearish 1, low=105
        bearish(110, 105, 100, 115),  // bearish 2, low=100
        bearish(105, 100, 95, 110),   // bearish 3, low=95 (last bear low)
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        bullish(110, 115, 105, 120),  // bullish 3 → triggers swing low
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // Swing low detected on bullish candle #3 (index 5)
      expect(results[5].newSwingLow).toBe(true);
      // Swing low = low of last bearish candle before bullish sequence = 95
      expect(results[5].swingLowPrice).toBe(95);
    });

    it('more than 3 bearish (5) + 3 bullish → swing low detected', () => {
      const candles: Candle[] = [
        bearish(125, 120, 115, 130),
        bearish(120, 115, 110, 125),
        bearish(115, 110, 105, 120),
        bearish(110, 105, 100, 115),
        bearish(105, 100, 92, 110),   // last bearish, low=92
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        bullish(110, 115, 105, 120),  // bullish 3 → triggers swing low
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // Swing low on bullish #3 (index 7)
      expect(results[7].newSwingLow).toBe(true);
      // Low of last bearish candle = 92
      expect(results[7].swingLowPrice).toBe(92);
    });

    it('single bearish candle between bullish groups does not satisfy ≥3', () => {
      const candles: Candle[] = [
        bearish(115, 110, 105, 120),  // bearish 1
        bearish(110, 105, 100, 115),  // bearish 2
        bullish(105, 110, 100, 115),  // bullish (interrupts)
        bearish(110, 105, 100, 115),  // bearish 1 (restart)
        bullish(105, 110, 100, 115),  // bullish 1
        bullish(110, 115, 105, 120),  // bullish 2
        bullish(115, 120, 110, 125),  // bullish 3
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // No swing low: bearish count never reached 3 before being interrupted
      // After the interruption, only 1 bearish preceded the bullish group
      for (const r of results) {
        expect(r.newSwingLow).toBe(false);
      }
    });
  });

  describe('Doji interruptions in bearish trend', () => {
    it('doji resets counters: 2 bullish + doji + 3 bullish + 3 bearish → swing high detected', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),   // bullish 1
        bullish(105, 110, 100, 115),  // bullish 2
        doji(110, 105, 115),          // doji → resets counters
        bullish(110, 115, 105, 120),  // bullish 1 (fresh), high=120
        bullish(115, 120, 110, 127),  // bullish 2, high=127
        bullish(120, 125, 115, 130),  // bullish 3, high=130
        bearish(125, 120, 115, 130),  // bearish 1
        bearish(120, 115, 110, 125),  // bearish 2
        bearish(115, 110, 105, 120),  // bearish 3 → triggers swing high
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // Swing high detected on last candle
      expect(results[8].newSwingHigh).toBe(true);
      // Pullback highs from fresh bullish group: 120, 127, 130 → max = 130
      expect(results[8].swingHighPrice).toBe(130);
    });

    it('doji resets counters: 3 bullish + doji + 2 bullish + 3 bearish → no swing high', () => {
      const candles: Candle[] = [
        bullish(100, 105, 95, 110),
        bullish(105, 110, 100, 115),
        bullish(110, 115, 105, 120),
        doji(115, 110, 120),          // doji → resets counters
        bullish(115, 120, 110, 125),  // bullish 1 (fresh)
        bullish(120, 125, 115, 130),  // bullish 2
        bearish(125, 120, 115, 130),  // bearish 1
        bearish(120, 115, 110, 125),  // bearish 2
        bearish(115, 110, 105, 120),  // bearish 3
      ];

      const results = detectSwingSequence(candles, BEARISH_TREND);

      // No swing high because after doji, only 2 bullish preceded
      for (const r of results) {
        expect(r.newSwingHigh).toBe(false);
      }
    });
  });
});

describe('Swing Detection - Edge Cases', () => {
  it('no swing detected when trend is 0 (uninitialized)', () => {
    const candles: Candle[] = [
      bearish(110, 105, 100, 115),
      bearish(105, 100, 95, 110),
      bearish(100, 95, 90, 105),
      bullish(95, 100, 90, 105),
      bullish(100, 105, 95, 110),
      bullish(105, 110, 100, 115),
    ];

    const results = detectSwingSequence(candles, 0);

    // No swings when trend is uninitialized
    for (const r of results) {
      expect(r.newSwingHigh).toBe(false);
      expect(r.newSwingLow).toBe(false);
    }
  });

  it('consecutive counters accumulate correctly across calls', () => {
    const state = initialSwingState();

    // Process 3 bearish candles one at a time
    let result = detectSwing(bearish(110, 105, 100, 115), 1, state);
    expect(result.state.consecBear).toBe(1);

    result = detectSwing(bearish(105, 100, 95, 110), 1, result.state);
    expect(result.state.consecBear).toBe(2);

    result = detectSwing(bearish(100, 95, 90, 105), 1, result.state);
    expect(result.state.consecBear).toBe(3);
    expect(result.state.consecBull).toBe(0);

    // Now process 3 bullish candles
    result = detectSwing(bullish(95, 100, 90, 105), 1, result.state);
    expect(result.state.consecBull).toBe(1);
    expect(result.state.consecBear).toBe(0);
    expect(result.state.prevConsecBear).toBe(3);

    result = detectSwing(bullish(100, 105, 95, 110), 1, result.state);
    expect(result.state.consecBull).toBe(2);

    result = detectSwing(bullish(105, 110, 100, 115), 1, result.state);
    expect(result.state.consecBull).toBe(3);
    expect(result.newSwingLow).toBe(true);
  });

  it('swing detection only fires once at exactly count == 3', () => {
    const candles: Candle[] = [
      bearish(110, 105, 100, 115),
      bearish(105, 100, 95, 110),
      bearish(100, 95, 90, 105),
      bullish(95, 100, 90, 105),
      bullish(100, 105, 95, 110),
      bullish(105, 110, 100, 115),  // count=3, triggers
      bullish(110, 115, 105, 120),  // count=4, no trigger
      bullish(115, 120, 110, 125),  // count=5, no trigger
    ];

    const results = detectSwingSequence(candles, 1);

    expect(results[5].newSwingLow).toBe(true);
    expect(results[6].newSwingLow).toBe(false);
    expect(results[7].newSwingLow).toBe(false);
  });
});
