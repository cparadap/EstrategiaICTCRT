import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { detectSwingSequence } from '../logic/swing';
import type { Candle } from '../logic/swing';
import {
  bearishThenBullishSequenceArb,
  pullbackImpulseSequenceArb,
  impulsePullbackSequenceArb,
} from '../generators/candle-sequence.gen';

/**
 * Helper: checks that a candle is strictly bullish (close > open).
 */
function isBullish(c: Candle): boolean {
  return c.close > c.open;
}

/**
 * Helper: checks that a candle is strictly bearish (close < open).
 */
function isBearish(c: Candle): boolean {
  return c.close < c.open;
}

/**
 * Helper: validates that a sequence has the expected pattern of
 * N bearish candles followed by M bullish candles (no dojis).
 */
function isValidBearishThenBullish(sequence: Candle[], bearishCount: number, bullishCount: number): boolean {
  if (sequence.length < bearishCount + bullishCount) return false;
  for (let i = 0; i < bearishCount; i++) {
    if (!isBearish(sequence[i])) return false;
  }
  for (let i = bearishCount; i < bearishCount + bullishCount; i++) {
    if (!isBullish(sequence[i])) return false;
  }
  return true;
}

/**
 * Helper: validates that a sequence has the expected pattern of
 * N bullish candles followed by M bearish candles (no dojis).
 */
function isValidBullishThenBearish(sequence: Candle[], bullishCount: number, bearishCount: number): boolean {
  if (sequence.length < bullishCount + bearishCount) return false;
  for (let i = 0; i < bullishCount; i++) {
    if (!isBullish(sequence[i])) return false;
  }
  for (let i = bullishCount; i < bullishCount + bearishCount; i++) {
    if (!isBearish(sequence[i])) return false;
  }
  return true;
}

describe('Feature: ict-crt-strategy, Property 2: Swing Point Identification', () => {
  /**
   * **Validates: Requirements 2.1, 2.2, 2.3, 2.4**
   *
   * Property 2: Swing Point Identification
   * For any sequence of 4H candles where at least 3 consecutive contrary candles (pullback)
   * are followed by at least 3 consecutive trend-direction candles (impulse), the strategy
   * shall identify the extreme price within the pullback group as the swing point.
   */

  describe('Requirement 2.1: Bullish trend - Swing Low identification', () => {
    it('≥3 bearish (pullback) followed by ≥3 bullish (impulse) identifies lowest low as Swing_Low', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = 1; // bullish
            const results = detectSwingSequence(sequence, trend);

            // The swing low should be detected on the 3rd bullish candle
            const swingLowResults = results.filter((r) => r.newSwingLow);
            expect(swingLowResults.length).toBeGreaterThanOrEqual(1);

            // The swing low price should be the lowest low in the bearish (pullback) group
            const pullbackCandles = sequence.slice(0, bearishCount);
            const expectedSwingLow = Math.min(...pullbackCandles.map((c) => c.low));

            const detectedSwingLow = swingLowResults[0].swingLowPrice;
            expect(detectedSwingLow).toBeCloseTo(expectedSwingLow, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 2.2: Bullish trend - Swing High identification', () => {
    it('≥3 bullish (impulse) followed by ≥3 bearish identifies last bullish high as Swing_High', () => {
      fc.assert(
        fc.property(
          impulsePullbackSequenceArb(3, 3),
          ({ sequence, bullishCount, bearishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBullishThenBearish(sequence, bullishCount, bearishCount)) return;

            const trend = 1; // bullish
            const results = detectSwingSequence(sequence, trend);

            // The swing high should be detected on the 3rd bearish candle
            const swingHighResults = results.filter((r) => r.newSwingHigh);
            expect(swingHighResults.length).toBeGreaterThanOrEqual(1);

            // The swing high price should be the high of the last bullish candle
            // before the bearish sequence started
            const lastBullishCandle = sequence[bullishCount - 1];
            const expectedSwingHigh = lastBullishCandle.high;

            const detectedSwingHigh = swingHighResults[0].swingHighPrice;
            expect(detectedSwingHigh).toBeCloseTo(expectedSwingHigh, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 2.3: Bearish trend - Swing High identification', () => {
    it('≥3 bullish (pullback) followed by ≥3 bearish (impulse) identifies highest high as Swing_High', () => {
      fc.assert(
        fc.property(
          impulsePullbackSequenceArb(3, 3),
          ({ sequence, bullishCount, bearishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBullishThenBearish(sequence, bullishCount, bearishCount)) return;

            const trend = -1; // bearish

            const results = detectSwingSequence(sequence, trend);

            // The swing high should be detected on the 3rd bearish candle
            const swingHighResults = results.filter((r) => r.newSwingHigh);
            expect(swingHighResults.length).toBeGreaterThanOrEqual(1);

            // The swing high price should be the highest high in the bullish (pullback) group
            const pullbackCandles = sequence.slice(0, bullishCount);
            const expectedSwingHigh = Math.max(...pullbackCandles.map((c) => c.high));

            const detectedSwingHigh = swingHighResults[0].swingHighPrice;
            expect(detectedSwingHigh).toBeCloseTo(expectedSwingHigh, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 2.4: Bearish trend - Swing Low identification', () => {
    it('≥3 bearish (impulse) followed by ≥3 bullish identifies last bearish low as Swing_Low', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = -1; // bearish

            const results = detectSwingSequence(sequence, trend);

            // The swing low should be detected on the 3rd bullish candle
            const swingLowResults = results.filter((r) => r.newSwingLow);
            expect(swingLowResults.length).toBeGreaterThanOrEqual(1);

            // The swing low price should be the low of the last bearish candle
            // before the bullish sequence started
            const lastBearishCandle = sequence[bearishCount - 1];
            const expectedSwingLow = lastBearishCandle.low;

            const detectedSwingLow = swingLowResults[0].swingLowPrice;
            expect(detectedSwingLow).toBeCloseTo(expectedSwingLow, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('General swing detection properties', () => {
    it('swing detection is triggered exactly when consecutive count reaches 3', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = 1; // bullish
            const results = detectSwingSequence(sequence, trend);

            // Swing low should be detected at the index where the 3rd bullish candle is
            // That's at index bearishCount + 2 (0-indexed: bearishCount is first bullish, +2 = third)
            const swingLowIndex = bearishCount + 2; // 3rd bullish candle (0-indexed)
            if (swingLowIndex < results.length) {
              expect(results[swingLowIndex].newSwingLow).toBe(true);
            }
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no swing is detected with fewer than 3 contrary candles', () => {
      fc.assert(
        fc.property(
          bearishThenBullishSequenceArb(2, 3), // only 2 bearish, not enough
          (sequence) => {
            // Skip if dojis were introduced
            const hasDoji = sequence.some((c) => c.close === c.open);
            if (hasDoji) return;

            const trend = 1; // bullish
            const results = detectSwingSequence(sequence, trend);

            // No swing low should be detected since pullback was only 2 candles
            const swingLowResults = results.filter((r) => r.newSwingLow);
            expect(swingLowResults.length).toBe(0);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no swing is detected with fewer than 3 impulse candles', () => {
      fc.assert(
        fc.property(
          bearishThenBullishSequenceArb(3, 2), // only 2 bullish impulse, not enough
          (sequence) => {
            // Skip if dojis were introduced
            const hasDoji = sequence.some((c) => c.close === c.open);
            if (hasDoji) return;

            const trend = 1; // bullish
            const results = detectSwingSequence(sequence, trend);

            // No swing low should be detected since impulse was only 2 candles
            const swingLowResults = results.filter((r) => r.newSwingLow);
            expect(swingLowResults.length).toBe(0);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
