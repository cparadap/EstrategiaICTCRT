import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { detectSwing, detectSwingSequence, initialSwingState } from '../logic/swing';
import {
  updateOrderBlockState,
  identifyOrderBlock,
  initialOrderBlockState,
} from '../logic/orderblock';
import type { Candle } from '../logic/swing';
import type { OrderBlockState } from '../logic/orderblock';
import {
  pullbackImpulseSequenceArb,
  impulsePullbackSequenceArb,
} from '../generators/candle-sequence.gen';

/**
 * Helper: checks that a candle is strictly bullish (close > open).
 */
function isBullish(c: Candle): boolean {
  return c.close > c.open;
}

/**
 * Helper: checks that a candle is strictly bearish (close < open).
 */
function isBearish(c: Candle): boolean {
  return c.close < c.open;
}

/**
 * Helper: validates that a sequence has the expected pattern of
 * N bearish candles followed by M bullish candles (no dojis).
 */
function isValidBearishThenBullish(
  sequence: Candle[],
  bearishCount: number,
  bullishCount: number
): boolean {
  if (sequence.length < bearishCount + bullishCount) return false;
  for (let i = 0; i < bearishCount; i++) {
    if (!isBearish(sequence[i])) return false;
  }
  for (let i = bearishCount; i < bearishCount + bullishCount; i++) {
    if (!isBullish(sequence[i])) return false;
  }
  return true;
}

/**
 * Helper: validates that a sequence has the expected pattern of
 * N bullish candles followed by M bearish candles (no dojis).
 */
function isValidBullishThenBearish(
  sequence: Candle[],
  bullishCount: number,
  bearishCount: number
): boolean {
  if (sequence.length < bullishCount + bearishCount) return false;
  for (let i = 0; i < bullishCount; i++) {
    if (!isBullish(sequence[i])) return false;
  }
  for (let i = bullishCount; i < bullishCount + bearishCount; i++) {
    if (!isBearish(sequence[i])) return false;
  }
  return true;
}



describe('Feature: ict-crt-strategy, Property 3: Order Block Identification', () => {
  /**
   * **Validates: Requirements 3.1, 3.2, 3.3**
   *
   * Property 3: Order Block Identification
   * For any swing point identification event, the order block shall be the last candle
   * contrary to the impulse direction immediately preceding the impulse group. Its high
   * and low shall be stored as the OB zone boundaries.
   */

  describe('Requirement 3.1: Bullish trend - OB is last bearish candle before bullish impulse', () => {
    it('for any bullish trend swing low, OB high/low equals the last bearish candle high/low', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = 1; // bullish

            // Process through swing detection to confirm swing low is detected
            const results = detectSwingSequence(sequence, trend);
            const swingLowResults = results.filter((r) => r.newSwingLow);
            if (swingLowResults.length === 0) return; // skip if no swing detected

            // Track OB state through the sequence
            let obState = initialOrderBlockState();
            for (const candle of sequence) {
              obState = updateOrderBlockState(candle, obState);
            }

            // The last bearish candle is the one at index bearishCount - 1
            // (the last candle before the bullish impulse started)
            const lastBearishCandle = sequence[bearishCount - 1];

            // Identify OB
            const ob = identifyOrderBlock(trend, false, true, obState);

            expect(ob).not.toBeNull();
            expect(ob!.valid).toBe(true);
            expect(ob!.obHigh).toBeCloseTo(lastBearishCandle.high, 5);
            expect(ob!.obLow).toBeCloseTo(lastBearishCandle.low, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 3.2: Bearish trend - OB is last bullish candle before bearish impulse', () => {
    it('for any bearish trend swing high, OB high/low equals the last bullish candle high/low', () => {
      fc.assert(
        fc.property(
          impulsePullbackSequenceArb(3, 3),
          ({ sequence, bullishCount, bearishCount }) => {
            // Skip sequences where continuity adjustment produced dojis
            if (!isValidBullishThenBearish(sequence, bullishCount, bearishCount)) return;

            const trend = -1; // bearish

            // Process through swing detection to confirm swing high is detected
            const results = detectSwingSequence(sequence, trend);
            const swingHighResults = results.filter((r) => r.newSwingHigh);
            if (swingHighResults.length === 0) return; // skip if no swing detected

            // Track OB state through the sequence
            let obState = initialOrderBlockState();
            for (const candle of sequence) {
              obState = updateOrderBlockState(candle, obState);
            }

            // The last bullish candle is the one at index bullishCount - 1
            // (the last candle before the bearish impulse started)
            const lastBullishCandle = sequence[bullishCount - 1];

            // Identify OB
            const ob = identifyOrderBlock(trend, true, false, obState);

            expect(ob).not.toBeNull();
            expect(ob!.valid).toBe(true);
            expect(ob!.obHigh).toBeCloseTo(lastBullishCandle.high, 5);
            expect(ob!.obLow).toBeCloseTo(lastBullishCandle.low, 5);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 3.3: OB high and low are correctly stored as zone boundaries', () => {
    it('bullish trend OB stores correct high/low boundaries from the last bearish candle', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = 1;

            // Verify swing low is detected
            const results = detectSwingSequence(sequence, trend);
            const swingLowResults = results.filter((r) => r.newSwingLow);
            if (swingLowResults.length === 0) return;

            // Process OB state candle by candle, checking state at swing detection point
            let obState = initialOrderBlockState();
            let swingState = initialSwingState();

            for (let i = 0; i < sequence.length; i++) {
              obState = updateOrderBlockState(sequence[i], obState);
              const swingResult = detectSwing(sequence[i], trend, swingState);
              swingState = swingResult.state;

              if (swingResult.newSwingLow) {
                // At this point, identify the OB
                const ob = identifyOrderBlock(trend, false, true, obState);
                expect(ob).not.toBeNull();
                // OB high must be >= OB low (valid zone)
                expect(ob!.obHigh).toBeGreaterThanOrEqual(ob!.obLow);
                // OB boundaries come from the last bearish candle
                expect(ob!.obHigh).toBe(obState.lastBearHigh);
                expect(ob!.obLow).toBe(obState.lastBearLow);
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish trend OB stores correct high/low boundaries from the last bullish candle', () => {
      fc.assert(
        fc.property(
          impulsePullbackSequenceArb(3, 3),
          ({ sequence, bullishCount, bearishCount }) => {
            if (!isValidBullishThenBearish(sequence, bullishCount, bearishCount)) return;

            const trend = -1;

            // Verify swing high is detected
            const results = detectSwingSequence(sequence, trend);
            const swingHighResults = results.filter((r) => r.newSwingHigh);
            if (swingHighResults.length === 0) return;

            // Process OB state candle by candle, checking state at swing detection point
            let obState = initialOrderBlockState();
            let swingState = initialSwingState();

            for (let i = 0; i < sequence.length; i++) {
              obState = updateOrderBlockState(sequence[i], obState);
              const swingResult = detectSwing(sequence[i], trend, swingState);
              swingState = swingResult.state;

              if (swingResult.newSwingHigh) {
                // At this point, identify the OB
                const ob = identifyOrderBlock(trend, true, false, obState);
                expect(ob).not.toBeNull();
                // OB high must be >= OB low (valid zone)
                expect(ob!.obHigh).toBeGreaterThanOrEqual(ob!.obLow);
                // OB boundaries come from the last bullish candle
                expect(ob!.obHigh).toBe(obState.lastBullHigh);
                expect(ob!.obLow).toBe(obState.lastBullLow);
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('OB identification only occurs on swing events', () => {
    it('no OB is identified when no swing event occurs', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            const trend = 1;

            // Build OB state from the full sequence
            let obState = initialOrderBlockState();
            for (const candle of sequence) {
              obState = updateOrderBlockState(candle, obState);
            }

            // When no swing event, OB should not be identified
            const ob = identifyOrderBlock(trend, false, false, obState);
            expect(ob).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('wrong trend + swing combination does not produce OB', () => {
      fc.assert(
        fc.property(
          pullbackImpulseSequenceArb(3, 3),
          ({ sequence, bearishCount, bullishCount }) => {
            if (!isValidBearishThenBullish(sequence, bearishCount, bullishCount)) return;

            // Build OB state
            let obState = initialOrderBlockState();
            for (const candle of sequence) {
              obState = updateOrderBlockState(candle, obState);
            }

            // Bullish trend + swing_high should NOT produce OB
            // (Pine Script only triggers OB on bullish+swing_low or bearish+swing_high)
            const ob = identifyOrderBlock(1, true, false, obState);
            expect(ob).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
