import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { crtRangeArb } from '../generators/crt-range.gen';
import type { CrtRange } from '../generators/crt-range.gen';
import {
  checkCrtActivation,
  processCrtBar,
} from '../logic/crt';
import type { PriceBar, Trend, CrtLevel } from '../logic/crt';

/**
 * State machine constants matching Pine Script definitions.
 */
const STATE = {
  IDLE: 0,
  WAIT_OB_TOUCH: 1,
  WAIT_4H_ACTIVATION: 2,
  WAIT_1H_CRT: 3,
  WAIT_15M_CRT: 4,
  WAIT_5M_ENTRY: 5,
  POSITION_OPEN: 6,
} as const;

/**
 * Maps the current state to the next state after CRT activation.
 * This mirrors the Pine Script state transitions:
 * - WAIT_4H_ACTIVATION → WAIT_1H_CRT (4H CRT activated)
 * - WAIT_1H_CRT → WAIT_15M_CRT (1H CRT activated)
 * - WAIT_15M_CRT → WAIT_5M_ENTRY (15M CRT activated)
 */
function getNextStateOnActivation(currentState: number): number {
  switch (currentState) {
    case STATE.WAIT_4H_ACTIVATION:
      return STATE.WAIT_1H_CRT;
    case STATE.WAIT_1H_CRT:
      return STATE.WAIT_15M_CRT;
    case STATE.WAIT_15M_CRT:
      return STATE.WAIT_5M_ENTRY;
    default:
      return currentState;
  }
}

/**
 * Maps state to the CRT level being checked at that state.
 */
function getLevelForState(state: number): CrtLevel {
  switch (state) {
    case STATE.WAIT_4H_ACTIVATION:
      return '4H';
    case STATE.WAIT_1H_CRT:
      return '1H';
    case STATE.WAIT_15M_CRT:
      return '15M';
    default:
      return '4H';
  }
}

describe('Feature: ict-crt-strategy, Property 5: CRT Activation on Correct Extreme Break', () => {
  /**
   * **Validates: Requirements 4.2, 4.3, 5.2, 5.3, 6.2, 6.3**
   *
   * Property 5: CRT Activation on Correct Extreme Break
   * For any valid CRT range at the 4H, 1H, or 15M level, when price breaks the
   * activation extreme (lower extreme for bullish trend, upper extreme for bearish trend),
   * the CRT shall transition to activated state and the state machine shall advance
   * to the next lower timeframe.
   */

  describe('Requirement 4.2: Bullish trend - price breaks below CRT low activates (4H)', () => {
    it('for any established CRT range in bullish trend, breaking below low activates the CRT', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = 1; // bullish
            const level: CrtLevel = '4H';

            // Price bar that breaks below the CRT low
            const bar: PriceBar = {
              high: crt.low + (crt.high - crt.low) * 0.5, // stays within range
              low: crt.low - offset, // breaks below low (activation)
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 4.3: Bearish trend - price breaks above CRT high activates (4H)', () => {
    it('for any established CRT range in bearish trend, breaking above high activates the CRT', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = -1; // bearish
            const level: CrtLevel = '4H';

            // Price bar that breaks above the CRT high
            const bar: PriceBar = {
              high: crt.high + offset, // breaks above high (activation)
              low: crt.low + (crt.high - crt.low) * 0.5, // stays within range
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 5.2, 5.3: 1H CRT activation follows same pattern', () => {
    it('bullish trend: any CRT range activates when low < crt_low (1H level)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = 1;
            const level: CrtLevel = '1H';

            const bar: PriceBar = {
              high: crt.low + (crt.high - crt.low) * 0.5,
              low: crt.low - offset,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish trend: any CRT range activates when high > crt_high (1H level)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = -1;
            const level: CrtLevel = '1H';

            const bar: PriceBar = {
              high: crt.high + offset,
              low: crt.low + (crt.high - crt.low) * 0.5,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 6.2, 6.3: 15M CRT activation follows same pattern', () => {
    it('bullish trend: CRT activates when low < crt_low (15M level)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = 1;
            const level: CrtLevel = '15M';

            const bar: PriceBar = {
              high: crt.low + (crt.high - crt.low) * 0.5,
              low: crt.low - offset,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.valid).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish trend: CRT activates when high > crt_high (15M level)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = -1;
            const level: CrtLevel = '15M';

            const bar: PriceBar = {
              high: crt.high + offset,
              low: crt.low + (crt.high - crt.low) * 0.5,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            expect(result.valid).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('State machine advances on activation', () => {
    it('4H activation (WAIT_4H_ACTIVATION) transitions to WAIT_1H_CRT', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, trend, offset) => {
            const level = getLevelForState(STATE.WAIT_4H_ACTIVATION);
            const bar: PriceBar =
              trend === 1
                ? { high: crt.high - 0.001, low: crt.low - offset }
                : { high: crt.high + offset, low: crt.low + 0.001 };

            const result = processCrtBar(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            const nextState = getNextStateOnActivation(STATE.WAIT_4H_ACTIVATION);
            expect(nextState).toBe(STATE.WAIT_1H_CRT);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('1H activation (WAIT_1H_CRT) transitions to WAIT_15M_CRT', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, trend, offset) => {
            const level = getLevelForState(STATE.WAIT_1H_CRT);
            const bar: PriceBar =
              trend === 1
                ? { high: crt.high - 0.001, low: crt.low - offset }
                : { high: crt.high + offset, low: crt.low + 0.001 };

            const result = processCrtBar(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            const nextState = getNextStateOnActivation(STATE.WAIT_1H_CRT);
            expect(nextState).toBe(STATE.WAIT_15M_CRT);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('15M activation (WAIT_15M_CRT) transitions to WAIT_5M_ENTRY', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, trend, offset) => {
            const level = getLevelForState(STATE.WAIT_15M_CRT);
            const bar: PriceBar =
              trend === 1
                ? { high: crt.high - 0.001, low: crt.low - offset }
                : { high: crt.high + offset, low: crt.low + 0.001 };

            const result = processCrtBar(crt, bar, trend, level);

            expect(result.activated).toBe(true);
            const nextState = getNextStateOnActivation(STATE.WAIT_15M_CRT);
            expect(nextState).toBe(STATE.WAIT_5M_ENTRY);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('No activation when price stays within range', () => {
    it('price within CRT range does not activate or invalidate', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.constantFrom<CrtLevel>('4H', '1H', '15M'),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          (crt, trend, level, highFrac, lowFrac) => {
            const spread = crt.high - crt.low;
            // Ensure high and low are strictly within the CRT range
            const high = crt.low + spread * Math.max(highFrac, lowFrac);
            const low = crt.low + spread * Math.min(highFrac, lowFrac);

            const bar: PriceBar = { high, low };
            const result = processCrtBar(crt, bar, trend, level);

            expect(result.activated).toBe(false);
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Already activated CRT is not re-processed', () => {
    it('an already-activated CRT range returns no activation or invalidation', () => {
      fc.assert(
        fc.property(
          crtRangeArb('activated', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.constantFrom<CrtLevel>('4H', '1H', '15M'),
          (crt, trend, level) => {
            // Even with a bar that would normally activate, already-activated CRT is skipped
            const bar: PriceBar = { high: crt.high + 10, low: crt.low - 10 };

            const result = processCrtBar(crt, bar, trend, level);

            expect(result.activated).toBe(true); // already activated, stays activated
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
