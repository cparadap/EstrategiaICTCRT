import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { crtRangeArb } from '../generators/crt-range.gen';
import {
  checkCrtActivation,
  calculateTPSL,
} from '../logic/crt';
import type { PriceBar, CrtRangeState, CrtLevel } from '../logic/crt';

/**
 * Property 11: Long/Short Symmetry
 *
 * **Validates: Requirements 11.1**
 *
 * For any complete setup scenario producing a valid entry in one trend direction,
 * mirroring all price inputs (swapping highs for lows and vice versa) and inverting
 * the trend direction shall produce the equivalent mirrored entry with mirrored TP/SL levels.
 *
 * Symmetry means:
 * - CRT activation: bullish activates when bar.low < crt.low; bearish activates when bar.high > crt.high
 *   If we mirror a bullish scenario (swap high↔low, invert trend), we get the equivalent bearish scenario.
 * - TP/SL: Long TP = crt4h_high, Short TP = crt4h_low (symmetric extremes)
 *   Long SL = entryBarLow - 5*mintick, Short SL = entryBarHigh + 5*mintick (symmetric offsets)
 */
describe('Feature: ict-crt-strategy, Property 11: Long/Short Symmetry', () => {
  // Generator for realistic price values
  const priceArb = fc.double({ min: 100, max: 5000, noNaN: true, noDefaultInfinity: true });

  // Generator for positive offsets
  const offsetArb = fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true });

  // Generator for mintick values
  const mintickArb = fc.oneof(
    fc.constant(0.01),
    fc.constant(0.001),
    fc.constant(0.0001),
    fc.constant(0.00001),
    fc.double({ min: 0.00001, max: 1, noNaN: true, noDefaultInfinity: true })
  );

  // CRT levels that share the same activation logic (4H, 1H, 15M)
  const higherTfLevelArb = fc.constantFrom<CrtLevel>('4H', '1H', '15M');

  describe('CRT Activation Symmetry (4H/1H/15M levels)', () => {
    it('bullish activation (bar.low < crt.low) mirrors bearish activation (bar.high > crt.high)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          offsetArb,
          higherTfLevelArb,
          (crt, offset, level) => {
            // Bullish scenario: bar breaks below CRT low → activation
            const bullishBar: PriceBar = {
              high: crt.high - 0.01, // stays below high (no invalidation)
              low: crt.low - offset, // breaks below low (activation)
            };

            const bullishResult = checkCrtActivation(crt, bullishBar, 1, level);

            // Mirror: swap the role of high/low in the CRT and bar, invert trend
            // For bearish activation: bar.high > crt.high
            // The "mirrored" CRT has the same range boundaries
            // The "mirrored" bar breaks above the CRT high by the same offset
            const bearishBar: PriceBar = {
              high: crt.high + offset, // breaks above high (activation for bearish)
              low: crt.low + 0.01, // stays above low (no invalidation)
            };

            const bearishResult = checkCrtActivation(crt, bearishBar, -1, level);

            // Both should activate symmetrically
            expect(bullishResult.activated).toBe(true);
            expect(bearishResult.activated).toBe(true);
            expect(bullishResult.valid).toBe(bearishResult.valid);
            expect(bullishResult.invalidated).toBe(bearishResult.invalidated);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('non-activating bullish bar mirrors non-activating bearish bar', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          higherTfLevelArb,
          (crt, highFrac, lowFrac, level) => {
            const spread = crt.high - crt.low;

            // Bullish: bar stays within range (no activation, no invalidation)
            const bullishBar: PriceBar = {
              high: crt.low + spread * Math.max(highFrac, lowFrac),
              low: crt.low + spread * Math.min(highFrac, lowFrac),
            };

            // Bearish: bar stays within range (no activation, no invalidation)
            const bearishBar: PriceBar = {
              high: crt.low + spread * Math.max(highFrac, lowFrac),
              low: crt.low + spread * Math.min(highFrac, lowFrac),
            };

            const bullishResult = checkCrtActivation(crt, bullishBar, 1, level);
            const bearishResult = checkCrtActivation(crt, bearishBar, -1, level);

            // Neither should activate
            expect(bullishResult.activated).toBe(false);
            expect(bearishResult.activated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('CRT Activation Symmetry (5M level)', () => {
    it('bullish 5M entry (bar.high > crt.high) mirrors bearish 5M entry (bar.low < crt.low)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          offsetArb,
          (crt, offset) => {
            // 5M bullish entry: bar.high > crt.high
            const bullishBar: PriceBar = {
              high: crt.high + offset, // breaks above high (entry for bullish)
              low: crt.low + 0.01, // stays above low (no invalidation)
            };

            const bullishResult = checkCrtActivation(crt, bullishBar, 1, '5M');

            // 5M bearish entry: bar.low < crt.low
            const bearishBar: PriceBar = {
              high: crt.high - 0.01, // stays below high (no invalidation)
              low: crt.low - offset, // breaks below low (entry for bearish)
            };

            const bearishResult = checkCrtActivation(crt, bearishBar, -1, '5M');

            // Both should activate (trigger entry) symmetrically
            expect(bullishResult.activated).toBe(true);
            expect(bearishResult.activated).toBe(true);
            expect(bullishResult.valid).toBe(bearishResult.valid);
            expect(bullishResult.invalidated).toBe(bearishResult.invalidated);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('TP/SL Symmetry', () => {
    it('long TP uses crt4h_high while short TP uses crt4h_low (symmetric extremes)', () => {
      fc.assert(
        fc.property(
          priceArb,
          priceArb,
          priceArb,
          priceArb,
          mintickArb,
          (crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick) => {
            // Ensure valid range: high > low
            const h = Math.max(crt4hHigh, crt4hLow) + 0.01;
            const l = Math.min(crt4hHigh, crt4hLow);
            const barH = Math.max(entryBarLow, entryBarHigh) + 0.01;
            const barL = Math.min(entryBarLow, entryBarHigh);

            const longResult = calculateTPSL(1, h, l, barL, barH, mintick);
            const shortResult = calculateTPSL(-1, h, l, barL, barH, mintick);

            // Long TP = crt4h_high, Short TP = crt4h_low
            // These are the symmetric extremes of the same 4H CRT range
            expect(longResult.tp).toBe(h);
            expect(shortResult.tp).toBe(l);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('long SL offset below entry bar low mirrors short SL offset above entry bar high', () => {
      fc.assert(
        fc.property(
          priceArb,
          priceArb,
          priceArb,
          priceArb,
          mintickArb,
          (crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick) => {
            const h = Math.max(crt4hHigh, crt4hLow) + 0.01;
            const l = Math.min(crt4hHigh, crt4hLow);
            const barH = Math.max(entryBarLow, entryBarHigh) + 0.01;
            const barL = Math.min(entryBarLow, entryBarHigh);

            const longResult = calculateTPSL(1, h, l, barL, barH, mintick);
            const shortResult = calculateTPSL(-1, h, l, barL, barH, mintick);

            // Long SL = entryBarLow - 5*mintick (offset below)
            // Short SL = entryBarHigh + 5*mintick (offset above)
            // The offset magnitude is the same (5*mintick) — symmetric
            const longSlOffset = barL - longResult.sl;
            const shortSlOffset = shortResult.sl - barH;

            expect(longSlOffset).toBeCloseTo(5 * mintick, 10);
            expect(shortSlOffset).toBeCloseTo(5 * mintick, 10);
            expect(longSlOffset).toBeCloseTo(shortSlOffset, 10);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('mirroring a long setup produces the equivalent short setup structure', () => {
      fc.assert(
        fc.property(
          // Generate a CRT range and entry bar
          fc.double({ min: 200, max: 4800, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 1, max: 200, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 200, max: 4800, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 1, max: 200, noNaN: true, noDefaultInfinity: true }),
          mintickArb,
          (crtBase, crtSpread, barBase, barSpread, mintick) => {
            const crt4hHigh = crtBase + crtSpread;
            const crt4hLow = crtBase;
            const entryBarHigh = barBase + barSpread;
            const entryBarLow = barBase;

            // Original long setup
            const longTPSL = calculateTPSL(1, crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick);

            // Mirrored short setup: same range, inverted direction
            const shortTPSL = calculateTPSL(-1, crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick);

            // Structural symmetry:
            // Long TP targets the high extreme, Short TP targets the low extreme
            expect(longTPSL.tp).toBe(crt4hHigh);
            expect(shortTPSL.tp).toBe(crt4hLow);

            // Both use the same 5*mintick offset for SL, just in opposite directions
            expect(longTPSL.sl).toBeCloseTo(entryBarLow - 5 * mintick, 10);
            expect(shortTPSL.sl).toBeCloseTo(entryBarHigh + 5 * mintick, 10);

            // The SL offset magnitude is identical for both directions
            const longSlDistance = entryBarLow - longTPSL.sl;
            const shortSlDistance = shortTPSL.sl - entryBarHigh;
            expect(longSlDistance).toBeCloseTo(shortSlDistance, 10);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
