import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

/**
 * Trend classification logic extracted from Pine Script.
 *
 * Pine Script equivalent:
 * ```pine
 * if not na(h4_close) and not na(h4_ema50)
 *     trend := h4_close > h4_ema50 ? 1 : h4_close < h4_ema50 ? -1 : trend
 *     trend_changed := trend != prev_trend
 *     prev_trend := trend
 * ```
 *
 * @param h4Close - The 4H candle close price
 * @param h4Ema50 - The 4H EMA50 value
 * @param previousTrend - The trend value before this evaluation (0 = uninitialized, 1 = bullish, -1 = bearish)
 * @returns The new trend value: 1 (bullish), -1 (bearish), or unchanged (previous trend)
 */
export function classifyTrend(
  h4Close: number,
  h4Ema50: number,
  previousTrend: number
): number {
  if (h4Close > h4Ema50) {
    return 1;
  } else if (h4Close < h4Ema50) {
    return -1;
  } else {
    // close == ema50 → trend unchanged
    return previousTrend;
  }
}

/**
 * Checks whether the trend has changed compared to the previous trend.
 *
 * @param currentTrend - The current trend value after classification
 * @param previousTrend - The trend value before classification
 * @returns true if trend changed, false otherwise
 */
export function detectTrendChange(
  currentTrend: number,
  previousTrend: number
): boolean {
  return currentTrend !== previousTrend;
}

describe('Feature: ict-crt-strategy, Property 1: Trend Classification Correctness', () => {
  /**
   * **Validates: Requirements 1.1, 1.2**
   *
   * Property 1: Trend Classification Correctness
   * For any 4H close price and EMA50 value:
   * - if close > EMA50 → trend is bullish (1)
   * - if close < EMA50 → trend is bearish (-1)
   * - if close == EMA50 → trend unchanged (returns previous trend)
   */

  const priceArb = fc.double({ min: 0.0001, max: 100000, noNaN: true, noDefaultInfinity: true });
  const previousTrendArb = fc.constantFrom(-1, 0, 1);

  it('close > ema50 → trend is bullish (1)', () => {
    fc.assert(
      fc.property(
        priceArb,
        fc.double({ min: 0.0001, max: 99999, noNaN: true, noDefaultInfinity: true }),
        previousTrendArb,
        (ema50, offset, prevTrend) => {
          // Ensure close > ema50 by adding a positive offset
          const positiveOffset = Math.abs(offset) + 0.0001;
          const h4Close = ema50 + positiveOffset;

          const result = classifyTrend(h4Close, ema50, prevTrend);
          expect(result).toBe(1);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('close < ema50 → trend is bearish (-1)', () => {
    fc.assert(
      fc.property(
        priceArb,
        fc.double({ min: 0.0001, max: 99999, noNaN: true, noDefaultInfinity: true }),
        previousTrendArb,
        (ema50, offset, prevTrend) => {
          // Ensure close < ema50 by subtracting a positive offset
          const positiveOffset = Math.abs(offset) + 0.0001;
          const h4Close = ema50 - positiveOffset;

          // Guard: h4Close must remain positive
          if (h4Close <= 0) return;

          const result = classifyTrend(h4Close, ema50, prevTrend);
          expect(result).toBe(-1);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('close == ema50 → trend unchanged (returns previous trend)', () => {
    fc.assert(
      fc.property(
        priceArb,
        previousTrendArb,
        (price, prevTrend) => {
          // When close equals ema50 exactly, trend should remain unchanged
          const result = classifyTrend(price, price, prevTrend);
          expect(result).toBe(prevTrend);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('trend change is detected when classification differs from previous', () => {
    fc.assert(
      fc.property(
        priceArb,
        priceArb,
        previousTrendArb,
        (h4Close, h4Ema50, prevTrend) => {
          const newTrend = classifyTrend(h4Close, h4Ema50, prevTrend);
          const changed = detectTrendChange(newTrend, prevTrend);

          if (newTrend !== prevTrend) {
            expect(changed).toBe(true);
          } else {
            expect(changed).toBe(false);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it('trend classification is deterministic for same inputs', () => {
    fc.assert(
      fc.property(
        priceArb,
        priceArb,
        previousTrendArb,
        (h4Close, h4Ema50, prevTrend) => {
          const result1 = classifyTrend(h4Close, h4Ema50, prevTrend);
          const result2 = classifyTrend(h4Close, h4Ema50, prevTrend);
          expect(result1).toBe(result2);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('trend output is always one of {-1, 0, 1} given valid previous trend', () => {
    fc.assert(
      fc.property(
        priceArb,
        priceArb,
        previousTrendArb,
        (h4Close, h4Ema50, prevTrend) => {
          const result = classifyTrend(h4Close, h4Ema50, prevTrend);
          expect([-1, 0, 1]).toContain(result);
        }
      ),
      { numRuns: 100 }
    );
  });
});
