import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { crtRangeArb } from '../generators/crt-range.gen';
import type { CrtRange } from '../generators/crt-range.gen';
import { checkCrtActivation } from '../logic/crt';
import type { PriceBar, Trend, CrtLevel } from '../logic/crt';

/**
 * Property 8: 5M Entry Trigger
 *
 * **Validates: Requirements 7.2, 7.3**
 *
 * For any valid 5M CRT range, when price breaks the entry extreme
 * (upper extreme for bullish trend, lower extreme for bearish trend),
 * a trade entry shall be executed in the trend direction.
 *
 * From Pine Script:
 * - Bullish: entry when high > crt5m_high → strategy.entry("Long", strategy.long)
 * - Bearish: entry when low < crt5m_low → strategy.entry("Short", strategy.short)
 *
 * This maps to checkCrtActivation with level='5M':
 * - Bullish: activated (entry) when bar.high > crt.high
 * - Bearish: activated (entry) when bar.low < crt.low
 */
describe('Feature: ict-crt-strategy, Property 8: 5M Entry Trigger', () => {
  const level: CrtLevel = '5M';

  describe('Requirement 7.2: Bullish trend - price breaks above 5M CRT high triggers long entry', () => {
    it('for any established 5M CRT range in bullish trend, breaking above high triggers entry', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = 1; // bullish

            // Price bar that breaks above the CRT high (entry trigger)
            const bar: PriceBar = {
              high: crt.high + offset, // breaks above high → entry
              low: crt.low + (crt.high - crt.low) * 0.5, // stays within range
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            // Entry should be triggered (activated = true for 5M means entry)
            expect(result.activated).toBe(true);
            expect(result.valid).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 7.3: Bearish trend - price breaks below 5M CRT low triggers short entry', () => {
    it('for any established 5M CRT range in bearish trend, breaking below low triggers entry', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = -1; // bearish

            // Price bar that breaks below the CRT low (entry trigger)
            const bar: PriceBar = {
              high: crt.low + (crt.high - crt.low) * 0.5, // stays within range
              low: crt.low - offset, // breaks below low → entry
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            // Entry should be triggered (activated = true for 5M means entry)
            expect(result.activated).toBe(true);
            expect(result.valid).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Entry direction matches trend direction', () => {
    it('bullish trend entry is always a Long (activated on high break)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = 1;
            const bar: PriceBar = {
              high: crt.high + offset,
              low: crt.low + (crt.high - crt.low) * 0.3,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            // Activation on 5M bullish = Long entry
            expect(result.activated).toBe(true);

            // Verify the opposite direction does NOT trigger:
            // In bullish trend, breaking below low should NOT activate 5M
            const nonTriggerBar: PriceBar = {
              high: crt.high - 0.01,
              low: crt.low - offset,
            };
            const nonResult = checkCrtActivation(crt, nonTriggerBar, trend, level);
            expect(nonResult.activated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish trend entry is always a Short (activated on low break)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
          (crt, offset) => {
            const trend: Trend = -1;
            const bar: PriceBar = {
              high: crt.low + (crt.high - crt.low) * 0.7,
              low: crt.low - offset,
            };

            const result = checkCrtActivation(crt, bar, trend, level);

            // Activation on 5M bearish = Short entry
            expect(result.activated).toBe(true);

            // Verify the opposite direction does NOT trigger:
            // In bearish trend, breaking above high should NOT activate 5M
            const nonTriggerBar: PriceBar = {
              high: crt.high + offset,
              low: crt.low + 0.01,
            };
            const nonResult = checkCrtActivation(crt, nonTriggerBar, trend, level);
            expect(nonResult.activated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('No entry when price stays within 5M CRT range', () => {
    it('price within range does not trigger entry for either trend direction', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 0.99, noNaN: true, noDefaultInfinity: true }),
          (crt, trend, highFrac, lowFrac) => {
            const spread = crt.high - crt.low;
            // Ensure bar stays strictly within the CRT range
            const high = crt.low + spread * Math.max(highFrac, lowFrac);
            const low = crt.low + spread * Math.min(highFrac, lowFrac);

            const bar: PriceBar = { high, low };
            const result = checkCrtActivation(crt, bar, trend, level);

            expect(result.activated).toBe(false);
            expect(result.valid).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Already activated 5M CRT does not re-trigger entry', () => {
    it('an already-activated 5M CRT range does not produce a new entry signal', () => {
      fc.assert(
        fc.property(
          crtRangeArb('activated', { min: 100, max: 5000 }),
          fc.constantFrom<Trend>(1, -1),
          (crt, trend) => {
            // Even with a bar that would normally trigger entry
            const bar: PriceBar = { high: crt.high + 10, low: crt.low - 10 };

            const result = checkCrtActivation(crt, bar, trend, level);

            // Already activated stays activated (no new entry signal)
            expect(result.activated).toBe(true);
            expect(result.invalidated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
