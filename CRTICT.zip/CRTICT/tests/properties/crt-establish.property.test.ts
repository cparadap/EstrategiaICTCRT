import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  establish4HCRT,
  establish1HCRT,
  establish15MCRT,
  establish5MCRT,
  isOBTouch,
  STATE,
} from '../logic/crt';
import type { OrderBlock, TimeframeCandle } from '../logic/crt';
import { crtRangeArb } from '../generators/crt-range.gen';

/**
 * Generates a valid Order Block with high > low.
 */
function orderBlockArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<OrderBlock> {
  return fc
    .record({
      low: fc.double({ min: priceRange.min, max: priceRange.max - 1, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: 50, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: low + spread,
      low,
    }));
}

/**
 * Generates a timeframe candle (high/low pair) with high > low.
 */
function timeframeCandleArb(
  priceRange: { min: number; max: number } = { min: 100, max: 5000 }
): fc.Arbitrary<TimeframeCandle> {
  return fc
    .record({
      low: fc.double({ min: priceRange.min, max: priceRange.max - 1, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: low + spread,
      low,
    }));
}

/**
 * Generates a bar (high/low) that touches a given OB zone.
 * Touch condition: barLow <= ob.high AND barHigh >= ob.low
 */
function touchingBarArb(ob: OrderBlock): fc.Arbitrary<{ high: number; low: number }> {
  // Generate a bar whose range overlaps with the OB zone
  return fc
    .record({
      // Low must be <= ob.high
      low: fc.double({ min: Math.max(0.01, ob.low - 100), max: ob.high, noNaN: true, noDefaultInfinity: true }),
      // Spread ensures high >= ob.low
      spread: fc.double({ min: 0.01, max: 200, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: Math.max(low + spread, ob.low),
      low,
    }));
}

/**
 * Generates a bar (high/low) that does NOT touch a given OB zone.
 * Non-touch: barLow > ob.high OR barHigh < ob.low
 */
function nonTouchingBarArb(ob: OrderBlock): fc.Arbitrary<{ high: number; low: number }> {
  return fc.oneof(
    // Bar entirely above OB
    fc
      .record({
        low: fc.double({ min: ob.high + 0.01, max: ob.high + 500, noNaN: true, noDefaultInfinity: true }),
        spread: fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
      })
      .map(({ low, spread }) => ({ high: low + spread, low })),
    // Bar entirely below OB
    fc
      .record({
        high: fc.double({ min: Math.max(0.02, ob.low - 500), max: ob.low - 0.01, noNaN: true, noDefaultInfinity: true }),
        spread: fc.double({ min: 0.01, max: Math.max(0.02, ob.low - 500 - 0.01), noNaN: true, noDefaultInfinity: true }),
      })
      .filter(({ high, spread }) => high - spread > 0)
      .map(({ high, spread }) => ({ high, low: high - spread }))
  );
}

describe('Feature: ict-crt-strategy, Property 4: CRT Range Establishment', () => {
  /**
   * **Validates: Requirements 4.1, 5.1, 6.1, 7.1**
   *
   * Property 4: CRT Range Establishment
   * For any CRT level (4H, 1H, 15M, 5M), when the parent condition is met
   * (OB touch for 4H, parent CRT activation for others), the CRT range shall be
   * established from the first candle close at that timeframe, recording its high
   * and low as the range boundaries.
   */

  describe('Requirement 4.1: 4H CRT established when price touches OB zone', () => {
    it('when state is WAIT_OB_TOUCH and bar touches OB, CRT range equals 4H candle high/low', () => {
      fc.assert(
        fc.property(
          orderBlockArb(),
          timeframeCandleArb(),
          (ob, h4Candle) => {
            // Generate a bar that touches the OB
            const barHigh = Math.max(ob.low, h4Candle.high);
            const barLow = Math.min(ob.high, h4Candle.low);

            // Ensure touch condition: barLow <= ob.high AND barHigh >= ob.low
            const touchLow = Math.min(ob.high, ob.low);
            const touchHigh = Math.max(ob.low, ob.high);

            const result = establish4HCRT(
              STATE.WAIT_OB_TOUCH,
              touchHigh,
              touchLow,
              ob,
              h4Candle
            );

            expect(result.established).toBe(true);
            expect(result.crtHigh).toBe(h4Candle.high);
            expect(result.crtLow).toBe(h4Candle.low);
            expect(result.newState).toBe(STATE.WAIT_4H_ACTIVATION);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('4H CRT high/low always comes from the 4H candle, not the 5M bar', () => {
      fc.assert(
        fc.property(
          orderBlockArb(),
          timeframeCandleArb(),
          (ob, h4Candle) => {
            // Use a bar that definitely touches OB (bar encompasses OB zone)
            const barHigh = ob.high + 10;
            const barLow = ob.low - 10;

            const result = establish4HCRT(
              STATE.WAIT_OB_TOUCH,
              barHigh,
              barLow,
              ob,
              h4Candle
            );

            expect(result.established).toBe(true);
            // CRT range must come from h4Candle, NOT from barHigh/barLow
            expect(result.crtHigh).toBe(h4Candle.high);
            expect(result.crtLow).toBe(h4Candle.low);
            // CRT high must be >= CRT low (valid range)
            expect(result.crtHigh).toBeGreaterThan(result.crtLow!);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when state is not WAIT_OB_TOUCH', () => {
      fc.assert(
        fc.property(
          fc.constantFrom(
            STATE.IDLE,
            STATE.WAIT_4H_ACTIVATION,
            STATE.WAIT_1H_CRT,
            STATE.WAIT_15M_CRT,
            STATE.WAIT_5M_ENTRY,
            STATE.POSITION_OPEN
          ),
          orderBlockArb(),
          timeframeCandleArb(),
          (wrongState, ob, h4Candle) => {
            // Bar that touches OB
            const barHigh = ob.high + 10;
            const barLow = ob.low - 10;

            const result = establish4HCRT(wrongState, barHigh, barLow, ob, h4Candle);

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
            expect(result.newState).toBe(wrongState);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when bar does not touch OB zone', () => {
      fc.assert(
        fc.property(
          orderBlockArb({ min: 200, max: 4000 }),
          timeframeCandleArb(),
          (ob, h4Candle) => {
            // Bar entirely above OB (barLow > ob.high)
            const barLow = ob.high + 1;
            const barHigh = barLow + 50;

            const result = establish4HCRT(
              STATE.WAIT_OB_TOUCH,
              barHigh,
              barLow,
              ob,
              h4Candle
            );

            expect(result.established).toBe(false);
            expect(result.newState).toBe(STATE.WAIT_OB_TOUCH);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 5.1: 1H CRT established on first 1H bar after 4H activation', () => {
    it('when state is WAIT_1H_CRT and new 1H bar, CRT range equals 1H candle high/low', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (h1Candle) => {
            const result = establish1HCRT(
              STATE.WAIT_1H_CRT,
              true, // new 1H bar
              h1Candle,
              false // not already established
            );

            expect(result.established).toBe(true);
            expect(result.crtHigh).toBe(h1Candle.high);
            expect(result.crtLow).toBe(h1Candle.low);
            // CRT high must be > CRT low
            expect(result.crtHigh).toBeGreaterThan(result.crtLow!);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when not a new 1H bar', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (h1Candle) => {
            const result = establish1HCRT(
              STATE.WAIT_1H_CRT,
              false, // NOT a new 1H bar
              h1Candle,
              false
            );

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when 1H CRT already established', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (h1Candle) => {
            const result = establish1HCRT(
              STATE.WAIT_1H_CRT,
              true, // new 1H bar
              h1Candle,
              true // already established
            );

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when state is not WAIT_1H_CRT', () => {
      fc.assert(
        fc.property(
          fc.constantFrom(
            STATE.IDLE,
            STATE.WAIT_OB_TOUCH,
            STATE.WAIT_4H_ACTIVATION,
            STATE.WAIT_15M_CRT,
            STATE.WAIT_5M_ENTRY,
            STATE.POSITION_OPEN
          ),
          timeframeCandleArb(),
          (wrongState, h1Candle) => {
            const result = establish1HCRT(wrongState, true, h1Candle, false);

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 6.1: 15M CRT established on first 15M bar after 1H activation', () => {
    it('when state is WAIT_15M_CRT and new 15M bar, CRT range equals 15M candle high/low', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (m15Candle) => {
            const result = establish15MCRT(
              STATE.WAIT_15M_CRT,
              true, // new 15M bar
              m15Candle,
              false // not already established
            );

            expect(result.established).toBe(true);
            expect(result.crtHigh).toBe(m15Candle.high);
            expect(result.crtLow).toBe(m15Candle.low);
            // CRT high must be > CRT low
            expect(result.crtHigh).toBeGreaterThan(result.crtLow!);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when not a new 15M bar', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (m15Candle) => {
            const result = establish15MCRT(
              STATE.WAIT_15M_CRT,
              false, // NOT a new 15M bar
              m15Candle,
              false
            );

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when 15M CRT already established', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (m15Candle) => {
            const result = establish15MCRT(
              STATE.WAIT_15M_CRT,
              true, // new 15M bar
              m15Candle,
              true // already established
            );

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when state is not WAIT_15M_CRT', () => {
      fc.assert(
        fc.property(
          fc.constantFrom(
            STATE.IDLE,
            STATE.WAIT_OB_TOUCH,
            STATE.WAIT_4H_ACTIVATION,
            STATE.WAIT_1H_CRT,
            STATE.WAIT_5M_ENTRY,
            STATE.POSITION_OPEN
          ),
          timeframeCandleArb(),
          (wrongState, m15Candle) => {
            const result = establish15MCRT(wrongState, true, m15Candle, false);

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 7.1: 5M CRT established on first 5M bar after 15M activation', () => {
    it('when state is WAIT_5M_ENTRY and first bar, CRT range equals 5M candle high/low', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (m5Candle) => {
            const result = establish5MCRT(
              STATE.WAIT_5M_ENTRY,
              m5Candle,
              false // not already established
            );

            expect(result.established).toBe(true);
            expect(result.crtHigh).toBe(m5Candle.high);
            expect(result.crtLow).toBe(m5Candle.low);
            // CRT high must be > CRT low
            expect(result.crtHigh).toBeGreaterThan(result.crtLow!);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when 5M CRT already established', () => {
      fc.assert(
        fc.property(
          timeframeCandleArb(),
          (m5Candle) => {
            const result = establish5MCRT(
              STATE.WAIT_5M_ENTRY,
              m5Candle,
              true // already established
            );

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });

    it('no establishment when state is not WAIT_5M_ENTRY', () => {
      fc.assert(
        fc.property(
          fc.constantFrom(
            STATE.IDLE,
            STATE.WAIT_OB_TOUCH,
            STATE.WAIT_4H_ACTIVATION,
            STATE.WAIT_1H_CRT,
            STATE.WAIT_15M_CRT,
            STATE.POSITION_OPEN
          ),
          timeframeCandleArb(),
          (wrongState, m5Candle) => {
            const result = establish5MCRT(wrongState, m5Candle, false);

            expect(result.established).toBe(false);
            expect(result.crtHigh).toBeNull();
            expect(result.crtLow).toBeNull();
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Cross-timeframe: CRT range high > low invariant', () => {
    it('for any established CRT at any timeframe, high is always greater than low', () => {
      fc.assert(
        fc.property(
          fc.constantFrom('4H', '1H', '15M', '5M'),
          timeframeCandleArb(),
          orderBlockArb(),
          (timeframe, candle, ob) => {
            let crtHigh: number | null = null;
            let crtLow: number | null = null;

            switch (timeframe) {
              case '4H': {
                // Use a bar that touches OB
                const barHigh = ob.high + 10;
                const barLow = ob.low - 10;
                const result = establish4HCRT(STATE.WAIT_OB_TOUCH, barHigh, barLow, ob, candle);
                if (result.established) {
                  crtHigh = result.crtHigh;
                  crtLow = result.crtLow;
                }
                break;
              }
              case '1H': {
                const result = establish1HCRT(STATE.WAIT_1H_CRT, true, candle, false);
                if (result.established) {
                  crtHigh = result.crtHigh;
                  crtLow = result.crtLow;
                }
                break;
              }
              case '15M': {
                const result = establish15MCRT(STATE.WAIT_15M_CRT, true, candle, false);
                if (result.established) {
                  crtHigh = result.crtHigh;
                  crtLow = result.crtLow;
                }
                break;
              }
              case '5M': {
                const result = establish5MCRT(STATE.WAIT_5M_ENTRY, candle, false);
                if (result.established) {
                  crtHigh = result.crtHigh;
                  crtLow = result.crtLow;
                }
                break;
              }
            }

            if (crtHigh !== null && crtLow !== null) {
              expect(crtHigh).toBeGreaterThan(crtLow);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
