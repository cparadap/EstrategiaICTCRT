import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { STATE, type StateValue } from '../logic/crt';
import { stateForPhaseArb, type StrategyState, type TrendDirection } from '../generators/state.gen';

/**
 * Feature: ict-crt-strategy, Property 12: Single Active Direction Invariant
 *
 * **Validates: Requirements 11.2, 11.3**
 *
 * For any state of the strategy, there shall be at most one active setup direction
 * at a time. When the trend changes direction, any active setup from the previous
 * trend shall be immediately invalidated (reset to IDLE).
 */

// ============================================================================
// TREND CHANGE INVALIDATION LOGIC
// ============================================================================

/**
 * Models the trend change invalidation logic from the Pine Script.
 *
 * When `trend_changed == true` and state is active (not IDLE, not POSITION_OPEN),
 * `f_invalidate_all()` is called, resetting to IDLE.
 *
 * @param currentState - The current state machine state
 * @param trendChanged - Whether the trend has changed direction
 * @returns The new state after applying trend change invalidation
 */
export function applyTrendChangeInvalidation(
  currentState: StateValue,
  trendChanged: boolean
): StateValue {
  if (!trendChanged) {
    return currentState;
  }

  // Trend changed: invalidate if in an active setup state
  // IDLE and POSITION_OPEN are exempt from invalidation
  if (currentState !== STATE.IDLE && currentState !== STATE.POSITION_OPEN) {
    return STATE.IDLE;
  }

  return currentState;
}

/**
 * Determines whether a state is an "active setup" state
 * (i.e., between IDLE and POSITION_OPEN, where a setup is in progress).
 */
function isActiveSetupState(state: StateValue): boolean {
  return (
    state === STATE.WAIT_OB_TOUCH ||
    state === STATE.WAIT_4H_ACTIVATION ||
    state === STATE.WAIT_1H_CRT ||
    state === STATE.WAIT_15M_CRT ||
    state === STATE.WAIT_5M_ENTRY
  );
}

// ============================================================================
// GENERATORS
// ============================================================================

/** All active setup states (states that should be invalidated on trend change) */
const ACTIVE_SETUP_STATES: StateValue[] = [
  STATE.WAIT_OB_TOUCH,
  STATE.WAIT_4H_ACTIVATION,
  STATE.WAIT_1H_CRT,
  STATE.WAIT_15M_CRT,
  STATE.WAIT_5M_ENTRY,
];

/** States exempt from trend change invalidation */
const EXEMPT_STATES: StateValue[] = [STATE.IDLE, STATE.POSITION_OPEN];

/**
 * Generates a random active setup state value.
 */
function activeSetupStateArb(): fc.Arbitrary<StateValue> {
  return fc.constantFrom(...ACTIVE_SETUP_STATES);
}

/**
 * Generates a random exempt state value.
 */
function exemptStateArb(): fc.Arbitrary<StateValue> {
  return fc.constantFrom(...EXEMPT_STATES);
}

/**
 * Generates a trend direction.
 */
function trendArb(): fc.Arbitrary<TrendDirection> {
  return fc.constantFrom<TrendDirection>(1, -1);
}

// ============================================================================
// PROPERTY TESTS
// ============================================================================

describe('Feature: ict-crt-strategy, Property 12: Single Active Direction Invariant', () => {
  /**
   * Requirement 11.3:
   * WHEN the trend changes from bullish to bearish or vice versa,
   * THE Strategy SHALL invalidate any active setup from the previous trend direction.
   *
   * For any active state (WAIT_OB_TOUCH through WAIT_5M_ENTRY), a trend change
   * always resets to IDLE.
   */
  describe('Trend change invalidates any active setup state', () => {
    it('any active setup state is reset to IDLE on trend change', () => {
      fc.assert(
        fc.property(activeSetupStateArb(), (state) => {
          const result = applyTrendChangeInvalidation(state, true);

          expect(result).toBe(STATE.IDLE);
        }),
        { numRuns: 100 }
      );
    });

    it('all active states with full strategy context are invalidated on trend change', () => {
      fc.assert(
        fc.property(
          activeSetupStateArb().chain((phase) => stateForPhaseArb(phase)),
          (strategyState) => {
            const result = applyTrendChangeInvalidation(strategyState.state, true);

            expect(result).toBe(STATE.IDLE);
            expect(isActiveSetupState(strategyState.state)).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Requirement 11.2:
   * THE Strategy SHALL support only one active setup direction at a time
   * based on the current 4H trend classification.
   *
   * A trend change during IDLE or POSITION_OPEN does NOT invalidate
   * (those states are exempt).
   */
  describe('Exempt states are not affected by trend change', () => {
    it('IDLE state remains IDLE on trend change', () => {
      fc.assert(
        fc.property(trendArb(), (_trend) => {
          const result = applyTrendChangeInvalidation(STATE.IDLE, true);

          expect(result).toBe(STATE.IDLE);
        }),
        { numRuns: 100 }
      );
    });

    it('POSITION_OPEN state remains POSITION_OPEN on trend change', () => {
      fc.assert(
        fc.property(trendArb(), (_trend) => {
          const result = applyTrendChangeInvalidation(STATE.POSITION_OPEN, true);

          expect(result).toBe(STATE.POSITION_OPEN);
        }),
        { numRuns: 100 }
      );
    });

    it('exempt states are never invalidated regardless of trend direction', () => {
      fc.assert(
        fc.property(exemptStateArb(), trendArb(), (state, _trend) => {
          const result = applyTrendChangeInvalidation(state, true);

          // Exempt states should remain unchanged
          expect(result).toBe(state);
        }),
        { numRuns: 100 }
      );
    });
  });

  /**
   * After invalidation, the state is always IDLE (ready for a new setup
   * in the new direction).
   */
  describe('Post-invalidation state is always IDLE', () => {
    it('after trend change invalidation, state is always IDLE for any active state', () => {
      fc.assert(
        fc.property(activeSetupStateArb(), trendArb(), (state, _trend) => {
          const result = applyTrendChangeInvalidation(state, true);

          // After invalidation, must be IDLE
          expect(result).toBe(STATE.IDLE);
          // And IDLE is not an active setup state
          expect(isActiveSetupState(result)).toBe(false);
        }),
        { numRuns: 100 }
      );
    });
  });

  /**
   * No trend change means no invalidation — state is preserved.
   */
  describe('No trend change preserves current state', () => {
    it('when trend has not changed, state remains unchanged for any state', () => {
      fc.assert(
        fc.property(
          fc.constantFrom<StateValue>(
            STATE.IDLE,
            STATE.WAIT_OB_TOUCH,
            STATE.WAIT_4H_ACTIVATION,
            STATE.WAIT_1H_CRT,
            STATE.WAIT_15M_CRT,
            STATE.WAIT_5M_ENTRY,
            STATE.POSITION_OPEN
          ),
          (state) => {
            const result = applyTrendChangeInvalidation(state, false);

            expect(result).toBe(state);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Invariant: at most one active setup direction at a time.
   * After a trend change invalidation, the system is in IDLE, meaning
   * no setup from the previous direction remains active.
   */
  describe('Single direction invariant', () => {
    it('a trend change always clears any in-progress setup, ensuring single direction', () => {
      fc.assert(
        fc.property(
          activeSetupStateArb(),
          trendArb(),
          trendArb(),
          (state, oldTrend, newTrend) => {
            // Only consider actual trend changes
            fc.pre(oldTrend !== newTrend);

            const trendChanged = true;
            const result = applyTrendChangeInvalidation(state, trendChanged);

            // After trend change, no active setup from old direction remains
            expect(result).toBe(STATE.IDLE);
            expect(isActiveSetupState(result)).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('consecutive trend changes always result in IDLE between setups', () => {
      fc.assert(
        fc.property(
          activeSetupStateArb(),
          fc.array(trendArb(), { minLength: 2, maxLength: 10 }),
          (initialState, trendSequence) => {
            let currentState: StateValue = initialState;

            for (let i = 1; i < trendSequence.length; i++) {
              const trendChanged = trendSequence[i] !== trendSequence[i - 1];
              currentState = applyTrendChangeInvalidation(currentState, trendChanged);

              // After any actual trend change, state must be IDLE
              if (trendChanged && isActiveSetupState(currentState)) {
                // This should never happen — if it does, the invariant is violated
                expect(currentState).toBe(STATE.IDLE);
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
