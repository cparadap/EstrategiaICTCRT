import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { checkTimeLimitInvalidation, STATE } from '../logic/crt';
import type { TimeLimitState, StateValue } from '../logic/crt';

/**
 * Feature: ict-crt-strategy, Property 10: Time Limit Invalidation
 *
 * **Validates: Requirements 8.1**
 *
 * For any active setup (state not IDLE/POSITION_OPEN), when the 4H candle that
 * established the 4H CRT range closes (a new 4H bar opens) and no position has
 * been entered, all CRT ranges and the entire setup state shall be reset to IDLE.
 *
 * Pine Script logic:
 *   if state != IDLE and state != POSITION_OPEN
 *       if new_h4_bar and not na(crt4h_setup_time) and time > crt4h_setup_time + (4 * 60 * 60 * 1000)
 *           f_invalidate_all()
 */

const FOUR_HOURS_MS = 4 * 60 * 60 * 1000;

/**
 * Active states: states that are NOT IDLE and NOT POSITION_OPEN.
 * These are the states where time limit invalidation can trigger.
 */
const ACTIVE_STATES: StateValue[] = [
  STATE.WAIT_OB_TOUCH,
  STATE.WAIT_4H_ACTIVATION,
  STATE.WAIT_1H_CRT,
  STATE.WAIT_15M_CRT,
  STATE.WAIT_5M_ENTRY,
];

/**
 * Generates a random active state (not IDLE, not POSITION_OPEN).
 */
function activeStateArb(): fc.Arbitrary<StateValue> {
  return fc.constantFrom(...ACTIVE_STATES);
}

/**
 * Generates a setup time (timestamp in ms, realistic range).
 */
function setupTimeArb(): fc.Arbitrary<number> {
  return fc.integer({ min: 1_000_000_000_000, max: 1_900_000_000_000 });
}

/**
 * Generates a current time that exceeds setup time + 4 hours.
 * This ensures the time limit condition is met.
 */
function expiredTimeArb(setupTime: number): fc.Arbitrary<number> {
  // Current time must be > setupTime + 4H
  // Add at least 1ms beyond the threshold, up to 24 hours beyond
  return fc
    .integer({ min: 1, max: 24 * 60 * 60 * 1000 })
    .map((offset) => setupTime + FOUR_HOURS_MS + offset);
}

/**
 * Generates a current time that does NOT exceed setup time + 4 hours.
 * This ensures the time limit condition is NOT met.
 */
function notExpiredTimeArb(setupTime: number): fc.Arbitrary<number> {
  // Current time must be <= setupTime + 4H
  return fc
    .integer({ min: 0, max: FOUR_HOURS_MS })
    .map((offset) => setupTime + offset);
}

describe('Feature: ict-crt-strategy, Property 10: Time Limit Invalidation', () => {
  /**
   * Core property: When an active setup has a new 4H bar and time exceeds
   * setup time + 4 hours, the state resets to IDLE.
   */
  describe('Time limit triggers invalidation when all conditions are met', () => {
    it('any active state with new_h4_bar and time > setupTime + 4H → state resets to IDLE', () => {
      fc.assert(
        fc.property(
          activeStateArb().chain((state) =>
            setupTimeArb().chain((setupTime) =>
              expiredTimeArb(setupTime).map((currentTime) => ({
                state,
                newH4Bar: true,
                crt4hSetupTime: setupTime,
                currentTime,
              }))
            )
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(true);
            expect(result.newState).toBe(STATE.IDLE);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: Time limit does NOT trigger when state is IDLE.
   */
  describe('No invalidation when state is IDLE', () => {
    it('IDLE state is never invalidated by time limit regardless of time', () => {
      fc.assert(
        fc.property(
          setupTimeArb().chain((setupTime) =>
            expiredTimeArb(setupTime).map((currentTime) => ({
              state: STATE.IDLE as StateValue,
              newH4Bar: true,
              crt4hSetupTime: setupTime,
              currentTime,
            }))
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(false);
            expect(result.newState).toBe(STATE.IDLE);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: Time limit does NOT trigger when state is POSITION_OPEN.
   */
  describe('No invalidation when state is POSITION_OPEN', () => {
    it('POSITION_OPEN state is never invalidated by time limit', () => {
      fc.assert(
        fc.property(
          setupTimeArb().chain((setupTime) =>
            expiredTimeArb(setupTime).map((currentTime) => ({
              state: STATE.POSITION_OPEN as StateValue,
              newH4Bar: true,
              crt4hSetupTime: setupTime,
              currentTime,
            }))
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(false);
            expect(result.newState).toBe(STATE.POSITION_OPEN);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: Time limit does NOT trigger when no new 4H bar.
   */
  describe('No invalidation without a new 4H bar', () => {
    it('active state with expired time but no new_h4_bar → no invalidation', () => {
      fc.assert(
        fc.property(
          activeStateArb().chain((state) =>
            setupTimeArb().chain((setupTime) =>
              expiredTimeArb(setupTime).map((currentTime) => ({
                state,
                newH4Bar: false,
                crt4hSetupTime: setupTime,
                currentTime,
              }))
            )
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(false);
            expect(result.newState).toBe(input.state);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: Time limit does NOT trigger when time has not expired.
   */
  describe('No invalidation when time has not exceeded 4 hours', () => {
    it('active state with new_h4_bar but time <= setupTime + 4H → no invalidation', () => {
      fc.assert(
        fc.property(
          activeStateArb().chain((state) =>
            setupTimeArb().chain((setupTime) =>
              notExpiredTimeArb(setupTime).map((currentTime) => ({
                state,
                newH4Bar: true,
                crt4hSetupTime: setupTime,
                currentTime,
              }))
            )
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(false);
            expect(result.newState).toBe(input.state);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: Time limit does NOT trigger when setup time is null.
   */
  describe('No invalidation when setup time is null', () => {
    it('active state with new_h4_bar but null setupTime → no invalidation', () => {
      fc.assert(
        fc.property(
          activeStateArb().chain((state) =>
            fc
              .integer({ min: 1_000_000_000_000, max: 2_000_000_000_000 })
              .map((currentTime) => ({
                state,
                newH4Bar: true,
                crt4hSetupTime: null,
                currentTime,
              }))
          ),
          (input: TimeLimitState) => {
            const result = checkTimeLimitInvalidation(input);

            expect(result.invalidated).toBe(false);
            expect(result.newState).toBe(input.state);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
