import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import {
  checkReestablishTrigger,
  completeReestablishment,
} from '../logic/crt';
import type {
  CrtReestablishmentState,
  Trend,
  CrtLevel,
  PriceBar,
  TimeframeCandle,
} from '../logic/crt';
import { crtRangeArb } from '../generators/crt-range.gen';

/**
 * Feature: ict-crt-strategy, Property 7: CRT Re-establishment After Invalidation
 *
 * **Validates: Requirements 5.6, 6.6, 7.9**
 *
 * For any invalidated CRT range at the 1H, 15M, or 5M level where the parent CRT
 * remains valid, a new CRT range shall be established when price breaks beyond the
 * last invalidated range's relevant extreme (below the invalidated low for bullish,
 * above the invalidated high for bearish at 1H/15M; above the invalidated high for
 * bullish, below the invalidated low for bearish at 5M).
 */

/**
 * Generates a valid re-establishment state where:
 * - Child CRT is invalid (not valid)
 * - Not already awaiting a new bar
 * - Parent CRT is valid and activated
 * - Has a stored last invalidated extreme
 */
function reestablishStateArb(
  trend: Trend,
  level: CrtLevel
): fc.Arbitrary<CrtReestablishmentState> {
  return fc
    .double({ min: 100, max: 5000, noNaN: true, noDefaultInfinity: true })
    .map((price) => {
      if (level === '5M') {
        // 5M: bullish stores lastInvalidatedHigh, bearish stores lastInvalidatedLow
        return {
          childValid: false,
          awaitingNewBar: false,
          lastInvalidatedLow: trend === -1 ? price : null,
          lastInvalidatedHigh: trend === 1 ? price : null,
          parentValid: true,
          parentActivated: true,
        };
      } else {
        // 1H/15M: bullish stores lastInvalidatedLow, bearish stores lastInvalidatedHigh
        return {
          childValid: false,
          awaitingNewBar: false,
          lastInvalidatedLow: trend === 1 ? price : null,
          lastInvalidatedHigh: trend === -1 ? price : null,
          parentValid: true,
          parentActivated: true,
        };
      }
    });
}

/**
 * Generates a price bar that breaks below a given price level.
 */
function barBreakingBelow(price: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true })
    .map((offset) => ({
      high: price + offset * 0.5,
      low: price - offset,
    }));
}

/**
 * Generates a price bar that breaks above a given price level.
 */
function barBreakingAbove(price: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true })
    .map((offset) => ({
      high: price + offset,
      low: price - offset * 0.5,
    }));
}

/**
 * Generates a price bar that does NOT break below a given price level.
 */
function barNotBreakingBelow(price: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0, max: 200, noNaN: true, noDefaultInfinity: true })
    .map((offset) => ({
      high: price + offset + 10,
      low: price + offset * 0.1, // stays above the price
    }));
}

/**
 * Generates a price bar that does NOT break above a given price level.
 */
function barNotBreakingAbove(price: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0, max: 200, noNaN: true, noDefaultInfinity: true })
    .map((offset) => ({
      high: price - offset * 0.1, // stays below the price
      low: price - offset - 10,
    }));
}

/**
 * Generates a new candle for re-establishment completion.
 */
function newCandleArb(): fc.Arbitrary<TimeframeCandle> {
  return fc
    .record({
      low: fc.double({ min: 100, max: 4900, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: low + spread,
      low,
    }));
}

describe('Feature: ict-crt-strategy, Property 7: CRT Re-establishment After Invalidation', () => {
  /**
   * Requirement 5.6:
   * WHILE the 4H CRT range remains valid, WHEN the 1H CRT range is invalidated,
   * THE Strategy SHALL establish a new 1H CRT range when price breaks below the low
   * of the last invalidated 1H CRT range (bullish) or above the high (bearish).
   */
  describe('1H CRT re-establishment trigger', () => {
    it('bullish: triggers when price breaks below last invalidated 1H CRT low', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(1, '1H').chain((reState) =>
            barBreakingBelow(reState.lastInvalidatedLow!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '1H');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish: triggers when price breaks above last invalidated 1H CRT high', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(-1, '1H').chain((reState) =>
            barBreakingAbove(reState.lastInvalidatedHigh!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, -1, '1H');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Requirement 6.6:
   * WHILE the 1H CRT range remains valid, WHEN the 15M CRT range is invalidated,
   * THE Strategy SHALL establish a new 15M CRT range when price breaks below the low
   * of the last invalidated 15M CRT range (bullish) or above the high (bearish).
   */
  describe('15M CRT re-establishment trigger', () => {
    it('bullish: triggers when price breaks below last invalidated 15M CRT low', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(1, '15M').chain((reState) =>
            barBreakingBelow(reState.lastInvalidatedLow!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '15M');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish: triggers when price breaks above last invalidated 15M CRT high', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(-1, '15M').chain((reState) =>
            barBreakingAbove(reState.lastInvalidatedHigh!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, -1, '15M');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Requirement 7.9:
   * WHILE the 15M CRT range remains valid, WHEN the 5M CRT range is invalidated,
   * THE Strategy SHALL establish a new 5M CRT range when price breaks above the high
   * of the last invalidated 5M CRT range (bullish) or below the low (bearish).
   */
  describe('5M CRT re-establishment trigger', () => {
    it('bullish: triggers when price breaks above last invalidated 5M CRT high', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(1, '5M').chain((reState) =>
            barBreakingAbove(reState.lastInvalidatedHigh!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '5M');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('bearish: triggers when price breaks below last invalidated 5M CRT low', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(-1, '5M').chain((reState) =>
            barBreakingBelow(reState.lastInvalidatedLow!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, -1, '5M');

            expect(result.triggered).toBe(true);
            expect(result.awaitingNewBar).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: re-establishment does NOT trigger when price does not
   * break beyond the last invalidated extreme.
   */
  describe('No trigger when price does not break invalidated extreme', () => {
    it('1H bullish: no trigger when price stays above last invalidated low', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(1, '1H').chain((reState) =>
            barNotBreakingBelow(reState.lastInvalidatedLow!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '1H');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('15M bearish: no trigger when price stays below last invalidated high', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(-1, '15M').chain((reState) =>
            barNotBreakingAbove(reState.lastInvalidatedHigh!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, -1, '15M');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('5M bullish: no trigger when price stays below last invalidated high', () => {
      fc.assert(
        fc.property(
          reestablishStateArb(1, '5M').chain((reState) =>
            barNotBreakingAbove(reState.lastInvalidatedHigh!).map((bar) => ({ reState, bar }))
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '5M');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Property: re-establishment does NOT trigger when parent CRT is invalid.
   */
  describe('No trigger when parent CRT is invalid', () => {
    it('1H: no trigger when 4H CRT (parent) is not valid', () => {
      fc.assert(
        fc.property(
          fc.double({ min: 100, max: 5000, noNaN: true, noDefaultInfinity: true }).chain(
            (price) => {
              const reState: CrtReestablishmentState = {
                childValid: false,
                awaitingNewBar: false,
                lastInvalidatedLow: price,
                lastInvalidatedHigh: null,
                parentValid: false, // parent invalid
                parentActivated: true,
              };
              return barBreakingBelow(price).map((bar) => ({ reState, bar }));
            }
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '1H');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('15M: no trigger when 1H CRT (parent) is not activated', () => {
      fc.assert(
        fc.property(
          fc.double({ min: 100, max: 5000, noNaN: true, noDefaultInfinity: true }).chain(
            (price) => {
              const reState: CrtReestablishmentState = {
                childValid: false,
                awaitingNewBar: false,
                lastInvalidatedLow: price,
                lastInvalidatedHigh: null,
                parentValid: true,
                parentActivated: false, // parent not activated
              };
              return barBreakingBelow(price).map((bar) => ({ reState, bar }));
            }
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '15M');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Property: re-establishment does NOT trigger when child CRT is still valid.
   */
  describe('No trigger when child CRT is still valid', () => {
    it('1H: no trigger when 1H CRT is still valid', () => {
      fc.assert(
        fc.property(
          fc.double({ min: 100, max: 5000, noNaN: true, noDefaultInfinity: true }).chain(
            (price) => {
              const reState: CrtReestablishmentState = {
                childValid: true, // still valid - no re-establishment needed
                awaitingNewBar: false,
                lastInvalidatedLow: price,
                lastInvalidatedHigh: null,
                parentValid: true,
                parentActivated: true,
              };
              return barBreakingBelow(price).map((bar) => ({ reState, bar }));
            }
          ),
          ({ reState, bar }) => {
            const result = checkReestablishTrigger(reState, bar, 1, '1H');

            expect(result.triggered).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Property: once triggered, the new CRT is established from the next bar's high/low.
   * This tests the completeReestablishment function.
   */
  describe('Re-establishment completion: new CRT from next bar', () => {
    it('new CRT is established with the new bar high/low when awaiting and new bar arrives', () => {
      fc.assert(
        fc.property(newCandleArb(), (candle) => {
          const result = completeReestablishment(true, true, candle);

          expect(result.established).toBe(true);
          expect(result.crtHigh).toBe(candle.high);
          expect(result.crtLow).toBe(candle.low);
          expect(result.awaitingNewBar).toBe(false);
        }),
        { numRuns: 100 }
      );
    });

    it('no establishment when awaiting but no new bar yet', () => {
      fc.assert(
        fc.property(newCandleArb(), (candle) => {
          const result = completeReestablishment(true, false, candle);

          expect(result.established).toBe(false);
          expect(result.crtHigh).toBeNull();
          expect(result.crtLow).toBeNull();
          expect(result.awaitingNewBar).toBe(true);
        }),
        { numRuns: 100 }
      );
    });

    it('no establishment when not awaiting even if new bar arrives', () => {
      fc.assert(
        fc.property(newCandleArb(), (candle) => {
          const result = completeReestablishment(false, true, candle);

          expect(result.established).toBe(false);
          expect(result.crtHigh).toBeNull();
          expect(result.crtLow).toBeNull();
          expect(result.awaitingNewBar).toBe(false);
        }),
        { numRuns: 100 }
      );
    });
  });

  /**
   * End-to-end property: full re-establishment flow.
   * When CRT is invalidated, parent is valid, price breaks beyond invalidated extreme,
   * and a new bar arrives → a new CRT is established from that bar.
   */
  describe('End-to-end: invalidation → trigger → new bar → new CRT', () => {
    const levels: Array<{ level: CrtLevel; label: string }> = [
      { level: '1H', label: '1H (Req 5.6)' },
      { level: '15M', label: '15M (Req 6.6)' },
      { level: '5M', label: '5M (Req 7.9)' },
    ];

    for (const { level, label } of levels) {
      it(`${label} bullish: full re-establishment flow produces valid new CRT`, () => {
        fc.assert(
          fc.property(
            reestablishStateArb(1, level).chain((reState) => {
              const targetPrice =
                level === '5M' ? reState.lastInvalidatedHigh! : reState.lastInvalidatedLow!;
              const barGen =
                level === '5M'
                  ? barBreakingAbove(targetPrice)
                  : barBreakingBelow(targetPrice);
              return fc.tuple(fc.constant(reState), barGen, newCandleArb());
            }),
            ([reState, triggerBar, newCandle]) => {
              // Step 1: Check trigger
              const triggerResult = checkReestablishTrigger(reState, triggerBar, 1, level);
              expect(triggerResult.triggered).toBe(true);
              expect(triggerResult.awaitingNewBar).toBe(true);

              // Step 2: Complete re-establishment with new bar
              const completeResult = completeReestablishment(
                triggerResult.awaitingNewBar,
                true,
                newCandle
              );
              expect(completeResult.established).toBe(true);
              expect(completeResult.crtHigh).toBe(newCandle.high);
              expect(completeResult.crtLow).toBe(newCandle.low);
              expect(completeResult.awaitingNewBar).toBe(false);
            }
          ),
          { numRuns: 100 }
        );
      });

      it(`${label} bearish: full re-establishment flow produces valid new CRT`, () => {
        fc.assert(
          fc.property(
            reestablishStateArb(-1, level).chain((reState) => {
              const targetPrice =
                level === '5M' ? reState.lastInvalidatedLow! : reState.lastInvalidatedHigh!;
              const barGen =
                level === '5M'
                  ? barBreakingBelow(targetPrice)
                  : barBreakingAbove(targetPrice);
              return fc.tuple(fc.constant(reState), barGen, newCandleArb());
            }),
            ([reState, triggerBar, newCandle]) => {
              // Step 1: Check trigger
              const triggerResult = checkReestablishTrigger(reState, triggerBar, -1, level);
              expect(triggerResult.triggered).toBe(true);
              expect(triggerResult.awaitingNewBar).toBe(true);

              // Step 2: Complete re-establishment with new bar
              const completeResult = completeReestablishment(
                triggerResult.awaitingNewBar,
                true,
                newCandle
              );
              expect(completeResult.established).toBe(true);
              expect(completeResult.crtHigh).toBe(newCandle.high);
              expect(completeResult.crtLow).toBe(newCandle.low);
              expect(completeResult.awaitingNewBar).toBe(false);
            }
          ),
          { numRuns: 100 }
        );
      });
    }
  });
});
