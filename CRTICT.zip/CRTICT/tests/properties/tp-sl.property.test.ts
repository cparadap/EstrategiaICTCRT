import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { calculateTPSL } from '../logic/crt';
import type { Trend } from '../logic/crt';

/**
 * Property 9: TP/SL Calculation Correctness
 *
 * **Validates: Requirements 7.4, 7.5**
 *
 * For any trade entry, the TP shall equal the 4H CRT candle's trend-direction
 * extreme (high for long, low for short), and the SL shall equal the 5M activation
 * candle's counter-trend extreme offset by 5 pips (low - 5*mintick for long,
 * high + 5*mintick for short).
 *
 * From Pine Script:
 * - Long TP: crt4h_high
 * - Long SL: entry_bar_low - (5 * syminfo.mintick)
 * - Short TP: crt4h_low
 * - Short SL: entry_bar_high + (5 * syminfo.mintick)
 */
describe('Feature: ict-crt-strategy, Property 9: TP/SL Calculation Correctness', () => {
  // Generator for realistic price values
  const priceArb = fc.double({ min: 0.01, max: 10000, noNaN: true, noDefaultInfinity: true });

  // Generator for mintick values (common values: 0.01, 0.001, 0.0001, 0.00001)
  const mintickArb = fc.oneof(
    fc.constant(0.01),
    fc.constant(0.001),
    fc.constant(0.0001),
    fc.constant(0.00001),
    fc.double({ min: 0.00001, max: 1, noNaN: true, noDefaultInfinity: true })
  );

  // Generator for a valid 4H CRT range (high > low)
  const crt4hArb = fc
    .record({
      low: fc.double({ min: 100, max: 4999, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: 500, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: low + spread,
      low,
    }));

  // Generator for a valid 5M entry bar (high > low)
  const entryBarArb = fc
    .record({
      low: fc.double({ min: 100, max: 4999, noNaN: true, noDefaultInfinity: true }),
      spread: fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ low, spread }) => ({
      high: low + spread,
      low,
    }));

  describe('Requirement 7.4: Long entry TP/SL calculation', () => {
    it('long TP equals 4H CRT high', () => {
      fc.assert(
        fc.property(crt4hArb, entryBarArb, mintickArb, (crt4h, entryBar, mintick) => {
          const result = calculateTPSL(1, crt4h.high, crt4h.low, entryBar.low, entryBar.high, mintick);

          expect(result.tp).toBe(crt4h.high);
        }),
        { numRuns: 100 }
      );
    });

    it('long SL equals 5M activation candle low minus 5*mintick', () => {
      fc.assert(
        fc.property(crt4hArb, entryBarArb, mintickArb, (crt4h, entryBar, mintick) => {
          const result = calculateTPSL(1, crt4h.high, crt4h.low, entryBar.low, entryBar.high, mintick);

          const expectedSL = entryBar.low - 5 * mintick;
          expect(result.sl).toBeCloseTo(expectedSL, 10);
        }),
        { numRuns: 100 }
      );
    });
  });

  describe('Requirement 7.5: Short entry TP/SL calculation', () => {
    it('short TP equals 4H CRT low', () => {
      fc.assert(
        fc.property(crt4hArb, entryBarArb, mintickArb, (crt4h, entryBar, mintick) => {
          const result = calculateTPSL(-1, crt4h.high, crt4h.low, entryBar.low, entryBar.high, mintick);

          expect(result.tp).toBe(crt4h.low);
        }),
        { numRuns: 100 }
      );
    });

    it('short SL equals 5M activation candle high plus 5*mintick', () => {
      fc.assert(
        fc.property(crt4hArb, entryBarArb, mintickArb, (crt4h, entryBar, mintick) => {
          const result = calculateTPSL(-1, crt4h.high, crt4h.low, entryBar.low, entryBar.high, mintick);

          const expectedSL = entryBar.high + 5 * mintick;
          expect(result.sl).toBeCloseTo(expectedSL, 10);
        }),
        { numRuns: 100 }
      );
    });
  });

  describe('TP/SL structural properties', () => {
    it('long TP is always above long SL (assuming 4H high > 5M entry bar low)', () => {
      fc.assert(
        fc.property(
          // Ensure 4H high > entry bar low (realistic scenario for a long trade)
          fc.double({ min: 200, max: 5000, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
          mintickArb,
          (crt4hHigh, entryBarSpread, crt4hSpread, mintick) => {
            // Entry bar low is below 4H high (realistic long scenario)
            const entryBarLow = crt4hHigh - crt4hSpread - entryBarSpread;
            if (entryBarLow <= 0) return; // skip unrealistic values

            const entryBarHigh = entryBarLow + entryBarSpread;
            const crt4hLow = crt4hHigh - crt4hSpread;

            const result = calculateTPSL(1, crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick);

            // TP (4H high) should be above SL (entry bar low - 5*mintick)
            expect(result.tp).toBeGreaterThan(result.sl);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('short SL is always above short TP (assuming 5M entry bar high > 4H low)', () => {
      fc.assert(
        fc.property(
          // Ensure entry bar high > 4H low (realistic scenario for a short trade)
          fc.double({ min: 100, max: 4900, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
          fc.double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true }),
          mintickArb,
          (crt4hLow, entryBarSpread, crt4hSpread, mintick) => {
            // Entry bar high is above 4H low (realistic short scenario)
            const entryBarHigh = crt4hLow + crt4hSpread + entryBarSpread;
            const entryBarLow = entryBarHigh - entryBarSpread;
            const crt4hHigh = crt4hLow + crt4hSpread;

            const result = calculateTPSL(-1, crt4hHigh, crt4hLow, entryBarLow, entryBarHigh, mintick);

            // SL (entry bar high + 5*mintick) should be above TP (4H low)
            expect(result.sl).toBeGreaterThan(result.tp);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('SL offset is exactly 5*mintick from the entry bar extreme', () => {
      fc.assert(
        fc.property(
          fc.constantFrom<Trend>(1, -1),
          crt4hArb,
          entryBarArb,
          mintickArb,
          (direction, crt4h, entryBar, mintick) => {
            const result = calculateTPSL(
              direction as 1 | -1,
              crt4h.high,
              crt4h.low,
              entryBar.low,
              entryBar.high,
              mintick
            );

            const expectedOffset = 5 * mintick;

            if (direction === 1) {
              // Long: SL = entryBarLow - 5*mintick
              const actualOffset = entryBar.low - result.sl;
              expect(actualOffset).toBeCloseTo(expectedOffset, 10);
            } else {
              // Short: SL = entryBarHigh + 5*mintick
              const actualOffset = result.sl - entryBar.high;
              expect(actualOffset).toBeCloseTo(expectedOffset, 10);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
