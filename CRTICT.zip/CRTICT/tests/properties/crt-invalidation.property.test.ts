import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { checkCrtInvalidation } from '../logic/crt';
import type { CrtRangeState, Trend, CrtLevel, PriceBar } from '../logic/crt';
import { crtRangeArb } from '../generators/crt-range.gen';

/**
 * Feature: ict-crt-strategy, Property 6: CRT Invalidation on Wrong Extreme Break
 *
 * **Validates: Requirements 4.4, 4.5, 5.4, 5.5, 6.4, 6.5, 7.7, 7.8**
 *
 * For any valid but not-yet-activated CRT range, when price breaks the invalidation
 * extreme (upper extreme for bullish trend at 4H/1H/15M, lower extreme for bearish
 * trend at 4H/1H/15M; lower extreme for bullish at 5M, upper extreme for bearish at 5M),
 * the CRT shall be invalidated.
 */

/**
 * Generates a price bar that breaks above the CRT high.
 */
function barBreakingAbove(crtHigh: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true })
    .map((offset) => {
      const high = crtHigh + offset;
      // Low can be anywhere below the high
      const low = crtHigh - offset * 0.5;
      return { high, low: Math.max(low, 0.01) };
    });
}

/**
 * Generates a price bar that breaks below the CRT low.
 */
function barBreakingBelow(crtLow: number): fc.Arbitrary<PriceBar> {
  return fc
    .double({ min: 0.01, max: 100, noNaN: true, noDefaultInfinity: true })
    .map((offset) => {
      const low = crtLow - offset;
      // High can be anywhere above the low
      const high = crtLow + offset * 0.5;
      return { high, low: Math.max(low, 0.01) };
    });
}

/**
 * Generates a price bar that does NOT break above the CRT high
 * and does NOT break below the CRT low (stays within range).
 */
function barWithinRange(crtHigh: number, crtLow: number): fc.Arbitrary<PriceBar> {
  return fc
    .record({
      highFraction: fc.double({ min: 0, max: 1, noNaN: true, noDefaultInfinity: true }),
      lowFraction: fc.double({ min: 0, max: 1, noNaN: true, noDefaultInfinity: true }),
    })
    .map(({ highFraction, lowFraction }) => {
      const range = crtHigh - crtLow;
      const high = crtLow + range * highFraction;
      const low = crtLow + range * lowFraction;
      return {
        high: Math.min(high, crtHigh), // ensure <= crt_high
        low: Math.max(Math.min(low, high), crtLow), // ensure >= crt_low and <= high
      };
    });
}

describe('Feature: ict-crt-strategy, Property 6: CRT Invalidation on Wrong Extreme Break', () => {
  /**
   * Requirements 4.4, 5.4, 6.4:
   * WHILE the trend is bullish, IF price breaks above the upper extreme of the CRT range
   * before activation, THEN the Strategy SHALL invalidate the CRT range.
   */
  describe('Bullish trend - 4H/1H/15M: invalidated when high > crt_high', () => {
    const levels: CrtLevel[] = ['4H', '1H', '15M'];

    for (const level of levels) {
      it(`${level} CRT is invalidated when bar high > crt_high in bullish trend`, () => {
        fc.assert(
          fc.property(
            crtRangeArb('established').chain((crt) =>
              barBreakingAbove(crt.high).map((bar) => ({ crt, bar }))
            ),
            ({ crt, bar }) => {
              const trend: Trend = 1; // bullish

              const result = checkCrtInvalidation(crt, bar, trend, level);

              expect(result.invalidated).toBe(true);
              expect(result.valid).toBe(false);
              expect(result.activated).toBe(false);
            }
          ),
          { numRuns: 100 }
        );
      });
    }
  });

  /**
   * Requirements 4.5, 5.5, 6.5:
   * WHILE the trend is bearish, IF price breaks below the lower extreme of the CRT range
   * before activation, THEN the Strategy SHALL invalidate the CRT range.
   */
  describe('Bearish trend - 4H/1H/15M: invalidated when low < crt_low', () => {
    const levels: CrtLevel[] = ['4H', '1H', '15M'];

    for (const level of levels) {
      it(`${level} CRT is invalidated when bar low < crt_low in bearish trend`, () => {
        fc.assert(
          fc.property(
            crtRangeArb('established').chain((crt) =>
              barBreakingBelow(crt.low).map((bar) => ({ crt, bar }))
            ),
            ({ crt, bar }) => {
              const trend: Trend = -1; // bearish

              const result = checkCrtInvalidation(crt, bar, trend, level);

              expect(result.invalidated).toBe(true);
              expect(result.valid).toBe(false);
              expect(result.activated).toBe(false);
            }
          ),
          { numRuns: 100 }
        );
      });
    }
  });

  /**
   * Requirement 7.7:
   * WHILE the trend is bullish, IF price breaks below the lower extreme of the 5M CRT
   * range before entry activation, THEN the Strategy SHALL invalidate the 5M CRT range.
   */
  describe('Bullish trend - 5M: invalidated when low < crt5m_low', () => {
    it('5M CRT is invalidated when bar low < crt_low in bullish trend', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established').chain((crt) =>
            barBreakingBelow(crt.low).map((bar) => ({ crt, bar }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = 1; // bullish
            const level: CrtLevel = '5M';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            expect(result.invalidated).toBe(true);
            expect(result.valid).toBe(false);
            expect(result.activated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Requirement 7.8:
   * WHILE the trend is bearish, IF price breaks above the upper extreme of the 5M CRT
   * range before entry activation, THEN the Strategy SHALL invalidate the 5M CRT range.
   */
  describe('Bearish trend - 5M: invalidated when high > crt5m_high', () => {
    it('5M CRT is invalidated when bar high > crt_high in bearish trend', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established').chain((crt) =>
            barBreakingAbove(crt.high).map((bar) => ({ crt, bar }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = -1; // bearish
            const level: CrtLevel = '5M';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            expect(result.invalidated).toBe(true);
            expect(result.valid).toBe(false);
            expect(result.activated).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Negative property: CRT is NOT invalidated when price stays within range.
   * This ensures the invalidation logic doesn't trigger false positives.
   */
  describe('No invalidation when price stays within CRT range', () => {
    it('4H/1H/15M CRT remains valid when bar stays within range (bullish)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established').chain((crt) =>
            barWithinRange(crt.high, crt.low).map((bar) => ({ crt, bar }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = 1;
            const level: CrtLevel = '4H';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('4H/1H/15M CRT remains valid when bar stays within range (bearish)', () => {
      fc.assert(
        fc.property(
          crtRangeArb('established').chain((crt) =>
            barWithinRange(crt.high, crt.low).map((bar) => ({ crt, bar }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = -1;
            const level: CrtLevel = '1H';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Property: Already-activated CRT ranges cannot be invalidated.
   * Once a CRT is activated, the invalidation check should be a no-op.
   */
  describe('Already-activated CRT cannot be invalidated', () => {
    it('activated CRT is not invalidated even if price breaks the wrong extreme', () => {
      fc.assert(
        fc.property(
          crtRangeArb('activated').chain((crt) =>
            barBreakingAbove(crt.high).map((bar) => ({ crt, bar }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = 1;
            const level: CrtLevel = '4H';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            // Should not be invalidated because it's already activated
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(true);
            expect(result.activated).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  /**
   * Property: Already-invalid CRT ranges stay invalid.
   */
  describe('Already-invalid CRT stays invalid', () => {
    it('invalid CRT remains invalid regardless of price action', () => {
      fc.assert(
        fc.property(
          crtRangeArb('invalidated').chain((crt) =>
            fc
              .double({ min: 50, max: 5000, noNaN: true, noDefaultInfinity: true })
              .map((price) => ({
                crt,
                bar: { high: price + 10, low: price } as PriceBar,
              }))
          ),
          ({ crt, bar }) => {
            const trend: Trend = 1;
            const level: CrtLevel = '4H';

            const result = checkCrtInvalidation(crt, bar, trend, level);

            // Should not be invalidated (already invalid)
            expect(result.invalidated).toBe(false);
            expect(result.valid).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
