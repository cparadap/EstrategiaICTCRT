import { defineConfig } from 'vitest/config';
import { resolve } from 'path';

export default defineConfig({
  test: {
    globals: true,
    include: ['**/*.{test,property.test}.ts'],
  },
  resolve: {
    alias: {
      '@generators': resolve(__dirname, './generators'),
    },
  },
});
