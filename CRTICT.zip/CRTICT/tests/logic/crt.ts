/**
 * CRT (Candle Range Theory) Logic
 *
 * Mirrors the Pine Script CRT range management logic for:
 * - Establishment: recording high/low from a candle as the CRT range
 * - Activation: price breaks the activation extreme
 * - Invalidation: price breaks the invalidation extreme before activation
 *
 * CRT Establishment Rules (from Pine Script):
 * - 4H CRT: When state == WAIT_OB_TOUCH and price touches OB zone
 *   (low <= ob_high and high >= ob_low), record h4_high/h4_low as crt4h_high/crt4h_low
 * - 1H CRT: When 4H CRT is activated (state == WAIT_1H_CRT) and first new_h1_bar,
 *   record h1_high/h1_low as crt1h_high/crt1h_low
 * - 15M CRT: When 1H CRT is activated (state == WAIT_15M_CRT) and first new_15m_bar,
 *   record m15_high/m15_low as crt15m_high/crt15m_low
 * - 5M CRT: When 15M CRT is activated (state == WAIT_5M_ENTRY) and first 5M bar,
 *   record high/low as crt5m_high/crt5m_low
 *
 * CRT Invalidation Rules (from Pine Script lines ~250-280):
 * - Bullish trend: CRT is invalidated when high > crt_high (price breaks above the range)
 * - Bearish trend: CRT is invalidated when low < crt_low (price breaks below the range)
 *
 * This applies to 4H, 1H, 15M CRT ranges. For 5M CRT:
 * - Bullish trend: invalidated when low < crt5m_low (price breaks below)
 * - Bearish trend: invalidated when high > crt5m_high (price breaks above)
 *
 * Validates: Requirements 4.1-4.5, 5.1-5.5, 6.1-6.5, 7.1-7.8
 */

export interface CrtRangeState {
  high: number;
  low: number;
  valid: boolean;
  activated: boolean;
}

export type Trend = 1 | -1;

export type CrtLevel = '4H' | '1H' | '15M' | '5M';

export interface PriceBar {
  high: number;
  low: number;
}

export interface CrtCheckResult {
  valid: boolean;
  activated: boolean;
  invalidated: boolean;
}

/**
 * Checks whether a CRT range is invalidated by a price bar.
 *
 * Invalidation occurs when price breaks the "wrong" extreme before activation:
 * - For 4H/1H/15M in bullish trend: invalidated when bar high > crt_high
 * - For 4H/1H/15M in bearish trend: invalidated when bar low < crt_low
 * - For 5M in bullish trend: invalidated when bar low < crt5m_low
 * - For 5M in bearish trend: invalidated when bar high > crt5m_high
 *
 * @param crt - The current CRT range state (must be valid and not activated)
 * @param bar - The price bar to check against
 * @param trend - Current trend direction (1 = bullish, -1 = bearish)
 * @param level - The CRT timeframe level
 * @returns Result indicating whether the CRT was invalidated
 */
export function checkCrtInvalidation(
  crt: CrtRangeState,
  bar: PriceBar,
  trend: Trend,
  level: CrtLevel
): CrtCheckResult {
  // Only check invalidation on valid, non-activated CRT ranges
  if (!crt.valid || crt.activated) {
    return { valid: crt.valid, activated: crt.activated, invalidated: false };
  }

  if (level === '5M') {
    // 5M has inverted invalidation logic compared to higher TFs
    // Bullish: invalidated when low < crt_low (price breaks below before entry)
    // Bearish: invalidated when high > crt_high (price breaks above before entry)
    if (trend === 1 && bar.low < crt.low) {
      return { valid: false, activated: false, invalidated: true };
    }
    if (trend === -1 && bar.high > crt.high) {
      return { valid: false, activated: false, invalidated: true };
    }
  } else {
    // 4H, 1H, 15M invalidation logic
    // Bullish: invalidated when high > crt_high (price breaks above the range)
    // Bearish: invalidated when low < crt_low (price breaks below the range)
    if (trend === 1 && bar.high > crt.high) {
      return { valid: false, activated: false, invalidated: true };
    }
    if (trend === -1 && bar.low < crt.low) {
      return { valid: false, activated: false, invalidated: true };
    }
  }

  // No invalidation occurred
  return { valid: true, activated: false, invalidated: false };
}

/**
 * Checks whether a CRT range is activated by a price bar.
 *
 * Activation occurs when price breaks the "correct" extreme:
 * - For 4H/1H/15M in bullish trend: activated when bar low < crt_low
 * - For 4H/1H/15M in bearish trend: activated when bar high > crt_high
 * - For 5M in bullish trend: activated (entry) when bar high > crt5m_high
 * - For 5M in bearish trend: activated (entry) when bar low < crt5m_low
 *
 * @param crt - The current CRT range state (must be valid and not activated)
 * @param bar - The price bar to check against
 * @param trend - Current trend direction (1 = bullish, -1 = bearish)
 * @param level - The CRT timeframe level
 * @returns Result indicating whether the CRT was activated
 */
export function checkCrtActivation(
  crt: CrtRangeState,
  bar: PriceBar,
  trend: Trend,
  level: CrtLevel
): CrtCheckResult {
  // Only check activation on valid, non-activated CRT ranges
  if (!crt.valid || crt.activated) {
    return { valid: crt.valid, activated: crt.activated, invalidated: false };
  }

  if (level === '5M') {
    // 5M entry trigger (activation equivalent)
    // Bullish: entry when high > crt5m_high
    // Bearish: entry when low < crt5m_low
    if (trend === 1 && bar.high > crt.high) {
      return { valid: true, activated: true, invalidated: false };
    }
    if (trend === -1 && bar.low < crt.low) {
      return { valid: true, activated: true, invalidated: false };
    }
  } else {
    // 4H, 1H, 15M activation logic
    // Bullish: activated when low < crt_low (price breaks below)
    // Bearish: activated when high > crt_high (price breaks above)
    if (trend === 1 && bar.low < crt.low) {
      return { valid: true, activated: true, invalidated: false };
    }
    if (trend === -1 && bar.high > crt.high) {
      return { valid: true, activated: true, invalidated: false };
    }
  }

  // No activation occurred
  return { valid: true, activated: false, invalidated: false };
}

/**
 * Processes a price bar against a CRT range, checking both activation and invalidation.
 * In the Pine Script, invalidation is checked with `else if`, meaning activation takes
 * priority when both conditions could theoretically be met on the same bar.
 *
 * @param crt - The current CRT range state
 * @param bar - The price bar to check
 * @param trend - Current trend direction
 * @param level - The CRT timeframe level
 * @returns Updated CRT check result
 */
export function processCrtBar(
  crt: CrtRangeState,
  bar: PriceBar,
  trend: Trend,
  level: CrtLevel
): CrtCheckResult {
  if (!crt.valid || crt.activated) {
    return { valid: crt.valid, activated: crt.activated, invalidated: false };
  }

  // Check activation first (matches Pine Script if/else if pattern)
  const activationResult = checkCrtActivation(crt, bar, trend, level);
  if (activationResult.activated) {
    return activationResult;
  }

  // Then check invalidation
  const invalidationResult = checkCrtInvalidation(crt, bar, trend, level);
  if (invalidationResult.invalidated) {
    return invalidationResult;
  }

  // Neither activation nor invalidation
  return { valid: true, activated: false, invalidated: false };
}


// ============================================================================
// CRT RANGE ESTABLISHMENT LOGIC
// ============================================================================

/** State machine constants matching Pine Script */
export const STATE = {
  IDLE: 0,
  WAIT_OB_TOUCH: 1,
  WAIT_4H_ACTIVATION: 2,
  WAIT_1H_CRT: 3,
  WAIT_15M_CRT: 4,
  WAIT_5M_ENTRY: 5,
  POSITION_OPEN: 6,
} as const;

export type StateValue = (typeof STATE)[keyof typeof STATE];

/** Represents an Order Block zone for establishment checks */
export interface OrderBlock {
  high: number;
  low: number;
}

/** Input candle data for a specific timeframe */
export interface TimeframeCandle {
  high: number;
  low: number;
}

/** Result of a 4H CRT establishment attempt */
export interface Establish4HResult {
  established: boolean;
  crtHigh: number | null;
  crtLow: number | null;
  newState: StateValue;
}

/** Result of a lower-timeframe CRT establishment attempt */
export interface EstablishLowerTFResult {
  established: boolean;
  crtHigh: number | null;
  crtLow: number | null;
}

/**
 * Determines if the current bar touches the Order Block zone.
 * OB touch: low <= ob_high AND high >= ob_low (price range overlaps OB zone)
 *
 * @param barHigh - Current bar's high price
 * @param barLow - Current bar's low price
 * @param ob - The Order Block zone
 * @returns true if the bar touches/enters the OB zone
 */
export function isOBTouch(barHigh: number, barLow: number, ob: OrderBlock): boolean {
  return barLow <= ob.high && barHigh >= ob.low;
}

/**
 * Establishes a 4H CRT range when price touches the Order Block.
 *
 * Mirrors Pine Script logic:
 * - State must be WAIT_OB_TOUCH
 * - OB must be valid
 * - Current bar must touch OB zone (low <= ob_high and high >= ob_low)
 * - On touch: record h4_high/h4_low as CRT range, transition to WAIT_4H_ACTIVATION
 *
 * @param currentState - Current state machine state
 * @param barHigh - Current 5M bar's high
 * @param barLow - Current 5M bar's low
 * @param ob - The Order Block zone
 * @param h4Candle - The current 4H candle OHLC (high/low used for CRT range)
 * @returns The establishment result
 */
export function establish4HCRT(
  currentState: StateValue,
  barHigh: number,
  barLow: number,
  ob: OrderBlock,
  h4Candle: TimeframeCandle
): Establish4HResult {
  if (currentState !== STATE.WAIT_OB_TOUCH) {
    return { established: false, crtHigh: null, crtLow: null, newState: currentState };
  }

  if (isOBTouch(barHigh, barLow, ob)) {
    return {
      established: true,
      crtHigh: h4Candle.high,
      crtLow: h4Candle.low,
      newState: STATE.WAIT_4H_ACTIVATION,
    };
  }

  return { established: false, crtHigh: null, crtLow: null, newState: currentState };
}

/**
 * Establishes a 1H CRT range on the first 1H bar after 4H CRT activation.
 *
 * Mirrors Pine Script logic:
 * - State must be WAIT_1H_CRT
 * - Must be a new 1H bar (first one after activation)
 * - Record h1_high/h1_low as CRT range
 *
 * @param currentState - Current state machine state
 * @param newH1Bar - Whether this is a new 1H bar
 * @param h1Candle - The current 1H candle (high/low)
 * @param alreadyEstablished - Whether a 1H CRT is already established (valid)
 * @returns The establishment result
 */
export function establish1HCRT(
  currentState: StateValue,
  newH1Bar: boolean,
  h1Candle: TimeframeCandle,
  alreadyEstablished: boolean
): EstablishLowerTFResult {
  if (currentState !== STATE.WAIT_1H_CRT) {
    return { established: false, crtHigh: null, crtLow: null };
  }

  if (newH1Bar && !alreadyEstablished) {
    return {
      established: true,
      crtHigh: h1Candle.high,
      crtLow: h1Candle.low,
    };
  }

  return { established: false, crtHigh: null, crtLow: null };
}

/**
 * Establishes a 15M CRT range on the first 15M bar after 1H CRT activation.
 *
 * Mirrors Pine Script logic:
 * - State must be WAIT_15M_CRT
 * - Must be a new 15M bar (first one after activation)
 * - Record m15_high/m15_low as CRT range
 *
 * @param currentState - Current state machine state
 * @param new15MBar - Whether this is a new 15M bar
 * @param m15Candle - The current 15M candle (high/low)
 * @param alreadyEstablished - Whether a 15M CRT is already established (valid)
 * @returns The establishment result
 */
export function establish15MCRT(
  currentState: StateValue,
  new15MBar: boolean,
  m15Candle: TimeframeCandle,
  alreadyEstablished: boolean
): EstablishLowerTFResult {
  if (currentState !== STATE.WAIT_15M_CRT) {
    return { established: false, crtHigh: null, crtLow: null };
  }

  if (new15MBar && !alreadyEstablished) {
    return {
      established: true,
      crtHigh: m15Candle.high,
      crtLow: m15Candle.low,
    };
  }

  return { established: false, crtHigh: null, crtLow: null };
}

/**
 * Establishes a 5M CRT range on the first 5M bar after 15M CRT activation.
 *
 * Mirrors Pine Script logic:
 * - State must be WAIT_5M_ENTRY
 * - First 5M bar after 15M activation
 * - Record high/low as CRT range
 *
 * @param currentState - Current state machine state
 * @param m5Candle - The current 5M candle (high/low)
 * @param alreadyEstablished - Whether a 5M CRT is already established (valid)
 * @returns The establishment result
 */
export function establish5MCRT(
  currentState: StateValue,
  m5Candle: TimeframeCandle,
  alreadyEstablished: boolean
): EstablishLowerTFResult {
  if (currentState !== STATE.WAIT_5M_ENTRY) {
    return { established: false, crtHigh: null, crtLow: null };
  }

  if (!alreadyEstablished) {
    return {
      established: true,
      crtHigh: m5Candle.high,
      crtLow: m5Candle.low,
    };
  }

  return { established: false, crtHigh: null, crtLow: null };
}


// ============================================================================
// CRT RE-ESTABLISHMENT LOGIC
// ============================================================================

/**
 * Represents the state needed for CRT re-establishment checks.
 */
export interface CrtReestablishmentState {
  /** Whether the child CRT is currently valid */
  childValid: boolean;
  /** Whether the child CRT is awaiting a new bar for re-establishment */
  awaitingNewBar: boolean;
  /** The last invalidated low (stored on bullish invalidation) */
  lastInvalidatedLow: number | null;
  /** The last invalidated high (stored on bearish invalidation) */
  lastInvalidatedHigh: number | null;
  /** Whether the parent CRT is valid and activated */
  parentValid: boolean;
  parentActivated: boolean;
}

/**
 * Result of a re-establishment trigger check.
 */
export interface ReestablishTriggerResult {
  /** Whether the re-establishment trigger condition was met */
  triggered: boolean;
  /** Whether the system is now awaiting a new bar to establish the CRT */
  awaitingNewBar: boolean;
}

/**
 * Result of a re-establishment completion (new bar arrives).
 */
export interface ReestablishCompleteResult {
  /** Whether a new CRT was established */
  established: boolean;
  /** The new CRT high (from the new bar) */
  crtHigh: number | null;
  /** The new CRT low (from the new bar) */
  crtLow: number | null;
  /** Whether the awaiting flag was cleared */
  awaitingNewBar: boolean;
}

/**
 * Checks whether the re-establishment trigger condition is met.
 *
 * Re-establishment trigger logic (from Pine Script):
 * - The child CRT must be invalid (not valid)
 * - The child must NOT already be awaiting a new bar
 * - The parent CRT must be valid and activated
 * - For 1H/15M (bullish): price low < last_invalidated_low
 * - For 1H/15M (bearish): price high > last_invalidated_high
 * - For 5M (bullish): price high > last_invalidated_high (inverted vs higher TFs)
 * - For 5M (bearish): price low < last_invalidated_low (inverted vs higher TFs)
 *
 * @param reState - The re-establishment state
 * @param bar - The current price bar
 * @param trend - Current trend direction
 * @param level - The CRT timeframe level being re-established
 * @returns Whether the trigger condition was met
 */
export function checkReestablishTrigger(
  reState: CrtReestablishmentState,
  bar: PriceBar,
  trend: Trend,
  level: CrtLevel
): ReestablishTriggerResult {
  // Pre-conditions: child must be invalid, not already awaiting, parent must be valid+activated
  if (reState.childValid || reState.awaitingNewBar) {
    return { triggered: false, awaitingNewBar: reState.awaitingNewBar };
  }

  if (!reState.parentValid || !reState.parentActivated) {
    return { triggered: false, awaitingNewBar: false };
  }

  if (level === '5M') {
    // 5M re-establishment has inverted logic compared to 1H/15M:
    // Bullish: price high > last_invalidated_high → trigger
    // Bearish: price low < last_invalidated_low → trigger
    if (trend === 1 && reState.lastInvalidatedHigh !== null && bar.high > reState.lastInvalidatedHigh) {
      return { triggered: true, awaitingNewBar: true };
    }
    if (trend === -1 && reState.lastInvalidatedLow !== null && bar.low < reState.lastInvalidatedLow) {
      return { triggered: true, awaitingNewBar: true };
    }
  } else {
    // 1H, 15M re-establishment logic:
    // Bullish: price low < last_invalidated_low → trigger
    // Bearish: price high > last_invalidated_high → trigger
    if (trend === 1 && reState.lastInvalidatedLow !== null && bar.low < reState.lastInvalidatedLow) {
      return { triggered: true, awaitingNewBar: true };
    }
    if (trend === -1 && reState.lastInvalidatedHigh !== null && bar.high > reState.lastInvalidatedHigh) {
      return { triggered: true, awaitingNewBar: true };
    }
  }

  return { triggered: false, awaitingNewBar: false };
}

/**
 * Completes the re-establishment by establishing a new CRT from the new bar.
 *
 * This is called when a new bar arrives at the child timeframe while
 * `awaitingNewBar` is true. The new bar's high/low become the new CRT range.
 *
 * @param awaitingNewBar - Whether the system is awaiting a new bar
 * @param newBar - Whether a new bar has arrived at the child timeframe
 * @param candle - The new candle's high/low
 * @returns The result of the re-establishment completion
 */
export function completeReestablishment(
  awaitingNewBar: boolean,
  newBar: boolean,
  candle: TimeframeCandle
): ReestablishCompleteResult {
  if (!awaitingNewBar || !newBar) {
    return { established: false, crtHigh: null, crtLow: null, awaitingNewBar };
  }

  return {
    established: true,
    crtHigh: candle.high,
    crtLow: candle.low,
    awaitingNewBar: false,
  };
}


// ============================================================================
// TIME LIMIT INVALIDATION LOGIC
// ============================================================================

/**
 * Represents the full strategy state relevant for time limit checks.
 */
export interface TimeLimitState {
  /** Current state machine state */
  state: StateValue;
  /** Whether a new 4H bar has opened */
  newH4Bar: boolean;
  /** The timestamp when the 4H CRT was established (ms) */
  crt4hSetupTime: number | null;
  /** Current bar time (ms) */
  currentTime: number;
}

/**
 * Result of a time limit invalidation check.
 */
export interface TimeLimitResult {
  /** Whether the time limit was triggered and all state was invalidated */
  invalidated: boolean;
  /** The new state after the check */
  newState: StateValue;
}

/**
 * Checks whether the time limit invalidation condition is met.
 *
 * Mirrors Pine Script logic:
 * - State must NOT be IDLE (0) and NOT be POSITION_OPEN (6)
 * - A new 4H bar must have opened (new_h4_bar == true)
 * - Current time must exceed setup time + 4 hours (4 * 60 * 60 * 1000 ms)
 *
 * When all conditions are met, f_invalidate_all() is called which:
 * - Resets state to IDLE
 * - Clears all CRT valid/activated flags
 * - Clears all OB and entry/exit state
 *
 * @param input - The time limit check input state
 * @returns Whether invalidation was triggered and the resulting state
 *
 * Validates: Requirements 8.1
 */
export function checkTimeLimitInvalidation(input: TimeLimitState): TimeLimitResult {
  const FOUR_HOURS_MS = 4 * 60 * 60 * 1000;

  // Only check when not IDLE and not POSITION_OPEN
  if (input.state === STATE.IDLE || input.state === STATE.POSITION_OPEN) {
    return { invalidated: false, newState: input.state };
  }

  // Must be a new 4H bar
  if (!input.newH4Bar) {
    return { invalidated: false, newState: input.state };
  }

  // Setup time must be set
  if (input.crt4hSetupTime === null) {
    return { invalidated: false, newState: input.state };
  }

  // Check if current time exceeds setup time + 4 hours
  if (input.currentTime > input.crt4hSetupTime + FOUR_HOURS_MS) {
    // Time limit exceeded - invalidate all
    return { invalidated: true, newState: STATE.IDLE };
  }

  return { invalidated: false, newState: input.state };
}


// ============================================================================
// TP/SL CALCULATION LOGIC
// ============================================================================

/**
 * Result of TP/SL calculation for a trade entry.
 */
export interface TPSLResult {
  /** Take Profit price level */
  tp: number;
  /** Stop Loss price level */
  sl: number;
}

/**
 * Calculates Take Profit and Stop Loss levels for a trade entry.
 *
 * Mirrors Pine Script logic:
 * - Long TP: crt4h_high (high of the 4H CRT candle)
 * - Long SL: entry_bar_low - (5 * syminfo.mintick) (low of 5M activation candle minus 5 ticks)
 * - Short TP: crt4h_low (low of the 4H CRT candle)
 * - Short SL: entry_bar_high + (5 * syminfo.mintick) (high of 5M activation candle plus 5 ticks)
 *
 * @param tradeDirection - 1 for long, -1 for short
 * @param crt4hHigh - High of the 4H CRT candle
 * @param crt4hLow - Low of the 4H CRT candle
 * @param entryBarLow - Low of the 5M activation candle (used for long SL)
 * @param entryBarHigh - High of the 5M activation candle (used for short SL)
 * @param mintick - The minimum tick size (syminfo.mintick)
 * @returns The calculated TP and SL levels
 *
 * Validates: Requirements 7.4, 7.5
 */
export function calculateTPSL(
  tradeDirection: 1 | -1,
  crt4hHigh: number,
  crt4hLow: number,
  entryBarLow: number,
  entryBarHigh: number,
  mintick: number
): TPSLResult {
  if (tradeDirection === 1) {
    // Long trade
    return {
      tp: crt4hHigh,
      sl: entryBarLow - 5 * mintick,
    };
  } else {
    // Short trade
    return {
      tp: crt4hLow,
      sl: entryBarHigh + 5 * mintick,
    };
  }
}
