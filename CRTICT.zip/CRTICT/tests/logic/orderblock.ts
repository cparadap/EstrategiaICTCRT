/**
 * Order Block Identification Logic
 *
 * Mirrors the Pine Script order block detection (lines 215-240):
 *
 * - Bullish trend + new_swing_low: OB = last bearish candle before the bullish impulse
 *   → ob_high = last_bear_high, ob_low = last_bear_low
 * - Bearish trend + new_swing_high: OB = last bullish candle before the bearish impulse
 *   → ob_high = last_bull_high, ob_low = last_bull_low
 * - Only triggers when state == IDLE
 *
 * The OB is the last candle of the contrary type before the impulse group started.
 * In a bullish trend swing low scenario (≥3 bearish then ≥3 bullish), the OB is the
 * last bearish candle (its high and low).
 * In a bearish trend swing high scenario (≥3 bullish then ≥3 bearish), the OB is the
 * last bullish candle (its high and low).
 *
 * Validates: Requirements 3.1, 3.2, 3.3
 */

import type { Candle } from './swing';
import { detectSwing, initialSwingState } from './swing';

export interface OrderBlock {
  obHigh: number;
  obLow: number;
  valid: boolean;
}

export interface OrderBlockState {
  /** High of the last bearish candle seen (for bullish trend OB) */
  lastBearHigh: number | null;
  /** Low of the last bearish candle seen (for bullish trend OB) */
  lastBearLow: number | null;
  /** High of the last bullish candle seen (for bearish trend OB) */
  lastBullHigh: number | null;
  /** Low of the last bullish candle seen (for bearish trend OB) */
  lastBullLow: number | null;
}

export function initialOrderBlockState(): OrderBlockState {
  return {
    lastBearHigh: null,
    lastBearLow: null,
    lastBullHigh: null,
    lastBullLow: null,
  };
}

/**
 * Updates the order block tracking state for a single candle.
 * This mirrors the Pine Script logic that tracks last_bear_high, last_bear_low,
 * last_bull_high, last_bull_low as candles are processed.
 *
 * @param candle - The 4H OHLC candle
 * @param state - The current OB tracking state
 * @returns Updated OB tracking state
 */
export function updateOrderBlockState(
  candle: Candle,
  state: OrderBlockState
): OrderBlockState {
  const s = { ...state };

  const isBullish = candle.close > candle.open;
  const isBearish = candle.close < candle.open;

  if (isBullish) {
    s.lastBullHigh = candle.high;
    s.lastBullLow = candle.low;
  } else if (isBearish) {
    s.lastBearHigh = candle.high;
    s.lastBearLow = candle.low;
  }
  // Doji: no update to last bull/bear tracking

  return s;
}

/**
 * Identifies the order block when a swing point event occurs.
 *
 * @param trend - Current trend: 1 = bullish, -1 = bearish
 * @param newSwingHigh - Whether a new swing high was just detected
 * @param newSwingLow - Whether a new swing low was just detected
 * @param obState - The current OB tracking state (last bull/bear candle highs/lows)
 * @returns The identified order block, or null if conditions not met
 */
export function identifyOrderBlock(
  trend: number,
  newSwingHigh: boolean,
  newSwingLow: boolean,
  obState: OrderBlockState
): OrderBlock | null {
  // Bearish trend + new_swing_high: OB = last bullish candle before the bearish impulse
  if (newSwingHigh && trend === -1) {
    if (obState.lastBullHigh !== null && obState.lastBullLow !== null) {
      return {
        obHigh: obState.lastBullHigh,
        obLow: obState.lastBullLow,
        valid: true,
      };
    }
  }

  // Bullish trend + new_swing_low: OB = last bearish candle before the bullish impulse
  if (newSwingLow && trend === 1) {
    if (obState.lastBearHigh !== null && obState.lastBearLow !== null) {
      return {
        obHigh: obState.lastBearHigh,
        obLow: obState.lastBearLow,
        valid: true,
      };
    }
  }

  return null;
}

/**
 * Processes a sequence of candles and identifies order blocks at swing points.
 * Combines swing detection with OB identification.
 *
 * This function processes candles one by one, tracking both the swing state and
 * the OB state, and returns the OB identified at each swing event.
 *
 * @param candles - The sequence of 4H candles
 * @param trend - Current trend: 1 = bullish, -1 = bearish
 * @returns Array of results, one per candle, with OB identification info
 */
export function detectOrderBlocksInSequence(
  candles: Candle[],
  trend: number
): Array<{
  orderBlock: OrderBlock | null;
  obState: OrderBlockState;
  newSwingHigh: boolean;
  newSwingLow: boolean;
}> {
  let swingState = initialSwingState();
  let obState = initialOrderBlockState();
  const results: Array<{
    orderBlock: OrderBlock | null;
    obState: OrderBlockState;
    newSwingHigh: boolean;
    newSwingLow: boolean;
  }> = [];

  for (const candle of candles) {
    // Update OB state BEFORE swing detection (mirrors Pine Script order)
    // In Pine Script, the candle classification and last_bear/last_bull tracking
    // happens in the same block as swing detection
    obState = updateOrderBlockState(candle, obState);

    // Detect swing
    const swingResult = detectSwing(candle, trend, swingState);
    swingState = swingResult.state;

    // Identify OB if swing event occurred
    const orderBlock = identifyOrderBlock(
      trend,
      swingResult.newSwingHigh,
      swingResult.newSwingLow,
      obState
    );

    results.push({
      orderBlock,
      obState: { ...obState },
      newSwingHigh: swingResult.newSwingHigh,
      newSwingLow: swingResult.newSwingLow,
    });
  }

  return results;
}
