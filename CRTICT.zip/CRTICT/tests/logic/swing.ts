/**
 * Swing Detection Logic
 *
 * Mirrors the Pine Script swing detection (lines 120-213):
 *
 * Bullish trend:
 *   - After ≥3 bearish (pullback) then ≥3 bullish (impulse) → Swing_Low = lowest low in pullback group
 *   - After ≥3 bullish (impulse) then ≥3 bearish → Swing_High = high of last bullish candle before bearish sequence
 *
 * Bearish trend:
 *   - After ≥3 bullish (pullback) then ≥3 bearish (impulse) → Swing_High = highest high in pullback group
 *   - After ≥3 bearish (impulse) then ≥3 bullish → Swing_Low = low of last bearish candle before bullish sequence
 *
 * Doji (open == close) resets both consecutive counters.
 *
 * Validates: Requirements 2.1, 2.2, 2.3, 2.4
 */

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface SwingState {
  consecBull: number;
  consecBear: number;
  prevConsecBull: number;
  prevConsecBear: number;
  lastBullHigh: number | null;
  lastBearLow: number | null;
  pullbackLows: number[];
  pullbackHighs: number[];
}

export interface SwingResult {
  newSwingHigh: boolean;
  newSwingLow: boolean;
  swingHighPrice: number | null;
  swingLowPrice: number | null;
  state: SwingState;
}

export function initialSwingState(): SwingState {
  return {
    consecBull: 0,
    consecBear: 0,
    prevConsecBull: 0,
    prevConsecBear: 0,
    lastBullHigh: null,
    lastBearLow: null,
    pullbackLows: [],
    pullbackHighs: [],
  };
}

/**
 * Processes a single 4H candle for swing detection.
 *
 * @param candle - The 4H OHLC candle
 * @param trend - Current trend: 1 = bullish, -1 = bearish
 * @param state - The current swing detection state
 * @returns The swing detection result including any new swing points
 */
export function detectSwing(
  candle: Candle,
  trend: number,
  state: SwingState
): SwingResult {
  // Clone state to avoid mutation
  const s: SwingState = {
    consecBull: state.consecBull,
    consecBear: state.consecBear,
    prevConsecBull: state.prevConsecBull,
    prevConsecBear: state.prevConsecBear,
    lastBullHigh: state.lastBullHigh,
    lastBearLow: state.lastBearLow,
    pullbackLows: [...state.pullbackLows],
    pullbackHighs: [...state.pullbackHighs],
  };

  let newSwingHigh = false;
  let newSwingLow = false;
  let swingHighPrice: number | null = null;
  let swingLowPrice: number | null = null;

  // Classify the candle
  const isBullish = candle.close > candle.open;
  const isBearish = candle.close < candle.open;
  const isDoji = candle.close === candle.open;

  if (isDoji) {
    // Doji: reset both consecutive counters
    s.consecBull = 0;
    s.consecBear = 0;
  } else if (isBullish) {
    // Bullish candle
    if (s.consecBear > 0) {
      // Transition from bearish to bullish sequence
      s.prevConsecBear = s.consecBear;
    }
    s.consecBull += 1;
    s.consecBear = 0;
    // Track the high of this bullish candle
    s.lastBullHigh = candle.high;
    // Track pullback highs during bullish sequence (for bearish trend pullback)
    if (trend === -1) {
      s.pullbackHighs.push(candle.high);
    }
  } else if (isBearish) {
    // Bearish candle
    if (s.consecBull > 0) {
      // Transition from bullish to bearish sequence
      s.prevConsecBull = s.consecBull;
    }
    s.consecBear += 1;
    s.consecBull = 0;
    // Track the low of this bearish candle
    s.lastBearLow = candle.low;
    // Track pullback lows during bearish sequence (for bullish trend pullback)
    if (trend === 1) {
      s.pullbackLows.push(candle.low);
    }
  }

  // === BULLISH TREND SWING DETECTION ===
  if (trend === 1) {
    // Swing Low: after ≥3 bearish (pullback) then ≥3 bullish (impulse)
    if (s.consecBull === 3 && s.prevConsecBear >= 3) {
      if (s.pullbackLows.length > 0) {
        swingLowPrice = Math.min(...s.pullbackLows);
        newSwingLow = true;
      }
      s.pullbackLows = [];
    }

    // Swing High: after ≥3 bullish (impulse) then ≥3 bearish
    if (s.consecBear === 3 && s.prevConsecBull >= 3) {
      if (s.lastBullHigh !== null) {
        swingHighPrice = s.lastBullHigh;
        newSwingHigh = true;
      }
      s.pullbackLows = [];
    }
  }

  // === BEARISH TREND SWING DETECTION ===
  if (trend === -1) {
    // Swing High: after ≥3 bullish (pullback) then ≥3 bearish (impulse)
    if (s.consecBear === 3 && s.prevConsecBull >= 3) {
      if (s.pullbackHighs.length > 0) {
        swingHighPrice = Math.max(...s.pullbackHighs);
        newSwingHigh = true;
      }
      s.pullbackHighs = [];
    }

    // Swing Low: after ≥3 bearish (impulse) then ≥3 bullish
    if (s.consecBull === 3 && s.prevConsecBear >= 3) {
      if (s.lastBearLow !== null) {
        swingLowPrice = s.lastBearLow;
        newSwingLow = true;
      }
      s.pullbackHighs = [];
    }
  }

  return {
    newSwingHigh,
    newSwingLow,
    swingHighPrice,
    swingLowPrice,
    state: s,
  };
}

/**
 * Processes a sequence of candles and returns all swing results.
 * Useful for testing transitions over multiple candles.
 */
export function detectSwingSequence(
  candles: Candle[],
  trend: number,
  initialState: SwingState = initialSwingState()
): SwingResult[] {
  const results: SwingResult[] = [];
  let state = initialState;

  for (const candle of candles) {
    const result = detectSwing(candle, trend, state);
    results.push(result);
    state = result.state;
  }

  return results;
}
