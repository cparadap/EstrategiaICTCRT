/**
 * State Machine Transition Logic
 *
 * Models the finite state machine transitions from the Pine Script strategy.
 * The state machine governs the CRT cascade flow:
 *   IDLE → WAIT_OB_TOUCH → WAIT_4H_ACTIVATION → WAIT_1H_CRT → WAIT_15M_CRT → WAIT_5M_ENTRY → POSITION_OPEN → IDLE
 *
 * Validates: Requirements 11.2, 11.3
 */

import { STATE, type StateValue } from './crt';

// ============================================================================
// EVENT TYPES
// ============================================================================

export type StateMachineEvent =
  | { type: 'OB_IDENTIFIED' }
  | { type: 'OB_TOUCHED' }
  | { type: 'CRT_4H_ACTIVATED' }
  | { type: 'CRT_4H_INVALIDATED' }
  | { type: 'CRT_1H_ACTIVATED' }
  | { type: 'CRT_15M_ACTIVATED' }
  | { type: 'CRT_5M_ENTRY_TRIGGERED' }
  | { type: 'POSITION_CLOSED' }
  | { type: 'TREND_CHANGED' }
  | { type: 'TIME_LIMIT_EXCEEDED' };

// ============================================================================
// VALID TRANSITIONS MAP
// ============================================================================

/**
 * Defines valid transitions for each state.
 * Key: current state, Value: map of event type → next state
 */
const TRANSITIONS: Record<StateValue, Partial<Record<StateMachineEvent['type'], StateValue>>> = {
  [STATE.IDLE]: {
    OB_IDENTIFIED: STATE.WAIT_OB_TOUCH,
  },
  [STATE.WAIT_OB_TOUCH]: {
    OB_TOUCHED: STATE.WAIT_4H_ACTIVATION,
    TREND_CHANGED: STATE.IDLE,
    TIME_LIMIT_EXCEEDED: STATE.IDLE,
  },
  [STATE.WAIT_4H_ACTIVATION]: {
    CRT_4H_ACTIVATED: STATE.WAIT_1H_CRT,
    CRT_4H_INVALIDATED: STATE.IDLE,
    TREND_CHANGED: STATE.IDLE,
    TIME_LIMIT_EXCEEDED: STATE.IDLE,
  },
  [STATE.WAIT_1H_CRT]: {
    CRT_1H_ACTIVATED: STATE.WAIT_15M_CRT,
    TREND_CHANGED: STATE.IDLE,
    TIME_LIMIT_EXCEEDED: STATE.IDLE,
  },
  [STATE.WAIT_15M_CRT]: {
    CRT_15M_ACTIVATED: STATE.WAIT_5M_ENTRY,
    TREND_CHANGED: STATE.IDLE,
    TIME_LIMIT_EXCEEDED: STATE.IDLE,
  },
  [STATE.WAIT_5M_ENTRY]: {
    CRT_5M_ENTRY_TRIGGERED: STATE.POSITION_OPEN,
    TREND_CHANGED: STATE.IDLE,
    TIME_LIMIT_EXCEEDED: STATE.IDLE,
  },
  [STATE.POSITION_OPEN]: {
    POSITION_CLOSED: STATE.IDLE,
  },
};

// ============================================================================
// TRANSITION FUNCTION
// ============================================================================

/**
 * Applies a state machine event and returns the new state.
 *
 * If the event is not valid for the current state, the state is unchanged (no-op).
 * This mirrors the Pine Script behavior where invalid events are simply ignored.
 *
 * @param currentState - The current state machine state
 * @param event - The event to apply
 * @returns The new state after applying the event
 */
export function transition(currentState: StateValue, event: StateMachineEvent): StateValue {
  const stateTransitions = TRANSITIONS[currentState];
  if (!stateTransitions) {
    return currentState;
  }

  const nextState = stateTransitions[event.type];
  if (nextState === undefined) {
    return currentState; // Invalid transition → no-op
  }

  return nextState;
}

/**
 * Applies trend change invalidation logic.
 *
 * When the trend changes, any active setup state (WAIT_OB_TOUCH through WAIT_5M_ENTRY)
 * is reset to IDLE. IDLE and POSITION_OPEN are exempt.
 *
 * @param currentState - The current state machine state
 * @param trendChanged - Whether the trend has changed direction
 * @returns The new state after applying trend change invalidation
 */
export function applyTrendChangeInvalidation(
  currentState: StateValue,
  trendChanged: boolean
): StateValue {
  if (!trendChanged) {
    return currentState;
  }

  // Trend changed: invalidate if in an active setup state
  if (currentState !== STATE.IDLE && currentState !== STATE.POSITION_OPEN) {
    return STATE.IDLE;
  }

  return currentState;
}

/**
 * Checks whether a state is an "active setup" state
 * (between IDLE and POSITION_OPEN, where a setup is in progress).
 */
export function isActiveSetupState(state: StateValue): boolean {
  return (
    state === STATE.WAIT_OB_TOUCH ||
    state === STATE.WAIT_4H_ACTIVATION ||
    state === STATE.WAIT_1H_CRT ||
    state === STATE.WAIT_15M_CRT ||
    state === STATE.WAIT_5M_ENTRY
  );
}

/**
 * Returns all valid events for a given state.
 */
export function validEventsForState(state: StateValue): StateMachineEvent['type'][] {
  const stateTransitions = TRANSITIONS[state];
  if (!stateTransitions) {
    return [];
  }
  return Object.keys(stateTransitions) as StateMachineEvent['type'][];
}
