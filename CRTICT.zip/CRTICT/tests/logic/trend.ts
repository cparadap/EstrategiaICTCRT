/**
 * Trend Detection Logic
 *
 * Mirrors the Pine Script trend detection:
 *   if not na(h4_close) and not na(h4_ema50)
 *       trend := h4_close > h4_ema50 ? 1 : h4_close < h4_ema50 ? -1 : trend
 *       trend_changed := trend != prev_trend
 *       prev_trend := trend
 *
 * Validates: Requirements 1.1, 1.2, 1.3
 */

export interface TrendState {
  trend: number; // 1 = bullish, -1 = bearish, 0 = uninitialized
  prevTrend: number;
}

export interface TrendResult {
  trend: number;
  prevTrend: number;
  trendChanged: boolean;
}

/**
 * Computes the trend classification for a single bar.
 *
 * @param h4Close - The 4H close price (null/undefined = na)
 * @param h4Ema50 - The 4H EMA50 value (null/undefined = na)
 * @param state - The current trend state (trend and prevTrend)
 * @returns The updated trend state and whether the trend changed
 */
export function detectTrend(
  h4Close: number | null | undefined,
  h4Ema50: number | null | undefined,
  state: TrendState
): TrendResult {
  let trend = state.trend;
  let prevTrend = state.prevTrend;
  let trendChanged = false;

  // Guard: if either value is na (null/undefined), no change
  if (h4Close == null || h4Ema50 == null) {
    return { trend, prevTrend, trendChanged };
  }

  // Trend classification
  if (h4Close > h4Ema50) {
    trend = 1; // bullish
  } else if (h4Close < h4Ema50) {
    trend = -1; // bearish
  }
  // else: close == ema50, trend unchanged

  // Change detection
  trendChanged = trend !== prevTrend;
  prevTrend = trend;

  return { trend, prevTrend, trendChanged };
}

/**
 * Processes a sequence of bars and returns the final trend state.
 * Useful for testing transitions over multiple bars.
 */
export function detectTrendSequence(
  bars: Array<{ close: number | null | undefined; ema50: number | null | undefined }>,
  initialState: TrendState = { trend: 0, prevTrend: 0 }
): TrendResult[] {
  const results: TrendResult[] = [];
  let state = { ...initialState };

  for (const bar of bars) {
    const result = detectTrend(bar.close, bar.ema50, state);
    results.push(result);
    state = { trend: result.trend, prevTrend: result.prevTrend };
  }

  return results;
}
