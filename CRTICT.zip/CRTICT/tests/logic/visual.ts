/**
 * Visual Rendering Logic
 *
 * Models the Pine Script visual drawing functions (lines 118-155) for testing:
 * - f_draw_swing_line(price, is_high): Red dashed for swing high, green dashed for swing low
 * - f_draw_ob_box(top, bottom, left_bar): Green(70) for bullish trend, red(70) for bearish trend
 * - f_draw_crt_box(top, bottom, left_bar, box_array, box_color): CRT box with specified color
 * - f_cleanup_drawings(): Iterates all drawing arrays, deletes each, clears arrays
 * - Drawing limit management: Deletes oldest when approaching 490 items
 *
 * Validates: Requirements 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 9.9
 */

// Drawing limit constant (TradingView allows 500 lines and 500 boxes)
export const MAX_DRAWINGS = 490;

// Color constants matching Pine Script
export type Color = 'red' | 'green' | 'blue' | 'yellow' | 'fuchsia';
export type LineStyle = 'dashed' | 'solid' | 'dotted';

export interface LineDrawing {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color: Color;
  style: LineStyle;
  width: number;
}

export interface BoxDrawing {
  left: number;
  top: number;
  right: number;
  bottom: number;
  borderColor: Color;
  bgColor: Color;
  transparency: number;
  borderWidth: number;
}

export interface DrawingArrays {
  swingLines: LineDrawing[];
  obBoxes: BoxDrawing[];
  crt4hBoxes: BoxDrawing[];
  crt1hBoxes: BoxDrawing[];
  crt15mBoxes: BoxDrawing[];
  crt5mBoxes: BoxDrawing[];
}

export function initialDrawingArrays(): DrawingArrays {
  return {
    swingLines: [],
    obBoxes: [],
    crt4hBoxes: [],
    crt1hBoxes: [],
    crt15mBoxes: [],
    crt5mBoxes: [],
  };
}

/**
 * Manages drawing limit for line arrays.
 * Removes the oldest line if the array is at or above MAX_DRAWINGS.
 */
export function manageLineLimit(arr: LineDrawing[]): void {
  if (arr.length >= MAX_DRAWINGS) {
    arr.shift(); // Remove oldest (index 0)
  }
}

/**
 * Manages drawing limit for box arrays.
 * Removes the oldest box if the array is at or above MAX_DRAWINGS.
 */
export function manageBoxLimit(arr: BoxDrawing[]): void {
  if (arr.length >= MAX_DRAWINGS) {
    arr.shift(); // Remove oldest (index 0)
  }
}

/**
 * Draws a dashed horizontal line at a swing price level.
 * Red dashed for Swing_High, Green dashed for Swing_Low.
 *
 * @param price - The swing price level
 * @param isHigh - true for swing high (red), false for swing low (green)
 * @param barIndex - Current bar index
 * @param arrays - The drawing arrays state
 */
export function drawSwingLine(
  price: number,
  isHigh: boolean,
  barIndex: number,
  arrays: DrawingArrays
): LineDrawing {
  manageLineLimit(arrays.swingLines);

  const lineColor: Color = isHigh ? 'red' : 'green';
  const line: LineDrawing = {
    x1: barIndex,
    y1: price,
    x2: barIndex + 50,
    y2: price,
    color: lineColor,
    style: 'dashed',
    width: 1,
  };

  arrays.swingLines.push(line);
  return line;
}

/**
 * Draws a semi-transparent box for an Order Block zone.
 * Green(70) for bullish trend, Red(70) for bearish trend.
 *
 * @param top - OB top price
 * @param bottom - OB bottom price
 * @param leftBar - Left bar index of the OB
 * @param barIndex - Current bar index (right edge)
 * @param trend - 1 for bullish, -1 for bearish
 * @param arrays - The drawing arrays state
 */
export function drawObBox(
  top: number,
  bottom: number,
  leftBar: number,
  barIndex: number,
  trend: number,
  arrays: DrawingArrays
): BoxDrawing {
  manageBoxLimit(arrays.obBoxes);

  const boxColor: Color = trend === 1 ? 'green' : 'red';
  const box: BoxDrawing = {
    left: leftBar,
    top,
    right: barIndex,
    bottom,
    borderColor: boxColor,
    bgColor: boxColor,
    transparency: 70,
    borderWidth: 1,
  };

  arrays.obBoxes.push(box);
  return box;
}

/**
 * Draws a semi-transparent box for a CRT range.
 *
 * @param top - CRT range top price
 * @param bottom - CRT range bottom price
 * @param leftBar - Left bar index
 * @param barIndex - Current bar index (right edge)
 * @param boxColor - The color for this CRT timeframe
 * @param targetArray - The specific CRT box array to add to
 */
export function drawCrtBox(
  top: number,
  bottom: number,
  leftBar: number,
  barIndex: number,
  boxColor: Color,
  targetArray: BoxDrawing[]
): BoxDrawing {
  manageBoxLimit(targetArray);

  const box: BoxDrawing = {
    left: leftBar,
    top,
    right: barIndex,
    bottom,
    borderColor: boxColor,
    bgColor: boxColor,
    transparency: 70,
    borderWidth: 1,
  };

  targetArray.push(box);
  return box;
}

/**
 * CRT color scheme per timeframe.
 * 4H = blue(70), 1H = yellow(70), 15M = green(70), 5M = fuchsia(70)
 */
export const CRT_COLORS: Record<string, Color> = {
  '4H': 'blue',
  '1H': 'yellow',
  '15M': 'green',
  '5M': 'fuchsia',
};

/**
 * Cleans up all drawings by clearing all arrays.
 * Mirrors Pine Script f_cleanup_drawings() which iterates each array,
 * deletes each drawing, then clears the array.
 */
export function cleanupDrawings(arrays: DrawingArrays): void {
  arrays.swingLines.length = 0;
  arrays.obBoxes.length = 0;
  arrays.crt4hBoxes.length = 0;
  arrays.crt1hBoxes.length = 0;
  arrays.crt15mBoxes.length = 0;
  arrays.crt5mBoxes.length = 0;
}
