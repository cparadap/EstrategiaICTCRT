# Design Document: ICT + CRT Multi-Timeframe Strategy

## Overview

This design describes a Pine Script v5 strategy that implements ICT (Inner Circle Trader) concepts combined with CRT (Candle Range Theory) across four timeframes (4H, 1H, 15M, 5M). The strategy runs on a 5M chart and uses `request.security()` to access higher timeframe data. It follows a state machine pattern that cascades from trend detection down through progressively lower timeframes until a precise 5M entry is triggered.

The core flow is:
1. Detect trend via 4H EMA50
2. Identify swing structure (swing highs/lows) on 4H
3. Mark order blocks on 4H
4. Establish and validate CRT ranges cascading: 4H → 1H → 15M → 5M
5. Execute entry on 5M with TP/SL management

### Design Decisions

- **Single-file Pine Script**: The entire strategy is a single `.pine` file since Pine Script v5 does not support multi-file projects.
- **State machine pattern**: A `var int` state variable tracks the current phase of the setup cascade, enabling clean transitions and invalidation logic.
- **Bar-by-bar execution**: All logic executes once per bar close on the 5M chart. Higher timeframe data is sampled via `request.security()` and changes are detected by comparing current vs previous values.
- **`barmerge.lookahead_off`**: All `request.security()` calls use this parameter to prevent future data leakage.
- **Visual cleanup via arrays**: Drawing objects (lines, boxes) are stored in arrays and cleaned up on invalidation or position close.

## Architecture

### High-Level Architecture

The strategy is organized as a pipeline of logical modules executed sequentially on each 5M bar:

```mermaid
flowchart TD
    A[Bar Open - 5M] --> B[Multi-TF Data Fetch]
    B --> C[Trend Detection Module]
    C --> D[Swing Detection Module]
    D --> E[Order Block Module]
    E --> F[CRT Cascade State Machine]
    F --> G{State?}
    G -->|WAIT_OB_TOUCH| H[4H CRT Module]
    G -->|WAIT_1H_CRT| I[1H CRT Module]
    G -->|WAIT_15M_CRT| J[15M CRT Module]
    G -->|WAIT_5M_ENTRY| K[5M Entry Module]
    H --> L[Time Limit Check]
    I --> L
    J --> L
    K --> L
    L --> M[Visual Rendering]
    M --> N[Bar Close]
```

### State Machine

The strategy uses a finite state machine with the following states:

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> WAIT_OB_TOUCH: OB identified
    WAIT_OB_TOUCH --> WAIT_4H_ACTIVATION: Price touches OB
    WAIT_4H_ACTIVATION --> WAIT_1H_CRT: 4H CRT activated
    WAIT_4H_ACTIVATION --> IDLE: 4H CRT invalidated
    WAIT_1H_CRT --> WAIT_15M_CRT: 1H CRT activated
    WAIT_1H_CRT --> WAIT_1H_CRT: 1H CRT invalidated (retry)
    WAIT_1H_CRT --> IDLE: 4H CRT invalidated
    WAIT_15M_CRT --> WAIT_5M_ENTRY: 15M CRT activated
    WAIT_15M_CRT --> WAIT_15M_CRT: 15M CRT invalidated (retry)
    WAIT_15M_CRT --> IDLE: 1H CRT invalidated
    WAIT_5M_ENTRY --> POSITION_OPEN: 5M entry triggered
    WAIT_5M_ENTRY --> WAIT_5M_ENTRY: 5M CRT invalidated (retry)
    WAIT_5M_ENTRY --> IDLE: 15M CRT invalidated
    POSITION_OPEN --> IDLE: TP/SL hit
    WAIT_OB_TOUCH --> IDLE: Time limit / Trend change
    WAIT_4H_ACTIVATION --> IDLE: Time limit / Trend change
    WAIT_1H_CRT --> IDLE: Time limit / Trend change
    WAIT_15M_CRT --> IDLE: Time limit / Trend change
    WAIT_5M_ENTRY --> IDLE: Time limit / Trend change
```

**State Definitions:**

| State | Value | Description |
|-------|-------|-------------|
| IDLE | 0 | No active setup, scanning for new OB |
| WAIT_OB_TOUCH | 1 | OB identified, waiting for price to return to it |
| WAIT_4H_ACTIVATION | 2 | 4H CRT range established, waiting for activation |
| WAIT_1H_CRT | 3 | 4H CRT activated, waiting for 1H CRT activation |
| WAIT_15M_CRT | 4 | 1H CRT activated, waiting for 15M CRT activation |
| WAIT_5M_ENTRY | 5 | 15M CRT activated, waiting for 5M entry signal |
| POSITION_OPEN | 6 | Position is active, managed by strategy.exit() |

### Data Flow

```mermaid
flowchart LR
    subgraph "request.security()"
        RS4H[4H OHLC + EMA50]
        RS1H[1H OHLC]
        RS15M[15M OHLC]
    end
    subgraph "5M Chart (native)"
        OHLC5M[5M OHLC]
    end
    RS4H --> TrendModule[Trend Detection]
    RS4H --> SwingModule[Swing Detection]
    SwingModule --> OBModule[Order Block ID]
    OBModule --> CRT4H[4H CRT Logic]
    RS1H --> CRT1H[1H CRT Logic]
    RS15M --> CRT15M[15M CRT Logic]
    OHLC5M --> CRT5M[5M CRT Logic]
    CRT4H --> StateMachine
    CRT1H --> StateMachine
    CRT15M --> StateMachine
    CRT5M --> StateMachine
    StateMachine --> EntryModule[Entry/Exit]
    StateMachine --> VisualModule[Visual Rendering]
```

## Components and Interfaces

### 1. Multi-Timeframe Data Fetcher

**Purpose:** Fetches OHLC data and indicators from higher timeframes.

**Interface:**
```pine
// Inputs (via request.security)
var float h4_open = request.security(syminfo.tickerid, "240", open, barmerge.gaps_off, barmerge.lookahead_off)
var float h4_high = request.security(syminfo.tickerid, "240", high, barmerge.gaps_off, barmerge.lookahead_off)
var float h4_low = request.security(syminfo.tickerid, "240", low, barmerge.gaps_off, barmerge.lookahead_off)
var float h4_close = request.security(syminfo.tickerid, "240", close, barmerge.gaps_off, barmerge.lookahead_off)
var float h4_ema50 = request.security(syminfo.tickerid, "240", ta.ema(close, 50), barmerge.gaps_off, barmerge.lookahead_off)

// Similar for 1H ("60") and 15M ("15")
```

**Design Note:** `request.security()` calls must be at the global scope in Pine Script v5 — they cannot be inside `if` blocks or functions. All HTF data is fetched unconditionally on every bar.

### 2. Trend Detection Module

**Purpose:** Classifies the current trend as bullish or bearish based on 4H EMA50.

**Interface:**
```pine
// Output
var int trend = 0  // 1 = bullish, -1 = bearish

// Logic
trend := h4_close > h4_ema50 ? 1 : h4_close < h4_ema50 ? -1 : trend
```

**Change Detection:**
```pine
var int prev_trend = 0
bool trend_changed = trend != prev_trend
prev_trend := trend
```

### 3. Swing Detection Module

**Purpose:** Identifies swing highs and swing lows on the 4H timeframe by counting consecutive bullish/bearish candles.

**Interface:**
```pine
// State variables
var int bullish_count = 0   // consecutive bullish 4H candles
var int bearish_count = 0   // consecutive bearish 4H candles
var float swing_high = na   // latest swing high price
var float swing_low = na    // latest swing low price
var bool new_swing_high = false
var bool new_swing_low = false

// Candle classification
bool h4_is_bullish = h4_close > h4_open
bool h4_is_bearish = h4_close < h4_open
```

**Algorithm (Bullish Trend):**
1. Track consecutive bearish candles (pullback counter)
2. When a bullish candle appears after ≥3 bearish, start counting bullish candles
3. When bullish count reaches 3: mark Swing_Low = lowest low in the pullback group
4. Track consecutive bullish candles (impulse counter)
5. When a bearish candle appears after ≥3 bullish, start counting bearish candles
6. When bearish count reaches 3: mark Swing_High = high of last bullish candle before bearish sequence

**New 4H Bar Detection:**
```pine
bool new_h4_bar = ta.change(time("240")) != 0
```

### 4. Order Block Module

**Purpose:** Identifies and stores order block zones when swing points are detected.

**Interface:**
```pine
// State
var float ob_high = na      // Order block high price
var float ob_low = na       // Order block low price
var int ob_bar_index = na   // Bar index where OB was identified
var bool ob_valid = false   // Whether an active OB exists

// The OB is the last contrary candle before the impulse
// For bullish: last bearish candle before the bullish impulse creating Swing_High
// For bearish: last bullish candle before the bearish impulse creating Swing_Low
```

### 5. CRT Range Manager

**Purpose:** Manages CRT ranges across all four timeframes with activation/invalidation logic.

**Interface (per timeframe):**
```pine
// CRT Range structure (repeated for each TF)
var float crt_4h_high = na
var float crt_4h_low = na
var bool crt_4h_active = false
var bool crt_4h_valid = false
var int crt_4h_bar = na         // bar_index when established

var float crt_1h_high = na
var float crt_1h_low = na
var bool crt_1h_active = false
var bool crt_1h_valid = false

var float crt_15m_high = na
var float crt_15m_low = na
var bool crt_15m_active = false
var bool crt_15m_valid = false

var float crt_5m_high = na
var float crt_5m_low = na
var bool crt_5m_active = false
var bool crt_5m_valid = false
```

**CRT Activation Logic (Bullish Example):**
```pine
// 4H CRT activation: price breaks below lower extreme
if crt_4h_valid and not crt_4h_active
    if low < crt_4h_low
        crt_4h_active := true
        // Transition to WAIT_1H_CRT state
    else if high > crt_4h_high
        // Invalidation: price broke upper extreme first
        crt_4h_valid := false
        // Reset to IDLE
```

**Re-establishment Logic (1H/15M/5M):**
When a lower-timeframe CRT is invalidated but the parent CRT remains valid, a new CRT can be established when price breaks beyond the invalidated range's extreme.

### 6. Entry/Exit Module

**Purpose:** Executes trade entries and manages TP/SL via `strategy.entry()` and `strategy.exit()`.

**Interface:**
```pine
// Entry execution
strategy.entry("Long", strategy.long)
strategy.exit("Long TP/SL", "Long", limit=tp_price, stop=sl_price)

// For short
strategy.entry("Short", strategy.short)
strategy.exit("Short TP/SL", "Short", limit=tp_price, stop=sl_price)
```

**TP/SL Calculation:**
- Long TP: `crt_4h_high` (high of the 4H CRT candle)
- Long SL: `crt_5m_low - (5 * syminfo.mintick)` (5 pips below 5M activation candle low)
- Short TP: `crt_4h_low` (low of the 4H CRT candle)
- Short SL: `crt_5m_high + (5 * syminfo.mintick)` (5 pips above 5M activation candle high)

### 7. Visual Rendering Module

**Purpose:** Draws and manages visual elements (lines, boxes) on the chart.

**Interface:**
```pine
// Drawing arrays for cleanup
var line[] swing_lines = array.new_line()
var box[] ob_boxes = array.new_box()
var box[] crt_boxes = array.new_box()

// Drawing functions
f_draw_swing_line(price, style) => line.new(...)
f_draw_ob_box(top, bottom, left, right, color) => box.new(...)
f_draw_crt_box(top, bottom, left, right, color) => box.new(...)

// Cleanup function
f_cleanup_drawings() =>
    // Delete all lines and boxes in arrays
    for i = 0 to array.size(swing_lines) - 1
        line.delete(array.get(swing_lines, i))
    array.clear(swing_lines)
    // Similar for boxes
```

**Color Scheme:**
| Element | Color | Transparency |
|---------|-------|-------------|
| Order Block (Bullish) | Green | 70 (30% opaque) |
| Order Block (Bearish) | Red | 70 |
| 4H CRT Range | Blue | 70 |
| 1H CRT Range | Yellow | 70 |
| 15M CRT Range | Green | 70 |
| 5M CRT Range | Pink/Fuchsia | 70 |
| Swing High Line | Red (dashed) | 0 |
| Swing Low Line | Green (dashed) | 0 |

### 8. Time Limit Module

**Purpose:** Invalidates all pending setups when the originating 4H candle closes.

**Interface:**
```pine
// Track the 4H bar that established the CRT
var int setup_h4_bar_time = na

// On each new 4H bar, check if the setup's originating bar has closed
if new_h4_bar and setup_h4_bar_time != na
    if time > setup_h4_bar_time + (4 * 60 * 60 * 1000)  // 4H in milliseconds
        // Invalidate everything
        f_invalidate_all()
```

## Data Models

### Core State Variables

```pine
//@version=5
strategy("ICT + CRT Multi-TF Strategy", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=1)

// === STATE MACHINE ===
var int state = 0  // IDLE=0, WAIT_OB_TOUCH=1, WAIT_4H_ACT=2, WAIT_1H=3, WAIT_15M=4, WAIT_5M=5, POS_OPEN=6

// === TREND ===
var int trend = 0  // 1=bullish, -1=bearish
var int prev_trend = 0

// === SWING DETECTION ===
var int consec_bull = 0
var int consec_bear = 0
var float[] pullback_lows = array.new_float()
var float[] pullback_highs = array.new_float()
var float swing_high_price = na
var float swing_low_price = na

// === ORDER BLOCK ===
var float ob_high = na
var float ob_low = na
var int ob_left_bar = na
var bool ob_valid = false

// === CRT RANGES ===
// 4H CRT
var float crt4h_high = na
var float crt4h_low = na
var bool crt4h_valid = false
var bool crt4h_activated = false
var int crt4h_setup_time = na

// 1H CRT
var float crt1h_high = na
var float crt1h_low = na
var bool crt1h_valid = false
var bool crt1h_activated = false
var float crt1h_last_invalidated_low = na
var float crt1h_last_invalidated_high = na

// 15M CRT
var float crt15m_high = na
var float crt15m_low = na
var bool crt15m_valid = false
var bool crt15m_activated = false
var float crt15m_last_invalidated_low = na
var float crt15m_last_invalidated_high = na

// 5M CRT
var float crt5m_high = na
var float crt5m_low = na
var bool crt5m_valid = false
var bool crt5m_activated = false
var float crt5m_last_invalidated_high = na
var float crt5m_last_invalidated_low = na

// === ENTRY/EXIT ===
var float tp_price = na
var float sl_price = na
var int trade_direction = 0  // 1=long, -1=short

// === VISUAL ===
var line[] swing_lines = array.new_line()
var box[] ob_boxes = array.new_box()
var box[] crt4h_boxes = array.new_box()
var box[] crt1h_boxes = array.new_box()
var box[] crt15m_boxes = array.new_box()
var box[] crt5m_boxes = array.new_box()
```

### HTF Data Structures

```pine
// === 4H DATA ===
[h4_open, h4_high, h4_low, h4_close] = request.security(syminfo.tickerid, "240", [open, high, low, close], barmerge.gaps_off, barmerge.lookahead_off)
h4_ema50 = request.security(syminfo.tickerid, "240", ta.ema(close, 50), barmerge.gaps_off, barmerge.lookahead_off)

// === 1H DATA ===
[h1_open, h1_high, h1_low, h1_close] = request.security(syminfo.tickerid, "60", [open, high, low, close], barmerge.gaps_off, barmerge.lookahead_off)

// === 15M DATA ===
[m15_open, m15_high, m15_low, m15_close] = request.security(syminfo.tickerid, "15", [open, high, low, close], barmerge.gaps_off, barmerge.lookahead_off)
```

### New Bar Detection

```pine
bool new_h4_bar = ta.change(time("240")) != 0
bool new_h1_bar = ta.change(time("60")) != 0
bool new_15m_bar = ta.change(time("15")) != 0
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Trend Classification Correctness

*For any* 4H close price and EMA50 value, if close > EMA50 then trend shall be classified as bullish, and if close < EMA50 then trend shall be classified as bearish.

**Validates: Requirements 1.1, 1.2**

### Property 2: Swing Point Identification

*For any* sequence of 4H candles where at least 3 consecutive contrary candles (pullback) are followed by at least 3 consecutive trend-direction candles (impulse), the strategy shall identify the extreme price within the pullback group as the swing point (lowest low for bullish Swing_Low, highest high for bearish Swing_High), and the last impulse candle's extreme before the reversal as the opposite swing point.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

### Property 3: Order Block Identification

*For any* swing point identification event, the order block shall be the last candle contrary to the impulse direction immediately preceding the impulse group. Its high and low shall be stored as the OB zone boundaries.

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 4: CRT Range Establishment

*For any* CRT level (4H, 1H, 15M, 5M), when the parent condition is met (OB touch for 4H, parent CRT activation for others), the CRT range shall be established from the first candle close at that timeframe, recording its high and low as the range boundaries.

**Validates: Requirements 4.1, 5.1, 6.1, 7.1**

### Property 5: CRT Activation on Correct Extreme Break

*For any* valid CRT range at the 4H, 1H, or 15M level, when price breaks the activation extreme (lower extreme for bullish trend, upper extreme for bearish trend), the CRT shall transition to activated state and the state machine shall advance to the next lower timeframe.

**Validates: Requirements 4.2, 4.3, 5.2, 5.3, 6.2, 6.3**

### Property 6: CRT Invalidation on Wrong Extreme Break

*For any* valid but not-yet-activated CRT range, when price breaks the invalidation extreme (upper extreme for bullish trend at 4H/1H/15M, lower extreme for bearish trend at 4H/1H/15M; lower extreme for bullish at 5M, upper extreme for bearish at 5M), the CRT shall be invalidated.

**Validates: Requirements 4.4, 4.5, 5.4, 5.5, 6.4, 6.5, 7.7, 7.8**

### Property 7: CRT Re-establishment After Invalidation

*For any* invalidated CRT range at the 1H, 15M, or 5M level where the parent CRT remains valid, a new CRT range shall be established when price breaks beyond the last invalidated range's relevant extreme (below the invalidated low for bullish, above the invalidated high for bearish at 1H/15M; above the invalidated high for bullish, below the invalidated low for bearish at 5M).

**Validates: Requirements 5.6, 6.6, 7.9**

### Property 8: 5M Entry Trigger

*For any* valid 5M CRT range, when price breaks the entry extreme (upper extreme for bullish trend, lower extreme for bearish trend), a trade entry shall be executed in the trend direction.

**Validates: Requirements 7.2, 7.3**

### Property 9: TP/SL Calculation Correctness

*For any* trade entry, the TP shall equal the 4H CRT candle's trend-direction extreme (high for long, low for short), and the SL shall equal the 5M activation candle's counter-trend extreme offset by 5 pips (low - 5*mintick for long, high + 5*mintick for short).

**Validates: Requirements 7.4, 7.5**

### Property 10: Time Limit Invalidation

*For any* active setup, when the 4H candle that established the 4H CRT range closes (a new 4H bar opens) and no position has been entered, all CRT ranges and the entire setup state shall be reset to IDLE.

**Validates: Requirements 8.1**

### Property 11: Long/Short Symmetry

*For any* complete setup scenario producing a valid entry in one trend direction, mirroring all price inputs (swapping highs for lows and vice versa) and inverting the trend direction shall produce the equivalent mirrored entry with mirrored TP/SL levels.

**Validates: Requirements 11.1**

### Property 12: Single Active Direction Invariant

*For any* state of the strategy, there shall be at most one active setup direction at a time. When the trend changes direction, any active setup from the previous trend shall be immediately invalidated.

**Validates: Requirements 11.2, 11.3**

## Error Handling

### Invalid State Transitions

- If the state machine receives an event that is not valid for the current state, it shall be ignored (no-op).
- All state variables use `na` as their uninitialized value; logic guards against `na` comparisons using `na()` checks.

### Data Gaps and Missing Bars

- `request.security()` may return `na` during the first bars of a chart or during data gaps.
- All HTF data is checked for `na` before processing: `if not na(h4_close)`.
- The strategy does not execute any logic until all HTF data sources return valid values.

### Drawing Limits

- TradingView limits the number of drawing objects (500 lines, 500 boxes by default).
- The strategy uses arrays to track drawings and proactively deletes old drawings when approaching limits.
- On invalidation, all associated drawings are immediately deleted.

### Position Conflicts

- `strategy.entry()` with the same ID replaces any existing pending entry.
- The strategy ensures only one position is active at a time by checking `strategy.position_size == 0` before new entries.
- If a position is already open, new setup signals are ignored until the position closes.

### Edge Cases

| Scenario | Handling |
|----------|----------|
| EMA50 == close exactly | Maintain previous trend (no change) |
| Candle with open == close (doji) | Classified as neither bullish nor bearish; resets consecutive counters |
| Gap through CRT range | Treated as activation/invalidation based on where price ends up |
| Multiple swing points on same bar | Only the most recent is tracked |
| Weekend gaps | Handled naturally by bar-by-bar processing |

## Testing Strategy

### Approach

Since Pine Script v5 does not support external unit testing frameworks, the testing strategy employs a dual approach:

1. **Logic Extraction Testing**: Extract core algorithms (trend detection, swing detection, CRT state machine, TP/SL calculation) into a testable language (TypeScript/JavaScript) that mirrors the Pine Script logic. This enables property-based testing of the algorithms.

2. **Visual Backtesting Verification**: Use TradingView's Strategy Tester to verify end-to-end behavior on historical data.

### Property-Based Testing (TypeScript with fast-check)

**Library:** [fast-check](https://github.com/dubzzz/fast-check) for TypeScript

**Configuration:**
- Minimum 100 iterations per property test
- Each test tagged with: `Feature: ict-crt-strategy, Property {N}: {description}`

**Test Structure:**
```
tests/
├── properties/
│   ├── trend.property.test.ts       (Property 1)
│   ├── swing.property.test.ts       (Property 2)
│   ├── orderblock.property.test.ts  (Property 3)
│   ├── crt-establish.property.test.ts (Property 4)
│   ├── crt-activation.property.test.ts (Property 5)
│   ├── crt-invalidation.property.test.ts (Property 6)
│   ├── crt-reestablish.property.test.ts (Property 7)
│   ├── entry-trigger.property.test.ts (Property 8)
│   ├── tp-sl.property.test.ts       (Property 9)
│   ├── time-limit.property.test.ts  (Property 10)
│   ├── symmetry.property.test.ts    (Property 11)
│   └── invariant.property.test.ts   (Property 12)
├── unit/
│   ├── trend.test.ts
│   ├── swing.test.ts
│   ├── visual.test.ts
│   └── state-machine.test.ts
└── generators/
    ├── candle.gen.ts          (random OHLC candle generator)
    ├── candle-sequence.gen.ts (sequences with controlled patterns)
    ├── crt-range.gen.ts       (random CRT range states)
    └── state.gen.ts           (random state machine states)
```

### Generators

**Candle Generator:**
- Generates valid OHLC candles where high ≥ max(open, close) and low ≤ min(open, close)
- Can be constrained to bullish (close > open) or bearish (close < open)

**Candle Sequence Generator:**
- Generates sequences with controlled patterns (N bearish followed by M bullish)
- Ensures realistic price continuity between consecutive candles

**CRT Range Generator:**
- Generates valid CRT range states (high > low, valid/invalid/activated flags)

**State Generator:**
- Generates valid state machine configurations with consistent internal state

### Unit Tests (Example-Based)

- Visual element creation with correct parameters (Requirements 9.x)
- `request.security()` call configuration (Requirements 10.x)
- Edge cases: doji candles, exact EMA50 == close, gap scenarios
- Integration: full cascade from OB identification to entry execution with specific price sequences

### Backtesting Verification

- Run strategy on known historical data (e.g., EUR/USD 5M chart)
- Manually verify 5-10 trade entries match expected ICT/CRT logic
- Verify no future data leakage by comparing results with and without `barmerge.lookahead_off`
- Check that all visual elements appear at correct locations
