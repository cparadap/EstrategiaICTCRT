# Requirements Document

## Introduction

This document specifies the requirements for the "ICT + CRT Multi-Timeframe Strategy" — a Pine Script v5 trading strategy for backtesting on TradingView. The strategy implements Inner Circle Trader (ICT) concepts combined with Candle Range Theory (CRT) across four timeframes (4H, 1H, 15M, 5M) to identify high-probability trade entries. The chart runs on the 5M timeframe and uses `request.security()` to access higher timeframe data.

## Glossary

- **Strategy**: The Pine Script v5 indicator/strategy script that implements the ICT + CRT Multi-Timeframe logic on TradingView.
- **EMA50**: The 50-period Exponential Moving Average calculated on the 4H timeframe.
- **Trend**: The directional bias (bullish or bearish) determined by price position relative to EMA50 on the 4H timeframe.
- **Swing_Low**: The lowest price within a pullback group of at least 3 bearish candles followed by at least 3 bullish candles during a bullish trend (inverted for bearish trend).
- **Swing_High**: The highest price at the end of an impulse group of at least 3 bullish candles before at least 3 bearish candles during a bullish trend (inverted for bearish trend).
- **Order_Block**: The last candle contrary to the impulse direction that creates a swing point; for bullish, the last bearish candle before the bullish impulse; for bearish, the last bullish candle before the bearish impulse.
- **CRT_Range**: A Candle Range Theory range defined by the high and low of a specific candle at a given timeframe, used to determine activation and invalidation levels.
- **Activation**: The event where price breaks the lower extreme of a CRT range (for long setups) or the upper extreme (for short setups), signaling a drop to the next lower timeframe.
- **Invalidation**: The event where price breaks the opposite extreme of a CRT range, canceling the setup at that timeframe level.
- **4H_CRT**: The CRT range established on the 4H timeframe when price returns to touch the Order Block.
- **1H_CRT**: The CRT range established on the 1H timeframe after 4H CRT activation.
- **15M_CRT**: The CRT range established on the 15M timeframe after 1H CRT activation.
- **5M_CRT**: The CRT range established on the 5M timeframe after 15M CRT activation, used for entry signals.
- **TP**: Take Profit — the price level at which the position is closed for profit.
- **SL**: Stop Loss — the price level at which the position is closed to limit loss.
- **Pip**: The smallest price movement unit; for this strategy, 5 pips below/above a level defines the SL offset.

## Requirements

### Requirement 1: Trend Detection

**User Story:** As a trader, I want the strategy to determine the market trend on the 4H timeframe using EMA50, so that trades are only taken in the direction of the prevailing trend.

#### Acceptance Criteria

1. WHILE the 4H close price is above the EMA50, THE Strategy SHALL classify the trend as bullish.
2. WHILE the 4H close price is below the EMA50, THE Strategy SHALL classify the trend as bearish.
3. THE Strategy SHALL calculate the EMA50 using 4H timeframe close prices via `request.security()`.

### Requirement 2: Swing High and Swing Low Identification

**User Story:** As a trader, I want the strategy to identify swing highs and swing lows on the 4H timeframe, so that market structure is properly mapped for order block detection.

#### Acceptance Criteria

1. WHILE the trend is bullish, WHEN at least 3 consecutive bearish 4H candles (pullback) are followed by at least 3 consecutive bullish 4H candles (impulse), THE Strategy SHALL identify the lowest price within the pullback group as a Swing_Low.
2. WHILE the trend is bullish, WHEN at least 3 consecutive bullish 4H candles (impulse) are followed by at least 3 consecutive bearish 4H candles, THE Strategy SHALL identify the highest price of the last bullish candle before the bearish sequence as a Swing_High.
3. WHILE the trend is bearish, WHEN at least 3 consecutive bullish 4H candles (pullback) are followed by at least 3 consecutive bearish 4H candles (impulse), THE Strategy SHALL identify the highest price within the pullback group as a Swing_High.
4. WHILE the trend is bearish, WHEN at least 3 consecutive bearish 4H candles (impulse) are followed by at least 3 consecutive bullish 4H candles, THE Strategy SHALL identify the lowest price of the last bearish candle before the bullish sequence as a Swing_Low.

### Requirement 3: Order Block Identification

**User Story:** As a trader, I want the strategy to identify order blocks on the 4H timeframe, so that key institutional supply/demand zones are marked for potential trade setups.

#### Acceptance Criteria

1. WHILE the trend is bullish, WHEN a Swing_High is identified, THE Strategy SHALL mark the last bearish candle before the bullish impulse that created the Swing_High as the Order_Block.
2. WHILE the trend is bearish, WHEN a Swing_Low is identified, THE Strategy SHALL mark the last bullish candle before the bearish impulse that created the Swing_Low as the Order_Block.
3. THE Strategy SHALL store the Order_Block high and low price levels for subsequent CRT range detection.

### Requirement 4: 4H CRT Range Establishment

**User Story:** As a trader, I want the strategy to establish a 4H CRT range when price returns to the order block, so that the multi-timeframe cascade can begin.

#### Acceptance Criteria

1. WHEN price on the 4H timeframe touches or enters the Order_Block zone, THE Strategy SHALL mark that 4H candle as the 4H_CRT and record its high and low as the 4H CRT range.
2. WHILE the trend is bullish, WHEN price breaks below the lower extreme of the 4H_CRT range, THE Strategy SHALL activate the 4H CRT range and signal a drop to the 1H timeframe.
3. WHILE the trend is bearish, WHEN price breaks above the upper extreme of the 4H_CRT range, THE Strategy SHALL activate the 4H CRT range and signal a drop to the 1H timeframe.
4. WHILE the trend is bullish, IF price breaks above the upper extreme of the 4H_CRT range before activation, THEN THE Strategy SHALL invalidate the 4H CRT range and discard the setup.
5. WHILE the trend is bearish, IF price breaks below the lower extreme of the 4H_CRT range before activation, THEN THE Strategy SHALL invalidate the 4H CRT range and discard the setup.

### Requirement 5: 1H CRT Range Establishment

**User Story:** As a trader, I want the strategy to establish a 1H CRT range after 4H CRT activation, so that the setup is refined on a lower timeframe.

#### Acceptance Criteria

1. WHEN the 4H CRT range is activated, THE Strategy SHALL wait for the first 1H candle to close and record its high and low as the 1H CRT range.
2. WHILE the trend is bullish, WHEN price breaks below the lower extreme of the 1H_CRT range, THE Strategy SHALL activate the 1H CRT range and signal a drop to the 15M timeframe.
3. WHILE the trend is bearish, WHEN price breaks above the upper extreme of the 1H_CRT range, THE Strategy SHALL activate the 1H CRT range and signal a drop to the 15M timeframe.
4. WHILE the trend is bullish, IF price breaks above the upper extreme of the 1H_CRT range before activation, THEN THE Strategy SHALL invalidate the 1H CRT range.
5. WHILE the trend is bearish, IF price breaks below the lower extreme of the 1H_CRT range before activation, THEN THE Strategy SHALL invalidate the 1H CRT range.
6. WHILE the 4H CRT range remains valid, WHEN the 1H CRT range is invalidated, THE Strategy SHALL establish a new 1H CRT range when price breaks below the low of the last invalidated 1H CRT range (bullish) or above the high (bearish).

### Requirement 6: 15M CRT Range Establishment

**User Story:** As a trader, I want the strategy to establish a 15M CRT range after 1H CRT activation, so that the entry zone is further narrowed.

#### Acceptance Criteria

1. WHEN the 1H CRT range is activated, THE Strategy SHALL wait for the first 15M candle to close and record its high and low as the 15M CRT range.
2. WHILE the trend is bullish, WHEN price breaks below the lower extreme of the 15M_CRT range, THE Strategy SHALL activate the 15M CRT range and signal a drop to the 5M timeframe.
3. WHILE the trend is bearish, WHEN price breaks above the upper extreme of the 15M_CRT range, THE Strategy SHALL activate the 15M CRT range and signal a drop to the 5M timeframe.
4. WHILE the trend is bullish, IF price breaks above the upper extreme of the 15M_CRT range before activation, THEN THE Strategy SHALL invalidate the 15M CRT range.
5. WHILE the trend is bearish, IF price breaks below the lower extreme of the 15M_CRT range before activation, THEN THE Strategy SHALL invalidate the 15M CRT range.
6. WHILE the 1H CRT range remains valid, WHEN the 15M CRT range is invalidated, THE Strategy SHALL establish a new 15M CRT range when price breaks below the low of the last invalidated 15M CRT range (bullish) or above the high (bearish).

### Requirement 7: 5M CRT Range and Entry Execution

**User Story:** As a trader, I want the strategy to execute trade entries on the 5M timeframe after 15M CRT activation, so that precise entries are achieved with defined risk parameters.

#### Acceptance Criteria

1. WHEN the 15M CRT range is activated, THE Strategy SHALL wait for the first 5M candle to close and record its high and low as the 5M CRT range.
2. WHILE the trend is bullish, WHEN price breaks above the upper extreme of the 5M_CRT range, THE Strategy SHALL execute a market buy order using `strategy.entry()`.
3. WHILE the trend is bearish, WHEN price breaks below the lower extreme of the 5M_CRT range, THE Strategy SHALL execute a market sell order using `strategy.entry()`.
4. WHEN a long entry is executed, THE Strategy SHALL set the TP at the high of the 4H_CRT candle and the SL at 5 pips below the low of the 5M candle that activated the range.
5. WHEN a short entry is executed, THE Strategy SHALL set the TP at the low of the 4H_CRT candle and the SL at 5 pips above the high of the 5M candle that activated the range.
6. THE Strategy SHALL use `strategy.exit()` to manage TP and SL levels for each position.
7. WHILE the trend is bullish, IF price breaks below the lower extreme of the 5M_CRT range before entry activation, THEN THE Strategy SHALL invalidate the 5M CRT range.
8. WHILE the trend is bearish, IF price breaks above the upper extreme of the 5M_CRT range before entry activation, THEN THE Strategy SHALL invalidate the 5M CRT range.
9. WHILE the 15M CRT range remains valid, WHEN the 5M CRT range is invalidated, THE Strategy SHALL establish a new 5M CRT range when price breaks above the high of the last invalidated 5M CRT range (bullish) or below the low (bearish).

### Requirement 8: Time Limit Invalidation

**User Story:** As a trader, I want all pending zones to be invalidated when the originating 4H candle closes without a position being taken, so that stale setups do not produce late entries.

#### Acceptance Criteria

1. WHEN the 4H candle that established the 4H_CRT range closes and no position has been entered, THE Strategy SHALL invalidate all CRT ranges (4H, 1H, 15M, 5M) created from that setup.
2. WHEN all CRT ranges are invalidated due to time limit, THE Strategy SHALL remove all associated visual drawings from the chart.

### Requirement 9: Visual Representation

**User Story:** As a trader, I want the strategy to draw visual markers on the chart for swing points, order blocks, and CRT ranges, so that I can visually verify the strategy logic during backtesting.

#### Acceptance Criteria

1. WHEN a Swing_High is identified, THE Strategy SHALL draw a dashed horizontal line at the Swing_High price level extending to the current bar.
2. WHEN a Swing_Low is identified, THE Strategy SHALL draw a dashed horizontal line at the Swing_Low price level extending to the current bar.
3. WHEN an Order_Block is identified in a bullish trend, THE Strategy SHALL draw a semi-transparent green box (transparency 30) covering the Order_Block candle range.
4. WHEN an Order_Block is identified in a bearish trend, THE Strategy SHALL draw a semi-transparent red box (transparency 30) covering the Order_Block candle range.
5. WHEN a 4H_CRT range is established, THE Strategy SHALL draw a semi-transparent blue box (transparency 30) covering the 4H CRT range.
6. WHEN a 1H_CRT range is established, THE Strategy SHALL draw a semi-transparent yellow box (transparency 30) covering the 1H CRT range.
7. WHEN a 15M_CRT range is established, THE Strategy SHALL draw a semi-transparent green box (transparency 30) covering the 15M CRT range.
8. WHEN a 5M_CRT range is established, THE Strategy SHALL draw a semi-transparent pink box (transparency 30) covering the 5M CRT range.
9. WHEN a position is closed or a CRT structure is invalidated, THE Strategy SHALL remove all associated visual drawings from the chart.

### Requirement 10: Multi-Timeframe Data Access

**User Story:** As a trader, I want the strategy to correctly access data from multiple timeframes while running on the 5M chart, so that all timeframe logic is computed accurately.

#### Acceptance Criteria

1. THE Strategy SHALL run on the 5M chart timeframe to capture all entry signals.
2. THE Strategy SHALL use `request.security()` to access 4H timeframe OHLC data and EMA50 values.
3. THE Strategy SHALL use `request.security()` to access 1H timeframe OHLC data.
4. THE Strategy SHALL use `request.security()` to access 15M timeframe OHLC data.
5. THE Strategy SHALL use `request.security()` with `barmerge.lookahead_off` to prevent future data leakage during backtesting.

### Requirement 11: Symmetric Long and Short Handling

**User Story:** As a trader, I want the strategy to handle both long and short positions symmetrically, so that the strategy performs consistently in both bullish and bearish market conditions.

#### Acceptance Criteria

1. THE Strategy SHALL apply identical CRT cascade logic for short setups (bearish trend) as for long setups (bullish trend) with inverted direction conditions.
2. THE Strategy SHALL support only one active setup direction at a time based on the current 4H trend classification.
3. WHEN the trend changes from bullish to bearish or vice versa, THE Strategy SHALL invalidate any active setup from the previous trend direction.
