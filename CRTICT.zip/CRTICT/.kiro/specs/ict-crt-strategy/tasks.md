# Implementation Plan: ICT + CRT Multi-Timeframe Strategy

## Overview

This plan implements a Pine Script v5 strategy combining ICT (Inner Circle Trader) concepts with CRT (Candle Range Theory) across four timeframes (4H, 1H, 15M, 5M). The strategy runs on a 5M chart and uses a state machine pattern to cascade from trend detection through progressively lower timeframes until a precise 5M entry is triggered. Core algorithmic logic is extracted into TypeScript for property-based testing with fast-check.

## Tasks

- [x] 1. Set up project structure and core data definitions
  - [x] 1.1 Create the Pine Script file with strategy declaration, inputs, and multi-timeframe data fetching
    - Create `ict_crt_strategy.pine` with `//@version=5` header and `strategy("ICT + CRT Multi-TF Strategy", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=1)` declaration
    - Define all `request.security()` calls for 4H OHLC + EMA50, 1H OHLC, and 15M OHLC data
    - All `request.security()` calls must use `barmerge.gaps_off` and `barmerge.lookahead_off`
    - Define new bar detection booleans: `new_h4_bar`, `new_h1_bar`, `new_15m_bar` using `ta.change(time(...))`
    - Define state machine constants: IDLE=0, WAIT_OB_TOUCH=1, WAIT_4H_ACTIVATION=2, WAIT_1H_CRT=3, WAIT_15M_CRT=4, WAIT_5M_ENTRY=5, POSITION_OPEN=6
    - Define all `var` state variables for trend, swing, OB, CRT ranges (4H/1H/15M/5M), entry/exit, and visual drawing arrays
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

  - [x] 1.2 Set up TypeScript testing project with fast-check and generators
    - Create `tests/` directory structure with `properties/`, `unit/`, and `generators/` subdirectories
    - Initialize `package.json` with `fast-check`, `vitest`, and `typescript` dependencies
    - Create `tsconfig.json` for the test project
    - Implement `tests/generators/candle.gen.ts` — random OHLC candle generator ensuring high ≥ max(open,close) and low ≤ min(open,close), with bullish/bearish constraint options
    - Implement `tests/generators/candle-sequence.gen.ts` — sequences with controlled patterns (N bearish followed by M bullish) and realistic price continuity between candles
    - Implement `tests/generators/crt-range.gen.ts` — random CRT range states with high > low and valid/invalid/activated flag combinations
    - Implement `tests/generators/state.gen.ts` — random state machine configurations with consistent internal state
    - _Requirements: 1.1, 2.1, 4.1, 7.1_

- [x] 2. Implement Trend Detection Module
  - [x] 2.1 Implement trend classification logic in Pine Script
    - Add trend detection: `trend := h4_close > h4_ema50 ? 1 : h4_close < h4_ema50 ? -1 : trend`
    - Add trend change detection: `bool trend_changed = trend != prev_trend` and update `prev_trend := trend`
    - Handle edge case: when EMA50 == close exactly, maintain previous trend value (no change)
    - Guard against `na` values on first bars: `if not na(h4_close) and not na(h4_ema50)`
    - _Requirements: 1.1, 1.2, 1.3_

  - [x] 2.2 Write property test for trend classification (Property 1)
    - **Property 1: Trend Classification Correctness**
    - Implement `tests/properties/trend.property.test.ts`
    - Extract trend logic into a testable TypeScript function mirroring Pine Script behavior
    - Test: for any close > ema50 → trend is bullish (1); for any close < ema50 → trend is bearish (-1); for close == ema50 → trend unchanged
    - Minimum 100 iterations
    - **Validates: Requirements 1.1, 1.2**

  - [x] 2.3 Write unit tests for trend detection
    - Implement `tests/unit/trend.test.ts`
    - Test edge cases: doji candles, exact EMA50 == close, first bar with na values, transition from bullish to bearish and back
    - _Requirements: 1.1, 1.2, 1.3_

- [x] 3. Implement Swing Detection Module
  - [x] 3.1 Implement swing high and swing low detection logic in Pine Script
    - Implement consecutive candle counting (`consec_bull`, `consec_bear`) triggered on `new_h4_bar`
    - Classify 4H candles: `h4_is_bullish = h4_close > h4_open`, `h4_is_bearish = h4_close < h4_open`
    - Track pullback lows/highs using arrays during pullback groups
    - Bullish trend: after ≥3 bearish (pullback) then ≥3 bullish (impulse) → Swing_Low = lowest low in pullback group
    - Bullish trend: after ≥3 bullish (impulse) then ≥3 bearish → Swing_High = high of last bullish candle before bearish sequence
    - Bearish trend: after ≥3 bullish (pullback) then ≥3 bearish (impulse) → Swing_High = highest high in pullback group
    - Bearish trend: after ≥3 bearish (impulse) then ≥3 bullish → Swing_Low = low of last bearish candle before bullish sequence
    - Handle doji candles (open == close): reset consecutive counters
    - Set `new_swing_high` / `new_swing_low` flags for downstream modules
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

  - [x] 3.2 Write property test for swing point identification (Property 2)
    - **Property 2: Swing Point Identification**
    - Implement `tests/properties/swing.property.test.ts`
    - Extract swing detection logic into testable TypeScript functions
    - Test: for any sequence with ≥3 contrary candles followed by ≥3 impulse candles, the correct extreme is identified as the swing point
    - Use `candle-sequence.gen.ts` to generate controlled patterns
    - Minimum 100 iterations
    - **Validates: Requirements 2.1, 2.2, 2.3, 2.4**

  - [x] 3.3 Write unit tests for swing detection
    - Implement `tests/unit/swing.test.ts`
    - Test specific sequences: exactly 3 bearish + 3 bullish, more than 3 each, doji interruptions, single candle between groups
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

- [x] 4. Implement Order Block Module
  - [x] 4.1 Implement order block identification logic in Pine Script
    - When `new_swing_high` in bullish trend: mark the last bearish candle before the bullish impulse as OB, store its high/low/bar_index
    - When `new_swing_low` in bearish trend: mark the last bullish candle before the bearish impulse as OB, store its high/low/bar_index
    - Set `ob_valid = true` and transition state from IDLE to WAIT_OB_TOUCH
    - _Requirements: 3.1, 3.2, 3.3_

  - [x] 4.2 Write property test for order block identification (Property 3)
    - **Property 3: Order Block Identification**
    - Implement `tests/properties/orderblock.property.test.ts`
    - Extract OB logic into testable TypeScript function
    - Test: for any swing point event, the OB is the last contrary candle before the impulse group with correct high/low boundaries stored
    - Minimum 100 iterations
    - **Validates: Requirements 3.1, 3.2, 3.3**

- [x] 5. Checkpoint - Ensure trend, swing, and OB modules work correctly
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Implement 4H CRT Range Module
  - [x] 6.1 Implement 4H CRT range establishment and activation logic in Pine Script
    - In WAIT_OB_TOUCH state: detect OB touch when `low <= ob_high and high >= ob_low`
    - On OB touch: record current 4H candle high/low as `crt4h_high`/`crt4h_low`, set `crt4h_valid = true`, store `crt4h_setup_time`, transition to WAIT_4H_ACTIVATION
    - In WAIT_4H_ACTIVATION (bullish): if `low < crt4h_low` → set `crt4h_activated = true`, transition to WAIT_1H_CRT
    - In WAIT_4H_ACTIVATION (bullish): if `high > crt4h_high` → invalidate, reset to IDLE
    - In WAIT_4H_ACTIVATION (bearish): if `high > crt4h_high` → activate, transition to WAIT_1H_CRT
    - In WAIT_4H_ACTIVATION (bearish): if `low < crt4h_low` → invalidate, reset to IDLE
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

  - [x] 6.2 Write property test for CRT range establishment (Property 4)
    - **Property 4: CRT Range Establishment**
    - Implement `tests/properties/crt-establish.property.test.ts`
    - Test: when parent condition is met, CRT range is established from the first candle close at that timeframe with correct high/low boundaries
    - Use `crt-range.gen.ts` for generating test states
    - Minimum 100 iterations
    - **Validates: Requirements 4.1, 5.1, 6.1, 7.1**

  - [x] 6.3 Write property test for CRT activation (Property 5)
    - **Property 5: CRT Activation on Correct Extreme Break**
    - Implement `tests/properties/crt-activation.property.test.ts`
    - Test: when price breaks activation extreme (lower for bullish, upper for bearish), CRT transitions to activated and state machine advances
    - Minimum 100 iterations
    - **Validates: Requirements 4.2, 4.3, 5.2, 5.3, 6.2, 6.3**

  - [x] 6.4 Write property test for CRT invalidation (Property 6)
    - **Property 6: CRT Invalidation on Wrong Extreme Break**
    - Implement `tests/properties/crt-invalidation.property.test.ts`
    - Test: when price breaks invalidation extreme before activation, CRT is invalidated
    - Minimum 100 iterations
    - **Validates: Requirements 4.4, 4.5, 5.4, 5.5, 6.4, 6.5, 7.7, 7.8**

- [x] 7. Implement 1H CRT Range Module
  - [x] 7.1 Implement 1H CRT range establishment, activation, invalidation, and re-establishment in Pine Script
    - In WAIT_1H_CRT state: on first `new_h1_bar` after 4H activation, record `h1_high`/`h1_low` as `crt1h_high`/`crt1h_low`, set `crt1h_valid = true`
    - Activation (bullish): if `low < crt1h_low` → set `crt1h_activated = true`, transition to WAIT_15M_CRT
    - Activation (bearish): if `high > crt1h_high` → activate, transition to WAIT_15M_CRT
    - Invalidation (bullish): if `high > crt1h_high` → invalidate, store `crt1h_last_invalidated_low = crt1h_low`
    - Invalidation (bearish): if `low < crt1h_low` → invalidate, store `crt1h_last_invalidated_high = crt1h_high`
    - Re-establishment (bullish): if 4H CRT still valid and `low < crt1h_last_invalidated_low` → establish new 1H CRT from next 1H candle
    - Re-establishment (bearish): if 4H CRT still valid and `high > crt1h_last_invalidated_high` → establish new 1H CRT from next 1H candle
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6_

  - [x] 7.2 Write property test for CRT re-establishment (Property 7)
    - **Property 7: CRT Re-establishment After Invalidation**
    - Implement `tests/properties/crt-reestablish.property.test.ts`
    - Test: when CRT is invalidated but parent remains valid, new CRT is established when price breaks beyond last invalidated extreme
    - Minimum 100 iterations
    - **Validates: Requirements 5.6, 6.6, 7.9**

- [x] 8. Implement 15M CRT Range Module
  - [x] 8.1 Implement 15M CRT range establishment, activation, invalidation, and re-establishment in Pine Script
    - In WAIT_15M_CRT state: on first `new_15m_bar` after 1H activation, record `m15_high`/`m15_low` as `crt15m_high`/`crt15m_low`, set `crt15m_valid = true`
    - Activation (bullish): if `low < crt15m_low` → activate, transition to WAIT_5M_ENTRY
    - Activation (bearish): if `high > crt15m_high` → activate, transition to WAIT_5M_ENTRY
    - Invalidation (bullish): if `high > crt15m_high` → invalidate, store `crt15m_last_invalidated_low`
    - Invalidation (bearish): if `low < crt15m_low` → invalidate, store `crt15m_last_invalidated_high`
    - Re-establishment (bullish): if 1H CRT still valid and `low < crt15m_last_invalidated_low` → establish new 15M CRT
    - Re-establishment (bearish): if 1H CRT still valid and `high > crt15m_last_invalidated_high` → establish new 15M CRT
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

- [x] 9. Implement 5M CRT Range and Entry Execution Module
  - [x] 9.1 Implement 5M CRT range establishment, entry trigger, invalidation, and re-establishment in Pine Script
    - In WAIT_5M_ENTRY state: on first 5M bar after 15M activation, record current 5M `high`/`low` as `crt5m_high`/`crt5m_low`, set `crt5m_valid = true`
    - Entry trigger (bullish): if `high > crt5m_high` → execute `strategy.entry("Long", strategy.long)`, transition to POSITION_OPEN
    - Entry trigger (bearish): if `low < crt5m_low` → execute `strategy.entry("Short", strategy.short)`, transition to POSITION_OPEN
    - Invalidation (bullish): if `low < crt5m_low` before entry → invalidate, store `crt5m_last_invalidated_high`
    - Invalidation (bearish): if `high > crt5m_high` before entry → invalidate, store `crt5m_last_invalidated_low`
    - Re-establishment (bullish): if 15M CRT still valid and `high > crt5m_last_invalidated_high` → establish new 5M CRT
    - Re-establishment (bearish): if 15M CRT still valid and `low < crt5m_last_invalidated_low` → establish new 5M CRT
    - _Requirements: 7.1, 7.2, 7.3, 7.7, 7.8, 7.9_

  - [x] 9.2 Implement TP/SL calculation and strategy.exit() logic
    - Long TP: `crt4h_high` (high of the 4H CRT candle)
    - Long SL: `low of 5M activation candle - (5 * syminfo.mintick)`
    - Short TP: `crt4h_low` (low of the 4H CRT candle)
    - Short SL: `high of 5M activation candle + (5 * syminfo.mintick)`
    - Call `strategy.exit("Long TP/SL", "Long", limit=tp_price, stop=sl_price)` for longs
    - Call `strategy.exit("Short TP/SL", "Short", limit=tp_price, stop=sl_price)` for shorts
    - On position close (`strategy.position_size == 0` after being != 0): transition to IDLE, call `f_cleanup_drawings()`
    - _Requirements: 7.4, 7.5, 7.6_

  - [x] 9.3 Write property test for 5M entry trigger (Property 8)
    - **Property 8: 5M Entry Trigger**
    - Implement `tests/properties/entry-trigger.property.test.ts`
    - Test: when price breaks entry extreme of valid 5M CRT, trade entry is executed in trend direction
    - Minimum 100 iterations
    - **Validates: Requirements 7.2, 7.3**

  - [x] 9.4 Write property test for TP/SL calculation (Property 9)
    - **Property 9: TP/SL Calculation Correctness**
    - Implement `tests/properties/tp-sl.property.test.ts`
    - Test: TP equals 4H CRT extreme (high for long, low for short), SL equals 5M activation candle counter-trend extreme ± 5*mintick
    - Minimum 100 iterations
    - **Validates: Requirements 7.4, 7.5**

- [x] 10. Checkpoint - Ensure CRT cascade and entry logic work correctly
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Implement Time Limit and Trend Change Invalidation
  - [x] 11.1 Implement time limit invalidation logic in Pine Script
    - Track `crt4h_setup_time` when 4H CRT is established
    - On each `new_h4_bar`: if setup is active and `time > crt4h_setup_time + (4 * 60 * 60 * 1000)`, call `f_invalidate_all()`
    - Implement `f_invalidate_all()`: reset all CRT valid/activated flags to false, reset state to IDLE, call `f_cleanup_drawings()`
    - _Requirements: 8.1, 8.2_

  - [x] 11.2 Implement trend change invalidation logic in Pine Script
    - When `trend_changed == true` and `state != 0` (IDLE) and `state != 6` (POSITION_OPEN): call `f_invalidate_all()`
    - Ensure only one active setup direction at a time
    - Guard new setups with `strategy.position_size == 0` check
    - _Requirements: 11.2, 11.3_

  - [x] 11.3 Write property test for time limit invalidation (Property 10)
    - **Property 10: Time Limit Invalidation**
    - Implement `tests/properties/time-limit.property.test.ts`
    - Test: when originating 4H bar closes without position entry, all CRT ranges and state reset to IDLE
    - Minimum 100 iterations
    - **Validates: Requirements 8.1**

  - [x] 11.4 Write property test for long/short symmetry (Property 11)
    - **Property 11: Long/Short Symmetry**
    - Implement `tests/properties/symmetry.property.test.ts`
    - Test: mirroring all price inputs (swap highs/lows) and inverting trend produces equivalent mirrored entry with mirrored TP/SL
    - Minimum 100 iterations
    - **Validates: Requirements 11.1**

  - [x] 11.5 Write property test for single active direction invariant (Property 12)
    - **Property 12: Single Active Direction Invariant**
    - Implement `tests/properties/invariant.property.test.ts`
    - Test: at most one active setup direction at a time; trend change invalidates previous setup immediately
    - Minimum 100 iterations
    - **Validates: Requirements 11.2, 11.3**

- [x] 12. Implement Visual Rendering Module
  - [x] 12.1 Implement visual drawing functions and cleanup logic in Pine Script
    - Implement `f_draw_swing_line(price, style)`: draw dashed horizontal line at swing price extending to current bar
    - Implement `f_draw_ob_box(top, bottom, left, right, color)`: draw semi-transparent box for OB zone
    - Implement `f_draw_crt_box(top, bottom, left, right, color)`: draw semi-transparent box for CRT ranges
    - Color scheme: OB bullish=green(70), OB bearish=red(70), 4H CRT=blue(70), 1H CRT=yellow(70), 15M CRT=green(70), 5M CRT=fuchsia(70)
    - Swing lines: Swing_High=red dashed, Swing_Low=green dashed
    - Implement `f_cleanup_drawings()`: iterate all drawing arrays, delete each line/box, then clear arrays
    - Call drawing functions at appropriate state transitions (OB identified, CRT established, swing detected)
    - Call cleanup on invalidation (`f_invalidate_all()`) and position close
    - Handle TradingView drawing limits (500 lines, 500 boxes) by proactively deleting oldest drawings when approaching limits
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 9.9_

  - [x] 12.2 Write unit tests for visual rendering logic
    - Implement `tests/unit/visual.test.ts`
    - Test that drawing functions produce correct parameters (color, transparency, coordinates)
    - Test cleanup removes all tracked drawings from arrays
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 9.9_

- [x] 13. Integration and State Machine Wiring
  - [x] 13.1 Wire all modules together in the Pine Script file with correct execution order
    - Ensure execution order: Data Fetch → Trend Detection → Swing Detection → Order Block → CRT Cascade State Machine → Time Limit Check → Visual Rendering
    - Add position conflict guard: only allow new setups when `strategy.position_size == 0`
    - Add `na` guards on all HTF data before processing any logic
    - Verify all state transitions are connected with no orphaned or hanging code
    - Confirm strategy settings: `overlay=true`, `default_qty_type=strategy.percent_of_equity`, `default_qty_value=1`
    - _Requirements: 10.1, 10.5, 11.2_

  - [x] 13.2 Write unit tests for state machine transitions
    - Implement `tests/unit/state-machine.test.ts`
    - Test full cascade: IDLE → WAIT_OB_TOUCH → WAIT_4H_ACTIVATION → WAIT_1H_CRT → WAIT_15M_CRT → WAIT_5M_ENTRY → POSITION_OPEN → IDLE
    - Test invalid transitions are ignored (no-op)
    - Test trend change resets from any active state to IDLE
    - _Requirements: 11.2, 11.3_

- [x] 14. Final checkpoint - Ensure all tests pass and strategy is complete
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties using TypeScript + fast-check
- Unit tests validate specific examples and edge cases
- The Pine Script strategy is a single file; all modules are logical sections within it
- Testing extracts core algorithms into TypeScript to enable property-based testing since Pine Script has no external test framework support
- All `request.security()` calls use `barmerge.lookahead_off` to prevent future data leakage

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.2"] },
    { "id": 1, "tasks": ["2.1"] },
    { "id": 2, "tasks": ["2.2", "2.3", "3.1"] },
    { "id": 3, "tasks": ["3.2", "3.3", "4.1"] },
    { "id": 4, "tasks": ["4.2", "6.1"] },
    { "id": 5, "tasks": ["6.2", "6.3", "6.4", "7.1"] },
    { "id": 6, "tasks": ["7.2", "8.1"] },
    { "id": 7, "tasks": ["9.1"] },
    { "id": 8, "tasks": ["9.2", "9.3"] },
    { "id": 9, "tasks": ["9.4", "11.1", "11.2"] },
    { "id": 10, "tasks": ["11.3", "11.4", "11.5", "12.1"] },
    { "id": 11, "tasks": ["12.2", "13.1"] },
    { "id": 12, "tasks": ["13.2"] }
  ]
}
```
